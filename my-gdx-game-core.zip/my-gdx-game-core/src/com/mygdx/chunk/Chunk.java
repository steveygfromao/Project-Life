package com.mygdx.chunk;

public class Chunk
{
	public static final int CHUNKSIZE = 4;
	
	public int x, y;
	public Chunk(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}

