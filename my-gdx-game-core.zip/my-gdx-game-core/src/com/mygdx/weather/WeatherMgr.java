package com.mygdx.weather;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.badguys.Rain;
import com.mygdx.badguys.Snow;
import com.mygdx.badguys.WeatherElement;

public class WeatherMgr {

	List<WeatherElement> weatherSprite = new ArrayList<>();

	Texture spriteSheet;

	TextureRegion[][] region;

	private Sprite rain, snow;


	public WeatherMgr() {
		spriteSheet = new Texture("../my-gdx-game-core/assets/weather.png");
		region = TextureRegion.split(spriteSheet, 9, 9);
		rain = new Sprite(region[0][1]);
		snow = new Sprite(region[0][0]);
	}

	public void renderSnow(SpriteBatch batch) {

		for (WeatherElement weatherElement : weatherSprite) {
			if (weatherElement instanceof Snow) {
				((Snow) weatherElement).move();
				((Snow) weatherElement).render(/* this. */batch, snow, 0);
			}
		}
	}
	public void renderRain(SpriteBatch batch) {

		for (WeatherElement weatherElement : weatherSprite) {
			if (weatherElement instanceof Rain) {
				((Rain) weatherElement).move();
				((Rain) weatherElement).render(/* this. */batch, rain, 1);
			} 
		}
	}

	public void addWeatherSprite(WeatherElement sprite) {
		weatherSprite.add(sprite);
	}

}
