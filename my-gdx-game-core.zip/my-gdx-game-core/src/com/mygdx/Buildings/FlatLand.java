package com.mygdx.Buildings;

public class FlatLand {
	public int x, y, size;
	public FlatLand(int x, int y, int size) {
		this.x = x;
		this.y = y;
		this.size = size;
	}
}