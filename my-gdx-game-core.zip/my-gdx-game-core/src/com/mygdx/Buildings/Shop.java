package com.mygdx.Buildings;

import java.util.ArrayList;
import java.util.Random;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.badguys.BadGuy;
import com.mygdx.game.BlankEntity;
import com.mygdx.game.SpotLight;
import com.mygdx.game.WorldMap;

import box2dLight.RayHandler;

public abstract class Shop {

	protected BlankEntity[][] worldMap;

	Random r;

	SpotLight light = null;
	
	static final int[] openingTimes = {6,7,8,9,10,11};
	static final int[] closingTimes = {15,16,17,18,19,20,21,22,23};

	private ArrayList<BadGuy> occupants;

	public Shop(Vector2 position, int w, int h, BlankEntity[][]worldMap)
	{
		r = new Random();

		this.occupants = new ArrayList<>();
		this.position = position;
		this.w = w;
		this.h = h;
		this.owned = false;
		this.itemsList = new ArrayList<>();
		this.setWorldMap(worldMap);
	}

	private boolean owned;

	public void addOccupant(BadGuy b)
	{
		this.occupants.add(b);
	}
	public void removeOccupant(BadGuy b)
	{
		this.occupants.remove(b);
	}

	public void addItem(ShopItem e) {
		this.itemsList.add(e);
	}


	public boolean isOwned() {
		return owned;
	}

	public void setOwned(boolean owned) {
		this.owned = owned;
	}

	public BadGuy getShopKeeper() {
		return shopKeeper;
	}

	public void setShopKeeper(BadGuy shopKeeper) {
		this.shopKeeper = shopKeeper;
	}

	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public int getWidth() {
		return w;
	}

	public void setWidth(int w) {
		this.w = w;
	}

	public int getHeight() {
		return h;
	}

	public void setHeight(int h) {
		this.h = h;
	}

	public int getTimeOpen() {
		return timeOpen;
	}

	public void setTimeOpen(int timeOpen) {
		this.timeOpen = timeOpen;
	}

	public int getTimeClose() {
		return timeClose;
	}

	public void setTimeClose(int timeClose) {
		this.timeClose = timeClose;
	}

	public ArrayList<ShopItem> getItemsList() {
		return itemsList;
	}

	public void showItems() {
		for(ShopItem item : itemsList) {
			System.out.println(item);
		}
	}
	
	public void setItemsList(ArrayList<ShopItem> itemsList) {
		this.itemsList = itemsList;
	}


	public BlankEntity[][] getWorldMap() {
		return worldMap;
	}

	public void setWorldMap(BlankEntity[][] worldMap) {
		this.worldMap = worldMap;
	}

	private Vector2 position;
	private int w,h;
	int timeOpen;
	int timeClose;

	private ArrayList<ShopItem> itemsList;

	private BadGuy shopKeeper;


	public abstract void drawShop(TextureRegion[][]regions, SpriteBatch batch, WorldMap world, RayHandler rayHandler);

	public void showOccupants() {
		for(BadGuy b : this.occupants)
		{
			System.out.println(b.getClass().getSimpleName());
		}
	}

	@Override
	public String toString() {
		return "Time open:" + this.timeOpen + " Time close:" + this.timeClose;
	}

}


