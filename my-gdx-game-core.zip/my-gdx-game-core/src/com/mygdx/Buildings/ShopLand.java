package com.mygdx.Buildings;

public class ShopLand extends FlatLand
{


	public ShopLand(int x, int y, int size) {
		super(x,y,size);
	}



}

