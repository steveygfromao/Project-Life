package com.mygdx.Buildings;


public class BiomeLand extends FlatLand {

	public BiomeLand(int x, int y, int size) {
		super(x,y,size);
	}
}



