package com.mygdx.Buildings;

public class ShopItem {

	public ShopItem(String itemName, double price, String itemDescription, int levelRequired) {
		super();
		this.itemName = itemName;
		this.price = price;
		this.itemDescription = itemDescription;
		this.levelRequired = levelRequired;
	}

	private String itemName;
	private double price;
	private String itemDescription;
	private int levelRequired;

	@Override
	public String toString() {
		return itemName + " �" + price + " " + itemDescription + " " + levelRequired;
	}
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public int getLevelRequired() {
		return levelRequired;
	}
	public void setLevelRequired(int levelRequired) {
		this.levelRequired = levelRequired;
	}
}
