package com.mygdx.Buildings;

import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.BlankEntity;

public class BuildingFactory {

	public static enum Buildings {
		armour(0), pet(1), weapons(2);
		private final int value;

		private Buildings(int value) {
			this.value = value;
		}

		public int getValue() {
			return this.value;
		}
	}

	public static Shop createShop(Buildings b, Vector2 position, int w, int h, BlankEntity[][] worldMap) {
		Shop shop = null;
		switch (b.getValue()) {
		case 0:
			shop = new ArmourShop(position, w, h, worldMap);
			break;
		case 1:
			shop = new PetShop(position, w, h, worldMap);
			break;
		case 2:
			shop = new WeaponsShop(position, w, h, worldMap);
			break;
		}

		// we add the shop to the singleton building manager class
		BuildingManager.getInstance().addShop(shop);
		return shop;
	}
}
