package com.mygdx.Buildings;

import java.util.ArrayList;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.WorldMap;

import box2dLight.RayHandler;

public class BuildingManager {

	private static ArrayList<Shop> shops = null;
	private static TextureRegion[][] shopSpriteRegions = null;
	private static Texture buildings = null;

	static
	{
		shops = new ArrayList<>();
	}

	private static float gameHours;

	public static void setHours(float hours) { gameHours = hours; }
	public static float getHours() { return gameHours; }

	private static BuildingManager instance = null;

	// Thread safe with synchronized block singleton
	public static BuildingManager getInstance() {
		if(instance==null) {
			synchronized(BuildingManager.class) {
				if(instance==null)
				{
					instance = new BuildingManager();
					buildings = new Texture("../my-gdx-game-core/assets/buildings.png");
					shopSpriteRegions = TextureRegion.split(buildings, 300, 300);
				}
			}
		}
		return instance;
	}

	public ArrayList<Shop> getShops() {
		return shops;
	}

	public void addShop(Shop s)
	{
		shops.add(s);
	}

	public void removeShop(Shop s)
	{
		shops.remove(s);  // possibly need to remove from the game map too...
	}

	public void renderShops(SpriteBatch batch, Camera camera, int width, int height, WorldMap world, RayHandler rayHandler) {
		shops.forEach(shop -> {
				// only draw shops that the camera can see
				if (shop.getPosition().x >= (camera.position.x - (width) - 0) && shop.getPosition().x <= camera.position.x + width
						&& shop.getPosition().y >= (camera.position.y - (height) - 0) && shop.getPosition().y <= camera.position.y + height)
				{
					shop.drawShop(shopSpriteRegions, batch, world, rayHandler);
				}
		});
	}
}
