package com.mygdx.Buildings;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.BlankEntity;
import com.mygdx.game.SpotLight;
import com.mygdx.game.WorldMap;

import box2dLight.PointLight;
import box2dLight.RayHandler;

public class WeaponsShop extends Shop {

	public WeaponsShop(Vector2 position, int w, int h,BlankEntity[][]worldMap) {
		super(position, w, h,worldMap);

		ShopItem item = new ShopItem("Dagger",2.0,"Small dagger, dmg 1",2);
		this.addItem(item);
		item = new ShopItem("Sword",5.0,"Steel sword, dmg 2",5);
		this.addItem(item);

		this.setTimeOpen(Shop.openingTimes[r.nextInt(Shop.openingTimes.length-1)]);
		this.setTimeClose(Shop.closingTimes[r.nextInt(Shop.closingTimes.length-1)]);

	}

	@Override
	public void drawShop(TextureRegion[][]regions,  SpriteBatch batch, WorldMap world, RayHandler rayHandler) {
		Sprite s = new Sprite(regions[0][1]);
		
		if(BuildingManager.getHours() >= this.getTimeOpen() && BuildingManager.getHours() < this.getTimeClose())
		{
			s.setColor(1,1,1,1);
			if(light!=null)
			{
				world.lights.remove(light);
				light.pl.remove();
				light.pl.dispose();
				light = null;
			}
		}
		else  // shop is closed
		{
			if(light==null)
			{
				light = new SpotLight();

				light.pl = new PointLight(rayHandler, 50, Color.PURPLE, 300, this.getPosition().x ,
						this.getPosition().y );
				// camera.position.y);
	
				light.x = (int) this.getPosition().x/16;
				light.y = (int) this.getPosition().y/16;
				world.lights.add(light); // add to our light
	
				
			}
			s.setColor(0.1f,0.1f,0.1f,1.0f);
		}
		s.setSize(s.getWidth() * 1, s.getHeight() * 1);
		s.setRotation(0);
		s.setPosition(this.getPosition().x, this.getPosition().y);
		s.draw(batch);
		s.setSize(s.getWidth() * 1, s.getHeight() * 1);
		s.setRotation(0);
		s.setPosition(this.getPosition().x, this.getPosition().y);
		s.draw(batch);
	}

}
