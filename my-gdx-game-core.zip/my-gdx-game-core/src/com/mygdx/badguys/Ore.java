package com.mygdx.badguys;

import com.badlogic.gdx.graphics.Camera;
import com.mygdx.game.WorldMap;

public class Ore extends Pig { //BadGuy {

	public Ore(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 16;
		this.setSpeed(0.2f);
	}
	

	@Override
	public void attack() {
		System.out.println(this.getClass().getName() + " attack");
		
	}

}
