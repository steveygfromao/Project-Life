package com.mygdx.badguys;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.WorldMap;

import box2dLight.RayHandler;

public class UfoManager {

	private ArrayList<Ufo> ufos = new ArrayList<>();

	private TextureRegion[][] regions;
	private Texture ufoSprites;
	private WorldMap worldMap;
	private Camera camera;
	private BadGuyOutsideManager outsideManager;
	private float width, height;

	private RayHandler rayHandler;
	
	private SpriteBatch batch;
	
	public UfoManager(WorldMap worldMap, Camera camera, BadGuyOutsideManager outsideManager, RayHandler rayHandler) {
		width = Gdx.graphics.getWidth() / 2; // get screen width and height
		// (used for frustum culling in renderBadGuys method)
		height = Gdx.graphics.getHeight() / 2;

		this.outsideManager = outsideManager;
		this.worldMap = worldMap;
		this.camera = camera;
		ufoSprites = new Texture("../my-gdx-game-core/assets/ufo.png");
		regions = TextureRegion.split(ufoSprites, 400, 200);
		
	}

	public void addUfo(float x, float y, int row, int col) {
		Ufo ufo = new Ufo(x, y, row, col, regions, worldMap, outsideManager, null);//rayHandler);
		ufos.add(ufo);
		ufo.camera = camera;
	}

	public void updateUfos(SpriteBatch batch, Camera camera) {
		
		Color c = batch.getColor();
		// Need to check if in view here before rendering...
		ufos.forEach(u -> u.move());

		batch.setColor(1,1,1,1);
		
		for (Ufo badguy : ufos) {
			// Check if in camera view, if so, render
			if ((badguy.x >= camera.position.x - width - 400 && badguy.x <= camera.position.x + width + 30)
					&& (badguy.y >= camera.position.y - (height + 30) && badguy.y <= camera.position.y + height))

				ufos.forEach(u -> u.render(/*this.*/batch));
		}
		batch.setColor(c);
		
	}
	
	public RayHandler getRayHandler() {
		return rayHandler;
	}

	public void setRayHandler(RayHandler rayHandler) {
		this.rayHandler = rayHandler;
	}
}
