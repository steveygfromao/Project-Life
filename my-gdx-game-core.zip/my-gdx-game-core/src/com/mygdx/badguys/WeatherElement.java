package com.mygdx.badguys;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.WorldMap;

abstract public class WeatherElement implements IWeatherElement {

	protected WorldMap worldMap;
	protected Camera camera;

	public float x, y, velocity, scale, angle, tint;

	protected float width = Gdx.graphics.getWidth() / 2; // get screen width and height
	protected float height = Gdx.graphics.getHeight() / 2;


	public WeatherElement(Camera camera, WorldMap worldMap, float x, float y, float velocity, float scale, float angle,
			float tint) {
		this.x = x;
		this.y = y;
		this.velocity = velocity;
		this.worldMap = worldMap;
		this.angle = angle;
		this.scale = scale;
		this.tint = tint;
		this.camera = camera;

	}

	@Override
	public abstract void move();

	@Override
	public void render(SpriteBatch batch, Sprite s, int xOffset) {

		Color c = batch.getColor();
		batch.setColor(tint, tint, tint, tint);


		s.setPosition(x, y);
		s.setSize(16, 16);
		s.setScale(scale);

		s.draw(batch);//, this.x, this.y);//, 0, 0, 16, 16, 1, scale, angle, 0, 0, 16, 16, false, false);// 0,
																										// 0,
																										// 1,
																										// 1,
																										// 0,
																										// 0
																										// );
		batch.setColor(c);

	}
}
