package com.mygdx.badguys;

// stores x,y positions of possible spawn points for baddies outside
public class OutsideLand {
	
	public int x, y;
	public OutsideLand(int x, int y) {
		this.x = x; 
		this.y = y;
	}
}
