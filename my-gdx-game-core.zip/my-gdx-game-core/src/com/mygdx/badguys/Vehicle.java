package com.mygdx.badguys;

abstract public class Vehicle {

	abstract void move();
	abstract void stop();

	private BadGuy driver;

	protected void setDriver(BadGuy driver) 
	{
		this.driver = driver;  // set who is driving the vehicle, if anybody
	}
	
	
	
}
