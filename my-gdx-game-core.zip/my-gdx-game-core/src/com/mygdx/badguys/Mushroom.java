package com.mygdx.badguys;

import com.badlogic.gdx.graphics.Camera;
import com.mygdx.game.WorldMap;

public class Mushroom extends Pig {
	public Mushroom(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 10;
	}
	

	@Override
	public void attack() {
		System.out.println(this.getClass().getName() + " attack");
		
	}
}
