package com.mygdx.badguys;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class SpeechBubble {

	private TextureRegion[][] regions;
	private BadGuy bg;
	private SpriteBatch batch;
	private Sprite s;

	private BitmapFont font;
	private String text;
	private long delay;

	private boolean finished;
	
	private String[] words;
	
	private int lineSpace = 0;
	public SpeechBubble(BadGuy bg, SpriteBatch batch, TextureRegion[][]region, String text) {
		this.regions = region;
		this.bg = bg;
		this.batch = batch;
		this.s = new Sprite(regions[0][0]);
		this.delay = System.currentTimeMillis() + 4*1000;  // 3 seconds to appear for
		font = new BitmapFont();
		this.text = text;
		this.finished = false;
		this.words = text.split("[[ ]*|[,]*|[\\.]*|[:]*|[/]*|[!]*|[?]*|[+]*]+");
	}

	public void draw()
	{
		if(s!=null)
		{
			if(System.currentTimeMillis() < delay)  // draw for a certain time period
			{
				s.setSize(s.getWidth() * 1, s.getHeight() * 1);
				s.setRotation(0);
				s.setPosition(bg.getX() - s.getWidth()/2, bg.getY() + 16);
				s.draw(batch);
				font.setColor(Color.BLACK);
				font.getData().setScale(0.7f);
				for(String word : words)
				{
					font.draw(batch, word, s.getX() + 8, s.getY() + 64 - lineSpace);
					lineSpace += 10;
				}
				lineSpace = 0;
			}
			else
			{
				finished = true;
			}
		}
	}
	public boolean isFinished() { return finished; }
	public void resetSpeechBubble() {
	
	}
}
