package com.mygdx.badguys;

public class Rocket extends Vehicle {

	
	
	@Override
	void move() {

		// As a rocket will be able to fly
	}

	@Override
	void stop() {
	}

}
