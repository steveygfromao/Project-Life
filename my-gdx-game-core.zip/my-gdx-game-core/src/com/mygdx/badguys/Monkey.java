/* Created with SDG Creature Class Creator. */
package com.mygdx.badguys;
import com.badlogic.gdx.graphics.Camera;
import com.mygdx.game.WorldMap;

public class Monkey extends Pig {
	public Monkey(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 10;
		currentState = State.WALK;
		this.setSpeed(0.1f);
	}

	@Override
	public void attack() { }

}
