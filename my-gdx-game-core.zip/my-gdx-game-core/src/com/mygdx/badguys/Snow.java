package com.mygdx.badguys;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.WorldMap;

public class Snow extends WeatherElement {

	float radius = 1.0f;
	float drift = 0;
	
	Random r = new Random();

	public Snow(Camera camera, WorldMap worldMap, float x, float y, float velocity, float scale, float angle,
			float tint, float drift) {
		super(camera, worldMap, x, y, velocity, scale, angle, tint);
		this.drift = drift;
	}

	@Override
	public void move() {

		x = (float) (x + Math.cos(angle) * radius);  // make snow drift a little, makes it look more realistic
		
		if(this.y < Gdx.graphics.getHeight())
		{
			this.y += velocity/3;// + 3;
			angle += drift/2;
		}
		else
		{
			this.y = r.nextInt(100)-200;
			this.x = r.nextInt(Gdx.graphics.getWidth());
			this.velocity = r.nextInt(10)+3;
			this.scale = r.nextFloat()+0.5f;
			this.tint = r.nextFloat()+0.55f;
			this.drift = r.nextFloat()/2;
		}
	}
/*
	@Override
	public void move() {

		x = (float) (x + Math.cos(angle) * radius);  // make snow drift a little, makes it look more realistic
		
		int squareX = (int) x;
		int squareY = (int) y;
		squareX -= squareX % 16;
		squareY -= squareY % 16;

		if (this.worldMap.checkCollisionWithGrass(new Vector3(squareX, squareY, 0))) // collision
		{
			if (this.y <= 200) // bottom of world?
			{
				this.y = (WorldMap.h * 16) + r.nextInt(1000);
			}
			this.y -= velocity/3;// + 3;
		} else { // We have collided
		//	worldMap.getAndSetSnowStageEntity(squareX / 16,squareY / 16);
			this.y = (WorldMap.h * 16) + r.nextInt(1000);
		}
		angle += drift/2;*/
//	}

}
