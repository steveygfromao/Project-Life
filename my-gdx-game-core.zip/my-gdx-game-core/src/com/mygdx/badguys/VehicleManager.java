package com.mygdx.badguys;

import java.util.ArrayList;

public class VehicleManager {

	private ArrayList<Vehicle> vehicles = new ArrayList<>();
	
	
	
}

