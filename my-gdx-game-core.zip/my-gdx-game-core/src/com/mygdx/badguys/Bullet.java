package com.mygdx.badguys;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.Collision;

public class Bullet {

	private static Texture bullet = null;
	private Sprite spriteBullet = null;
	private boolean firing = false;
	
	private float x,y, px,py,xVel, yVel;
	private int speed = 0;
	private float dir = -4.0f;
	private boolean bDone = false;
	
	public Sprite getBullet() { return spriteBullet; }
			
	private double x1,y1,distance,angleToPlayer;
	
	public boolean fireComplete() { return this.bDone; }
	
	public void setDir(float dir) {
		this.dir = dir;
	}
	
	public Bullet()
	{
		speed = new Random().nextInt(12)+5;
		bDone = false;
		firing = false;
		if(bullet==null) {
		     bullet = new Texture(Gdx.files.internal("../my-gdx-game-core/assets/sentrybulletone.png"));
		}
	    spriteBullet = new Sprite(bullet);
	
	}
	
	public void fireBullet(float x, float y, float tx, float ty, SpriteBatch batch, BadGuy badGuy)
	{
		
		if(!firing)
		{
			bDone = false;
			
			this.x = x; this.y = y; this.px=tx;this.py=ty;
						
			angleToPlayer = Math.atan2(Math.abs(y-ty), Math.abs(x-tx));
			firing = true;
		}
	    
		xVel = (float) ((speed) * Math.cos(angleToPlayer));
        yVel = (float) ((speed) * Math.sin(angleToPlayer));
        
        
        // we need check if bullet hits a wall or something...
        if(Collision.intersectorCollision(this.x, this.y, 16, 16, tx, ty, 16, 16))
        {
        	if(badGuy!=null)
        	{
        		badGuy.decreaseHealth(1.0f);
        	}
        	else
        	{
        		// we hit the player
        	}
        	
        	firing = false;
        	bDone = true;
        	return;
        }
        
		batch.draw(spriteBullet, this.x, this.y, 16, 16);
		
        if(this.dir <0)
		{
			if(this.x > this.px)  
			{
				this.x -= xVel;
				this.y -= yVel;
			}
			else
			{
				bDone = true;
				firing = false;				
			}
		} 
		else 
		{
			if(this.x < this.px)
			{
				this.x += xVel;
				this.y -= yVel;
			}
			else
			{
				bDone = true;
				firing = false;				
			}
			
		}
	}

}
