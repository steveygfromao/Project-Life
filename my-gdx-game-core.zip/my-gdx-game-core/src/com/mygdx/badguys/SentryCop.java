/* Created with SDG Creature Class Creator. */
package com.mygdx.badguys;

import java.util.concurrent.CopyOnWriteArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.WorldMap;

public class SentryCop extends Bat {

	private Bullet bullet;
	private int randomShoot;

	public SentryCop(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);

		bullet = new Bullet();
		health = 10;
		currentState = State.FLYLEFT;
		this.setSpeed(0.1f);
		this.setAggression(12);

	}

	
	// Always fire at player before any creature
	public void fireBullet(SpriteBatch batch, CopyOnWriteArrayList<BadGuy> badGuys) {

		bullet.setDir(this.bRight == true ? -4.0f : 4.0f);

		if (currentState == State.ATTACK) {

			bullet.fireBullet(x, y, camera.position.x, camera.position.y, batch, null);

			if (bullet.fireComplete())
				currentState = r.nextBoolean() == true ?
												State.FLYLEFT :
												State.FLYRIGHT;

		} else {
			fireAtCreature(batch, badGuys);
		}

	}

	public void fireAtCreature(SpriteBatch batch, CopyOnWriteArrayList<BadGuy> badGuys) {

		bullet.setDir(this.bRight == true ? -4.0f : 4.0f);

		for (int i = 0; i < badGuys.size(); i++) {
			BadGuy badguy = badGuys.get(i);

			if ((badguy.x >= camera.position.x - (Gdx.graphics.getWidth() / 2 + 30)
					&& badguy.x <= camera.position.x + Gdx.graphics.getWidth() / 2 + 10)
					&& (badguy.y >= camera.position.y - Gdx.graphics.getHeight() / 2
							&& badguy.y <= camera.position.y + Gdx.graphics.getHeight() / 2)) {

				if (!(badguy instanceof SentryCop)) {
					
					// We could check here if wanted what the sentry cop can actually fire at...
					
					if (this.castRay((int) x, (int) y, new Vector3(badguy.getX(), badguy.getY(), 0))) {
						badguy.shootAt = true;
						bullet.fireBullet(x, y, badguy.getX(), badguy.getY(), batch, badguy);
						
						if (bullet.fireComplete()) {
							if (r.nextBoolean()) // chance of stopping to fire
							{
								currentState = r.nextBoolean() == true ? State.FLYLEFT : State.FLYRIGHT;
							}
							badguy.shootAt = false;
						}
						break;
					}
				}

			}
		}

	}

	@Override
	public void move(float x, float y, Camera camera) {

		switch (currentState) {
		case ATTACK:
			// We will shoot towards the player, need get angle from sentry to
			// player
			// The manager class will notice the change of state and call
			// fireBullet method

			break;

		case ATTACKCREATURE:

			break;

		case FLYLEFT:

			if (this.castRay((int) x, (int) y, camera.position)) {
				currentState = State.ATTACK; // fire a bullet towards the player
			} else {
				if (!worldMap.checkCollisionRounded(new Vector3(x - 10, y, 0))) { // collision
																					// on
																					// left
					currentState = State.FLYRIGHT;
				} else {
					bRight = true;
					xDir = -speed;
					yDir = (float) (Math.sin(angle) * radius);
				}
			}
			break;
		case FLYRIGHT:
			if (this.castRay((int) x, (int) y, camera.position)) {
				currentState = State.ATTACK; // fire a bullet towards the player
			} else {

				if (!worldMap.checkCollisionRounded(new Vector3(x + 10, y, 0))) { // collision
																					// on
																					// right
					currentState = State.FLYLEFT;
				} else {
					bRight = false;
					xDir = speed;
					yDir = (float) (Math.sin(angle) * radius);
				}
			}
			break;

		}
		if (this.currentState != State.ATTACK || this.currentState != State.ATTACKCREATURE) {
			this.angle += (this.randomAngleIncrement / 10);
			this.x += xDir;
			this.y += yDir;
		}

	}

	@Override
	public void attack() {
	}

}
