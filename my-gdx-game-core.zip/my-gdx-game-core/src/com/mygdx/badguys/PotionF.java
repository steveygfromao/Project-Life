/* Created with SDG Creature Class Creator. */
package com.mygdx.badguys;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.WorldMap;

public class PotionF extends Pig {
	public PotionF(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 10;
		currentState = State.WALK;
		this.setSpeed(0.1f);
	}

	@Override
	public void attack() { }

	@Override
	public void move(float x, float y, Camera camera) {

		Vector3 pos = new Vector3(x, y - 12, 0);
		if (this.worldMap.checkCollisionRounded(pos)) // collision with ground
		{
			yDir = velocity; // Falling down
			velocity -= 0.2f;
		} else {
			yDir = 0;
			velocity = -0.5f;
		}
		this.y += yDir;
		
	}
	
}
