/* Created with SDG Creature Class Creator. */
package com.mygdx.badguys;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.WorldMap;

public class Bat extends Pig {
	
	protected double angle = 0.2f;
	protected double radius = 0.2f;
	protected double randomAngleIncrement = 0;
	
	public Bat(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 10;
		currentState = State.FLYLEFT;
		this.setSpeed(0.4f);
		this.randomAngleIncrement = r.nextDouble();
		this.radius = r.nextDouble();
	}

	@Override
	public void move(float x, float y, Camera camera) {
		switch (currentState) {
		
		
		// We need to check if we collide with something above / below TODO TODO TODO
/*
 * 		if (!worldMap.checkCollisionRounded(new Vector3(x, y+16, 0))) {  // collision above
				System.out.println("Collision above");
			}
	
			if (!worldMap.checkCollisionRounded(new Vector3(x, y, 0))) {  // collision on right
				xDir = 0;
				yDir += speed;
			}
			else
			{
				xDir = -speed;
				yDir = 0;
			}	
 */
		case FLYLEFT:				
			if (!worldMap.checkCollisionRounded(new Vector3(x-10, y, 0))) {  // collision on left
				currentState = State.FLYRIGHT;
			}
			else
			{
				bRight = true;
				xDir = -speed;
				yDir = (float) (Math.sin(angle) * radius);
			}
			break;
		case FLYRIGHT:
			if (!worldMap.checkCollisionRounded(new Vector3(x+10, y, 0))) {  // collision on right
				currentState = State.FLYLEFT;
			}
			else
			{
				bRight = false;
				xDir = speed;
				yDir = (float) (Math.sin(angle) * radius);
			}
			break;
			
		}
		this.angle += (this.randomAngleIncrement/10);
		this.x += xDir;
		this.y += yDir;
	}
			
		
	@Override
	public void attack() { }

}
