package com.mygdx.badguys;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class WeatherManager<T extends WeatherElement> {

	List<T> weatherSprite = new ArrayList<>();

	Texture spriteSheet;

	TextureRegion[][] region;

	private Camera camera;

	private Sprite rain,snow;

	private SpriteBatch batch;

	public WeatherManager(Camera camera) {
		spriteSheet = new Texture("../my-gdx-game-core/assets/weather.png");
		this.camera = camera;

		region = TextureRegion.split(spriteSheet, 9, 9);

		rain = new Sprite(region[0][1]);
		snow = new Sprite(region[0][0]);


	}

	public void render(SpriteBatch batch, float x) {

		for (T weatherElement : weatherSprite) {

			if ((((WeatherElement) weatherElement).x >= camera.position.x - ((WeatherElement) weatherElement).width
					- 1000)
					&& (((WeatherElement) weatherElement).x <= camera.position.x
							+ ((WeatherElement) weatherElement).width + 1000)) {

				if (weatherElement instanceof Rain) {

					((Rain) weatherElement).move();

				} else {
					if (weatherElement instanceof Snow) {
						((Snow) weatherElement).move();
					}
				}

			}
			// move weather element regardless of whether in camera view or not
			// ((WeatherElement)weatherElement).x += x;
			// Only DRAW if in camera view (the weather element would still have
			// been moved)
			if ((((WeatherElement) weatherElement).x >= camera.position.x - ((WeatherElement) weatherElement).width
					+ 30)
					&& (((WeatherElement) weatherElement).x <= camera.position.x
							+ ((WeatherElement) weatherElement).width + 10)
					&& (((WeatherElement) weatherElement).y >= camera.position.y
							- ((WeatherElement) weatherElement).height)
					&& (((WeatherElement) weatherElement).y <= camera.position.y
							+ ((WeatherElement) weatherElement).height)) {


				if (weatherElement instanceof Rain) {
					((Rain) weatherElement).render(/*this.*/batch, rain,1);

				} else {
					if (weatherElement instanceof Snow) {
						((Snow) weatherElement).render(/*this.*/batch, snow,0);
					}
				}

			}
		}

	}

	public void addWeatherSprite(T sprite) {
		weatherSprite.add(sprite);
	}

}
