/*
 * UFO Enemy
 * SDG - Started 27/4/2015
 * AI is FSM plus some randomness every so often so ufo doesn't have to change AI state
 * when a collision occurs
 */
package com.mygdx.badguys;

import java.util.Random;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.WorldMap;

import box2dLight.RayHandler;

public class Ufo {
	private final static int CHANGESTATETIME = 200;
	public Camera camera;
	private float yDir, xDir = 0;
	private WorldMap worldMap;
	private int idle = 100;
	private int row, col;

	private enum State {
		IDLE, MOVINGUP, MOVINGDOWN, MOVINGLEFT, MOVINGRIGHT, DROPPINGALIENS, SHOOTING,
	}

	private BadGuyOutsideManager outsideManager;

	private State currentState = State.MOVINGDOWN;

	public float x, y;

	private TextureRegion[][] region;

	private Random r = new Random();

	private float centreX;

	private int moved = 0;

	private boolean bVisited = false;

	private int verticalSpeed, horizontalSpeed = 0;

	public Ufo(float x, float y, int row, int col, TextureRegion[][] region, WorldMap worldMap,
			BadGuyOutsideManager outsideManager, RayHandler rayHandler) {
		this.outsideManager = outsideManager;
		this.region = region;
		this.worldMap = worldMap;
		this.x = x;
		this.y = y;
		this.row = row;
		this.col = col;
		this.centreX = region[row][col].getRegionWidth() / 2;

		horizontalSpeed = r.nextInt(2) + 2;
		verticalSpeed = r.nextInt(3) + 2;

		idle = r.nextInt(200) + 50; // how long ufo should be idle

	}

	// Drop down an alien or more...
	public void manShip() {
		int alienAmount = r.nextInt(2); // random amount of aliens to create
		for (int i = 0; i <= alienAmount; i++) {
			switch (r.nextInt(4)) {
			case 0:
				BadGuy slime = new Ore(centreX + this.x + i, y, 8, 3, camera, worldMap);
				slime.load("../my-gdx-game-core/assets/badguys.png", 40, 5, false, "Fox");
				outsideManager.addBadGuy((int) slime.getX(), (int) slime.getY(), slime);
				break;
			case 1:
				BadGuy jackRussell = new JackRussell(centreX + this.x + i, y, 6, 2, camera, worldMap);
				jackRussell.load("../my-gdx-game-core/assets/badguys.png", 40, 5, false, "Rabbit");
				outsideManager.addBadGuy((int) jackRussell.getX(), (int) jackRussell.getY(), jackRussell);
				break;
			case 2:
				BadGuy skeleton = new Skeleton(centreX + x + i, y, 23, 3, camera, worldMap);
				skeleton.load("../my-gdx-game-core/assets/badguys.png", 40, 5, false, "Pig");
				outsideManager.addBadGuy((int) skeleton.getX(), (int) skeleton.getY(), skeleton);
				break;
			case 3:
				BadGuy ore = new Ore(centreX + x + i, y, 26, 3, camera, worldMap);
				ore.load("../my-gdx-game-core/assets/badguys.png", 40, 5, false, "Frog");
				outsideManager.addBadGuy((int) ore.getX(), (int) ore.getY(), ore);
				break;
			case 4:
				BadGuy sheep = new Sheep(centreX + x + i, y, 4, 2, camera, worldMap);
				sheep.load("../my-gdx-game-core/assets/badguys.png", 40, 5, false, "Koala");
				outsideManager.addBadGuy((int) sheep.getX(), (int) sheep.getY(), sheep);
				break;
			default: // nothing on boards
				break;
			}
		}

	}

	public void render(SpriteBatch spriteBatch) {
		spriteBatch.draw(region[row][col], x, y);
	}

	public void move() {
		// We change the behaviour of the UFO every so often to add more realism
		if (moved > CHANGESTATETIME && bVisited) {
			int val = r.nextInt(6); // we favour moving down - 2/6 of moving
									// down
			if (val == 0)
				currentState = State.MOVINGRIGHT;
			if (val == 2)
				currentState = State.MOVINGLEFT;
			if (val == 1 || val == 3)
				currentState = State.MOVINGUP; // 2/6 chance of moving up
			if (val == 4)
				currentState = State.IDLE; // when idle, will drop aliens down
			if (val == 5 || val == 6)
				currentState = State.MOVINGDOWN;
			moved = 0;
		}
		moved++;

		switch (currentState) {
		case IDLE:
			if (this.idle <= 2) {
				currentState = State.DROPPINGALIENS; // time to drop some aliens
														// - beam them down!
				idle = r.nextInt(200) + 50;
			} else {
				idle--;
			}
			break;
		case MOVINGUP:
			yDir = 2.0f;
			moveUp();
			break;
		case MOVINGDOWN:
			yDir = -2.0f;
			moveDown();
			break;
		case MOVINGLEFT:
			moveLeft();
			break;
		case MOVINGRIGHT:
			moveRight();
			break;
		case DROPPINGALIENS: 
			manShip();
			currentState = State.MOVINGUP;
			break;
		case SHOOTING:
			break;
		}
	}

	private void moveDown() {
		Vector3 pos = new Vector3(x, y - 150, 0);
		if (!this.worldMap.checkLongCollision(pos, 200, 200)) // collision
		{
			this.y -= verticalSpeed;
		} else {
			bVisited = true; // UFO has appeared near the land
			int val = r.nextInt(3);
			if (val == 0)
				currentState = State.MOVINGLEFT;
			if (val == 1)
				currentState = State.MOVINGRIGHT;
			else
				currentState = State.MOVINGUP;
		}
	}

	private void moveLeft() {
		if (this.worldMap.checkCollision(new Vector3(x - 4, y, 0))) {
			if (this.x > 200)
				this.x -= horizontalSpeed;
			else {
				if (r.nextBoolean())
					currentState = State.MOVINGRIGHT;
				else
					currentState = State.MOVINGUP;
			}
		} else {
			int v = r.nextInt(3);
			if (v == 0)
				currentState = State.MOVINGRIGHT;
			if (v == 1)
				currentState = State.MOVINGUP;
			else
				currentState = State.MOVINGDOWN;
		}
	}

	private void moveRight() {
		if (this.worldMap.checkCollision(new Vector3(x + 404, y, 0))) {
			if (this.x / 16 < worldMap.w - 200) // at end of world on right?
			{
				this.x += horizontalSpeed;
			} else {
				if (r.nextBoolean())

					currentState = State.MOVINGLEFT;
				else
					currentState = State.MOVINGUP;
			}
		} else {
			int v = r.nextInt(3);
			if (v == 0)
				currentState = State.MOVINGLEFT;
			if (v == 1)
				currentState = State.MOVINGDOWN;
			else
				currentState = State.MOVINGUP;
		}
	}

	private void moveUp() {
		if (!this.worldMap.checkCollision(new Vector3(x - 4, y, 0))
				|| !this.worldMap.checkCollision(new Vector3(x + 404, y, 0)))
			this.y += verticalSpeed;
		else {
			int val = r.nextInt(3);
			if (val == 0)
				currentState = State.MOVINGRIGHT;
			else if (val == 1)
				currentState = State.MOVINGLEFT;
		}

	}
}
