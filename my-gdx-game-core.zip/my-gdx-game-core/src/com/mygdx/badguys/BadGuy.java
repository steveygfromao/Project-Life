package com.mygdx.badguys;

import java.util.concurrent.CopyOnWriteArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Pixmap.Format;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.mygdx.game.Line;
import com.mygdx.game.Sterria;
import com.mygdx.game.WorldMap;

public abstract class BadGuy {


	protected boolean bAnimating = true;
	
	protected boolean inShop;
	
	protected SpeechBubble speechBubble;

	protected SpriteBatch batch;

	private int spriteCurrentFrame = 0;
	private final float frameLength = 0.1f;
	private float animationElapsed = 0.0f;

	protected double age;

	protected float speed;
	protected float runSpeed = 0;

	protected boolean shootAt = false;

	protected WorldMap worldMap;

	public boolean isIdle() { return this.bAnimating; }
	
	
	public static enum State {
		IDLE, CHASELEFT, CHASERIGHT,  WALK, RUN, JUMP, DEAD, FLYUP, FLYDOWN, FLYLEFT, FLYRIGHT, ATTACK, ATTACKCREATURE,
		INSHOP;
	}

	protected State currentState = State.IDLE;

	protected double ageToLiveTo = 4.0;

	protected float x, y;
	protected float health;

	protected double foodLevel;
	public double getFoodLevel() { return foodLevel; }
	public void increaseFoodLevel(double level) { foodLevel += level; }

	protected int aggression;
	public int getAggression() {
		return aggression;
	}


	public double getAge() { return this.age; }
	public void setAge(double age) { this.age = age; }

	public void setSpeed(float speed) { this.speed = speed; }
	public float getSpeed() { return this.speed; }

	public void setAggression(int aggression) {
		this.aggression = aggression;
	}

	protected boolean inVehicle;


	public boolean isInVehicle() {
		return inVehicle;
	}

	public void setInVehicle(boolean inVehicle) {
		this.inVehicle = inVehicle;
	}

	public boolean isCanDrive() {
		return canDrive;
	}

	public void setCanDrive(boolean canDrive) {
		this.canDrive = canDrive;
	}

	public boolean isBePet() {
		return bePet;
	}

	public void setBePet(boolean bePet) {
		this.bePet = bePet;
	}

	protected boolean canDrive;
	protected boolean bePet;

	protected /*static*/ Animation walkAnimation;
	protected /*static*/ TextureRegion currentFrame;
	//protected SpriteBatch batch, innerBatch;
	protected int animStart;
	protected int frameCount;
	protected Camera camera;
	protected float stateTime;

	private Array<Sprite> badGuySprites;

	private TextureAtlas spriteSheet;

	private double dayCycle = 0;

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	protected float xDir = 0;
	protected float yDir = 0;

//	public ShapeRenderer lineRenderer = null;

	protected boolean bRight = !false;

	private Texture healthTexture, healthTexture2;

	private Pixmap pixmap, pixmap2 = null;

	private Line ray;

	private Pixmap createProceduralPixmap(int width, int height, int r, int g, int b) {
		Pixmap pixmap = new Pixmap(width, height, Format.RGBA8888);

		pixmap.setColor(r, g, b, 1);
		pixmap.fill();
		return pixmap;
	}

	public float getHealth() {
		return this.health;
	}

	public void setHealth(float health) {
		this.health = health;
	}


	public void increaseAge() {
		this.age += 0.1;
	}

	public BadGuy(float x, float y, int animStart, int frameCount, Camera camera, WorldMap worldMap) {// ,
																										// TextureAtlas
																										// spriteSheet)
																										// {

		this.inShop = false;
		this.foodLevel = 10;
		this.aggression = 0;
		this.canDrive = false;
		this.bePet = false;
		this.inVehicle = false;
		this.speechBubble = null;
		this.worldMap = worldMap;
		this.x = x;
		this.y = y;
		this.animStart = animStart;
		this.frameCount = frameCount;
		this.camera = camera;
		pixmap = createProceduralPixmap(16, 2, 0, 1, 0);
		pixmap2 = createProceduralPixmap(16, 2, 1, 0, 0);

		healthTexture = new Texture(pixmap);
		healthTexture2 = new Texture(pixmap2);

		ray = new Line(0, 0, worldMap); // 1000,1000 not needed anymore
		// ray.Initalise();

		this.age = 0.1;  // when creature generated, it starts at 0.1 day old
	//	lineRenderer = new ShapeRenderer();

	}

	public void load(String textureFile, int cols, int rows, boolean bNewFile, String name) {

		//this.batch = new SpriteBatch();

		stateTime = this.animStart;

		badGuySprites = BadGuyOutsideManager.getSprites(name);

	}

	abstract public void jump();

	abstract public void move(float x, float y, Camera camera);

	abstract public boolean checkCollision(float x, float y, Camera camera);

	public abstract void attack();

	public void decreaseHealth(float amount) {
		this.health -= amount;
	}

	public void spawn(int x, int y) {
	}

	// bx,by is the bad guy position
	public boolean castRay(int bx, int by, Vector3 pos) { // VIP than the Vector
															// is updated every
															// frame

		//pos = Sterria.camera.position;
		by += 16;
		// check if in range to do a ray cast
		if ((Math.abs(pos.x - bx) > 500) || (Math.abs(pos.y - by) > 400))
			return false;

		// Cast ray into map array from alien position to player position x0,y0
		// to x1,y1

		if ((bx > pos.x && bRight) || (bx < pos.x && !bRight)) {
			int bbx = bx / 16; // convert to map/array space
			int bby = (by+16) / 16;

			boolean bSee = ray.RayCast(bbx, bby, (int) (pos.x) / 16, (int) (pos.y) / 16);
			{

			/*	 Gdx.gl20.glLineWidth(1);
				 lineRenderer.setProjectionMatrix(camera.combined);
				 lineRenderer.begin(ShapeType.Line);
				 lineRenderer.setColor(Color.WHITE); lineRenderer.line(bx, by,
				 ray.getCollisionX()*16,ray.getCollisionY()*16);//
				 //camera.position.x, camera.position.y);
				 lineRenderer.end();*/

			}
			if (bSee) {
				return true;
			}
		}
		return false;
		// ray.Debug();
	}

	public void render(SpriteBatch batch,  CopyOnWriteArrayList<BadGuy> badGuys) {

		if(this.inVehicle)
		{
			return; // if in a vehicle we do not want to draw the bad guy/creature - we need to draw the vehicle instead
		}

		if(this.inShop) // if in a shop, no point drawing here - TODO, need to draw in shop
		{
			return;
		}
		Color c = batch.getColor();
		if (badGuySprites != null) {
			float dt = Gdx.graphics.getDeltaTime();
			//if(this.isIdle())
			{
				animationElapsed += dt;
				while (animationElapsed > frameLength) {
					animationElapsed -= frameLength;
					spriteCurrentFrame = (spriteCurrentFrame == badGuySprites.size - 1) ? 0 : ++spriteCurrentFrame;
				}
			}
			
			Sprite s = badGuySprites.get(spriteCurrentFrame);
			if (s != null) {
				float colour = worldMap.getBlockColor(new Vector3(x,y,0));
				if(colour==-1) colour=1;
				batch.setColor(colour,colour,colour,1);
				batch.draw(s, bRight ? x + 16 : x, y, bRight ? -16 : 16, 16);

				batch.draw(healthTexture2, x, y + 22, 32, 2); // red
				batch.draw(healthTexture, x, y + 22, health, 2);

				if(this.speechBubble!=null)
					speechBubble.draw();
				// If a sentry cop it could be firing at the player
				if(this instanceof SentryCop)
				{
					batch.setColor(1,1,1,1);
					((SentryCop) this).fireBullet(batch, badGuys);
				}
			}
		}
		batch.setColor(c);

	}

	public void moveTimeOnInCreaturesLife(CopyOnWriteArrayList<BadGuy> badGuys) {
		float dt = Gdx.graphics.getDeltaTime();
		dayCycle += dt * 2;
		if(dayCycle >= 24)  // this value needs to be looked at to match night cycle
  		{
			this.increaseAge();
			dayCycle = 0;
			if(this.getAge()>=ageToLiveTo) {
				badGuys.remove(this);
			}
		}

	}
	public Array<Sprite> getBadGuySprites() {
		return badGuySprites;
	}

	public void setBadGuySprites(Array<Sprite> badGuySprites) {
		this.badGuySprites = badGuySprites;
	}

	public TextureAtlas getSpriteSheet() {
		return spriteSheet;
	}

	public void setSpriteSheet(TextureAtlas spriteSheet) {
		this.spriteSheet = spriteSheet;
	}

}
