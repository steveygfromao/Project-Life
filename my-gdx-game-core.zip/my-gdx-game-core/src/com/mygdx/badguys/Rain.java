package com.mygdx.badguys;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.WorldMap;

public class Rain extends WeatherElement implements IWeatherElement {

	static Random r;
	static float height;

	static {
		height = Gdx.graphics.getHeight();
		r = new Random();
	}

	public Rain(Camera camera, WorldMap worldMap, float x, float y, float velocity, float scale, float angle,
			float tint) {
		super(camera, worldMap, x, y, velocity, scale, angle, tint);
	}

	@Override
	public String toString() {
		return "Rain:" + x + "," + y;
	}

	@Override
	public void move() {
		// System.out.println("Move rain : " + x +"," + y);
		if (this.y >= Gdx.graphics.getHeight()) {
			this.y = r.nextInt(100) - 200;
			this.velocity = r.nextInt(20) + 4;
			this.x = r.nextInt(Gdx.graphics.getWidth());
		} else {
			this.y += velocity;
		}
	}
}
/*
 * @Override public void move() { // System.out.println("Move rain : " + x +","
 * + y); Vector3 rainPos = new Vector3(this.x, height - this.y, 0);
 * 
 * // camera.unproject(rainPos); int squareX = (int) x;// rainPos.x; int squareY
 * = (int) y;// rainPos.y; squareX -= squareX % 16; squareY -= squareY % 16;
 * 
 * if (!this.worldMap.checkCollisionWithGrass(new Vector3(squareX, squareY, 0)))
 * // collision { this.y = (WorldMap.h * 16) + r.nextInt(1000); // this.x =
 * r.nextInt(Gdx.graphics.getWidth()); this.velocity = r.nextInt(20) + 4; } else
 * {
 * 
 * if (this.y <= 200) this.y = (WorldMap.h * 16) + r.nextInt(1000); else {
 * this.y -= velocity; //this.x += 0.7f; }
 * 
 * // render(batch, sprite);
 * 
 * } }
 */
