package com.mygdx.badguys;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public interface IWeatherElement {

	void move();
//	void render(SpriteBatch batch, TextureRegion[][] sprite, int offset);
	void render(SpriteBatch batch, Sprite s, int xOffset);
}
