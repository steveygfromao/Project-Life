package com.mygdx.badguys;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.mygdx.game.Collision;

// Baddy manager v1.0
// Renders baddies above ground etc...

public class BadGuyOutsideManager {

	private static TextureAtlas spriteSheet = null;

	static TextureRegion[][] speechRegions = null;
	Texture speechTexture = null;

	// Store baddies in here
	private CopyOnWriteArrayList<BadGuy> badGuys;

	private int width, height;

	private static HashMap<String, Array<Sprite>> allSprites = new HashMap<String,Array<Sprite>>();

	public BadGuyOutsideManager() {

		this.speechTexture = new Texture("../my-gdx-game-core/assets/speech.png");
		speechRegions = TextureRegion.split(this.speechTexture, 80, 80);

		setSpriteSheet(new TextureAtlas("../my-gdx-game-core/assets/spritesplanetone.txt"));   // load sprite

		// Load all sprite regions and store in hash map
		Array<AtlasRegion> allRegions = spriteSheet.getRegions();
		for(AtlasRegion region : allRegions) {
			Array<Sprite> sprites = spriteSheet.createSprites(region.name);
			allSprites.put(region.name, sprites);
		}

		badGuys = new CopyOnWriteArrayList<BadGuy>(); // thread safe arraylist

		width = Gdx.graphics.getWidth() / 2; // get screen width and height
												// (used for frustum culling in
												// renderBadGuys method)
		height = Gdx.graphics.getHeight() / 2;

	}

	public static Array<Sprite>getSprites(String name) {
		return(allSprites.get(name));
	}

	public void addBadGuy(int x, int y, BadGuy badGuy) {
		badGuy.bRight = new Random().nextBoolean();
		badGuy.xDir = badGuy.bRight ? -badGuy.speed : badGuy.speed;
		badGuys.add(badGuy);

	}

	public void renderBadGuys(Camera camera, SpriteBatch batch) {

		for (int i = 0; i < badGuys.size(); i++) {
			BadGuy badguy = badGuys.get(i);
			badguy.batch = batch;
			if(badguy!=null)
			{
				if (badguy.health <= 0) // if bad guy dead, remove them from the
										// list
					removeBadGuy(badguy);
				else {

					badguy.move(badguy.x, badguy.y, camera);  // we move the bad guy even if we cannot see them (For optimization maybe should have a distance check,
															  // as creatures that are miles away not much point in moving them really...

				//	if ((badguy.x >= camera.position.x - (width + 800) && badguy.x <= camera.position.x + width + 700)
				//			&& (badguy.y >= camera.position.y - (height+800) && badguy.y <= camera.position.y + (height + 700))) {

					badguy.moveTimeOnInCreaturesLife(this.badGuys);  // we move time on in the life of the creature even if we cannot see it :-) Bug fix - 13/11/2016 SDG
				//	}

					// Only draw outside baddies that are in the camera's view
					if ((badguy.x >= camera.position.x - (width + 20) && badguy.x <= camera.position.x + width + 10)
							&& (badguy.y >= camera.position.y - height && badguy.y <= camera.position.y + height)) {

						badguy.render(batch, this.badGuys);


					}
				}
			}
		}
	}

	public BadGuy didWeHitABadGuy(Vector3 camera) {
		for (int i = 0; i < badGuys.size(); i++) {
			BadGuy badguy = badGuys.get(i);

			// Only check collision with bad guys who are in view
			if ((badguy.x >= camera.x - (width + 30) && badguy.x <= camera.x + width + 10)
					&& (badguy.y >= camera.y - height && badguy.y <= camera.y + height)) {
				if(checkCollision(badguy.x, badguy.y, camera))
				{
					return badguy;
				}
			}
		}
		return null;
	}

	// Test if clicked on a creature/bad guy, if so, we return this creature object
	public BadGuy badGuyInformation(Vector3 camera, float x1, float y1) {
		Vector3 cam = new Vector3(x1,y1,0);
		for (int i = 0; i < badGuys.size(); i++) {
			BadGuy badguy = badGuys.get(i);

			// Only check collision with bad guys who are in view
			if ((badguy.x >= camera.x - (width + 30) && badguy.x <= camera.x + width + 10)
					&& (badguy.y >= camera.y - height && badguy.y <= camera.y + height)) {

				if(checkCollision(badguy.x, badguy.y, cam))
				{
					return badguy;
				}
			}
		}
		return null;
	}

	public boolean checkCollision(float x, float y, Vector3 cam) {
		// TODO Auto-generated method stub
		return Collision.intersectorCollision(x, y, 16, 16, cam.x, cam.y, 16, 16);
	}

	public void removeBadGuy(BadGuy badGuy) {
		badGuys.remove(badGuy);
	}

	public static TextureAtlas getSpriteSheet() {
		return spriteSheet;
	}

	public static void setSpriteSheet(TextureAtlas spriteSheet) {
		BadGuyOutsideManager.spriteSheet = spriteSheet;
	}
}
