package com.mygdx.badguys;

import com.badlogic.gdx.graphics.Camera;
import com.mygdx.badguys.BadGuy.State;
import com.mygdx.game.WorldMap;


public class Sheep extends Pig {//BadGuy {

	public Sheep(float x, float y, int animStart, int frameCount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameCount, camera, worldMap);
		health = 6;
		currentState = State.WALK;
		this.setSpeed(0.5f);

	}

	
	@Override
	public void attack() {
	}

}
