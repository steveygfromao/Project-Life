package com.mygdx.badguys;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.Buildings.BuildingManager;
import com.mygdx.Buildings.PetShop;
import com.mygdx.Buildings.Shop;
import com.mygdx.game.Collision;
import com.mygdx.game.WorldMap;

public class Pig extends BadGuy {

	static final int SPEECHDELAY = 15; // minimum delay before next possible
										// speech bubble
	Shop s = null;
	float txDir = 0;
	float velocity = -1.0f;
	float jumpForce = 1;
	boolean jump = false;
	long timeWait = 0;
	boolean tbRight;
	Random r = new Random();
	private int moved = 0;

	private static final int CHANGEDELAY = 20;
	
	protected long delay;
	protected long nextSpeech = 0;

	protected long howLongBeforeSwitch = 0;
	
	public void setSpeed(float speed) {
		this.speed = speed;
		this.xDir = -speed;
	}

	public Pig(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 8;
		currentState = State.WALK;
		this.setSpeed(1.0f);
		this.howLongBeforeSwitch = System.currentTimeMillis() + CHANGEDELAY * 1000;
	}

	@Override
	public void move(float x, float y, Camera camera) {

		if(System.currentTimeMillis() >= this.howLongBeforeSwitch && currentState!=State.IDLE && currentState!=State.INSHOP)
		{
	/*		if(r.nextInt(10)>3 && yDir==0 )
			{
				this.timeWait = System.currentTimeMillis() + r.nextInt(6) * 1000;
				currentState = State.IDLE;
			}
			else
			{*/
			//	currentState = State.WALK;
				bRight = r.nextBoolean();
				if(bRight) xDir=-speed; 
				else
					xDir = speed;
				this.howLongBeforeSwitch = System.currentTimeMillis() + r.nextInt(CHANGEDELAY) * 1000;
			}
		//}
		//else
			//currentState = State.WALK;
		switch (currentState) {
		case INSHOP:

			if (this.inShop) // if shop closed kick the creatures out
			{
				if (BuildingManager.getHours() >= s.getTimeOpen() && BuildingManager.getHours() < s.getTimeClose()) {
					// shop is open, we need to stay in for a period of time
					// then leave
					if (System.currentTimeMillis() > delay) {
						this.inShop = false;
						currentState = State.WALK;
						this.xDir = r.nextBoolean() ? this.speed : -this.speed;
						this.bRight = this.xDir < 0 ? true : false;
						s.removeOccupant(this);
						nextSpeech = System.currentTimeMillis() + (r.nextInt(30) + SPEECHDELAY) * 1000;
						break;
					}
				} else // shop closed now
				{
					this.inShop = false;
					currentState = State.WALK;
					this.xDir = r.nextBoolean() ? this.speed : -this.speed;
					this.bRight = this.xDir < 0 ? true : false;
					s.removeOccupant(this);
					nextSpeech = System.currentTimeMillis() + (r.nextInt(30) + SPEECHDELAY) * 1000; // delay
																									// of
																									// 15
																									// seconds
																									// before
																									// next
																									// possible
																									// speech
					break;
				}
			} else {
				if (!(s instanceof PetShop)) {
					if (r.nextInt(10) > 2) // possibly need look at type of
											// shop, if
											// need food etc...
					{
						s.addOccupant(this); // add creature to shop occupants
												// list
						this.inShop = true;
					} else {
						nextSpeech = System.currentTimeMillis() + (r.nextInt(30) + SPEECHDELAY) * 1000;
						currentState = State.WALK;
					}
				}
				else
					currentState = State.WALK;
			}
			break;
		case IDLE:
			idle();
			break;
		case WALK:
			s = worldMap.collisionWithShop(this); // see if walking past a shop
			if (s != null && System.currentTimeMillis() > nextSpeech) {

				if (BuildingManager.getHours() >= s.getTimeOpen() && BuildingManager.getHours() < s.getTimeClose()) {
					// Open
					if (this.speechBubble == null) {
						String text = s.getClass().getSimpleName() + " is open";
						// create a speech bubble
						this.speechBubble = new SpeechBubble(this, this.batch, BadGuyOutsideManager.speechRegions,
								text);

					}
					if (speechBubble.isFinished()) {
						this.delay = System.currentTimeMillis() + 5 * 1000; // stay
																			// for
																			// five
																			// seconds
																			// in
																			// shop

						currentState = State.INSHOP;
					}
				}
			} else { // no collision
				this.speechBubble = null;
			}

			txDir = xDir;
			tbRight = bRight;
			// Need to move pig left/right
			// Collision on right?
			if (!worldMap.checkCollisionRounded(new Vector3(x - 4, y-2, 0), this)) {
				if (r.nextInt(3) < 1) {
					xDir = speed;
					bRight = false;
				} 
				else // if (yDir == 0) // no jumping if not on ground
				{
					if(yDir==0) // on the ground
						currentState = State.JUMP;
					else
					{
						xDir = speed;
						bRight = false;
					}
				}
			} else {
				if (!worldMap.checkCollisionRounded(new Vector3(x + 4, y-2, 0), this)) {
					if (r.nextInt(3) < 1) {
						xDir = -speed;
						bRight = true;
					} 
					else
					{
						if (yDir == 0) // no jumping if not on ground
						{
							currentState = State.JUMP;
						}
						else
						{
							xDir =-speed;
							bRight = true;
						}
					}
				} 
				else {
						// no action needed
				}
			}
			Vector3 pos = new Vector3(x, y - 12, 0);
			if (this.worldMap.checkCollisionRounded(pos)) // collision
			{
				yDir = velocity; // Falling down
				velocity -= 0.2f;
			} else {
				yDir = 0;
				velocity = -0.5f;
			}
			this.x += xDir;
			this.y += yDir;
			// Is this creature being shot???
			if (this.shootAt) {
				this.x += (bRight ? -0.5 : 0.5); // the creature will run when
													// being shot at...
			}
			break;
		case JUMP:

			jump();
			break;
		default:
			break;
		}
	}

	@Override
	public void attack() {
		System.out.println(this.getClass().getName() + " attack");
	}

	public void jump() {
		if (!jump) {
			jump = true;
			jumpForce = 2.1f;
		}
		if (jumpForce < 0) // coming down
		{
			Vector3 poss = new Vector3(x, y - 12, 0);
			if (!this.worldMap.checkCollisionRounded(poss)) // collision
			{
	//			if(r.nextBoolean())
					currentState = State.WALK;
		/*		else
				{
					this.bAnimating = false;
					timeWait = (long) (System.currentTimeMillis() + (r.nextInt(10)+2)*1000);  // 3 seconds to appear for
					currentState = State.IDLE;
					
				}*/
				jump = false;
			}
		}

		if (jumpForce > -2.1f) {
			if (!worldMap.checkCollisionRounded(new Vector3(x, y + 16, 0), this)) {
				jumpForce = 0;
				currentState = State.WALK;
			}

			if (!worldMap.checkCollisionRounded(new Vector3(x - 4, y, 0), this)) {// collision
																					// on
																					// left
				// x+=2;
				xDir = 0;
			} else
				xDir = bRight == !true ? speed : -speed;
			if (!worldMap.checkCollisionRounded(new Vector3(x + 4, y, 0), this)) // collision
																					// on
																					// left
			{
				// x-=2;
				xDir = 0;
			} else
				xDir = bRight == !true ? speed : -speed;

			jumpForce -= .05;
		} else {
			jump = false;
			jumpForce = 0;
			currentState = State.WALK;
		}
		if (currentState == State.JUMP)
			if (jump) {
				this.x += xDir;// / 2;
				this.y += jumpForce;
			}
	}

	public void chaneStateWhenBeingAttacked(State state) {
		currentState = state;
	}

	private void idle() {
		if(System.currentTimeMillis() < timeWait)  // draw for a certain time period
		{
			bAnimating = false;
		}
		else
		{
			this.howLongBeforeSwitch = System.currentTimeMillis() + r.nextInt(6) * 1000;
			bAnimating = true;
			currentState = State.WALK;
		}
		
	}

	@Override
	public boolean checkCollision(float x, float y, Camera camera) {
		return Collision.intersectorCollision(x, y, 16, 16, camera.position.x, camera.position.y, 16, 48);
	}
}
