package com.mygdx.badguys;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.Sterria;
import com.mygdx.game.WorldMap;

public class Crocodile extends Pig {
	public Crocodile(float x, float y, int animStart, int frameAmount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameAmount, camera, worldMap);
		health = 32;
		currentState = State.WALK;
		this.setSpeed(0.4f);
		this.setAggression(30);
	}

	@Override
	public void attack() {
	//	System.out.println(this.getClass().getName() + " attack");
	}

	@Override
	public void move(float x, float y, Camera camera) {

		switch (currentState) {

		case WALK:
//			System.out.println("WALK");
		// if (this.castRay((int) x, (int) y, Sterria.camera.position))//
		// camera.position))
		// //
		// can
		// we
		// see
		// the
		// player
		{
			// this.x += xDir * (aggression/1.5); // we really need to keep
			// heading towards the player...
		}
			double xDist = Math.sqrt(Math.abs(this.x - camera.position.x) * Math.abs(this.x - camera.position.x));
			double yDist = Math.sqrt(Math.abs(this.y - camera.position.y) * Math.abs(this.y - camera.position.y));
			if (xDist < 10 && yDist < 10) {
				currentState = State.ATTACK;
				break;
			}
			// Below allows creature to follow player, but line of sight seems
			// better

			if (this.health > 5) {
				if (Math.abs(camera.position.y - this.y) < 80 + aggression) {

					if (Sterria.camera.position.x > this.x) {
						if (camera.position.x - this.x < 200 + aggression) {
							currentState = State.CHASERIGHT;
							bRight = false;
							// System.out.println("State to chaseright");
							// System.out.println(camera.position.x +":" + x);
							// break;
						}
					} else {
						if (Sterria.camera.position.x < this.x) {
							if (this.x - camera.position.x < 200 + aggression) {
								currentState = State.CHASELEFT;
								bRight = true;
								// System.out.println("State to chaseleft");
								// System.out.println(camera.position.x +":" +
								// x);
								// break;
							}
						}
					}
				}
			}
			if (!this.checkColls()) {
				this.x += xDir;
			}
			// if(this.checkColls())
			// {
			this.y += yDir;
			// }
			break;

		case CHASELEFT:
			if (!this.checkColls()) {

				xDir = -speed;

				this.x += xDir * (this.speed * 12); // we really need to keep
													// heading towards the
			} // player...
			currentState = State.WALK;
			break;

		case CHASERIGHT:
			if (!this.checkColls()) {

				xDir = speed;

				this.x += xDir * (this.speed * 12); // we really need to keep
													// heading towards the
			} // player...
			currentState = State.WALK;
			break;

		case JUMP:
			jump();
			break;

		case ATTACK:
			if (this.health < 5) {
				currentState = State.WALK;
			}
			System.out.println("ATTACK");
			xDist = Math.sqrt(Math.abs(this.x - camera.position.x) * Math.abs(this.x - camera.position.x));
			yDist = Math.sqrt(Math.abs(this.y - camera.position.y) * Math.abs(this.y - camera.position.y));
			if (xDist < 10 && yDist < 10) // these could be values passed in or
											// we can use aggression value???
			{
				Vector3 pos = new Vector3(x, y - 4, 0);
				/*
				 * if (this.worldMap.checkCollisionRounded(pos)) // collision {
				 * yDir = velocity; // Falling down velocity -= 0.2f; } else {
				 * yDir = 0; velocity = -0.5f; }
				 */
			} else
				currentState = State.WALK;
			break;
		default:
			break;
		}
	}

	private boolean checkColls() {

		// Rectangle r1 = new Rectangle(x,y,16,16);
		// worldMap.checkRectCollision(r1, new Vector3(x,y,0));

		if (!worldMap.checkCollisionRounded(new Vector3(x - 4, y, 0))) { // collision
																			// on
																			// left
			if (r.nextInt(3) < 1) {
				if (currentState == State.WALK || currentState == State.CHASELEFT)
					xDir = speed; // go the other way now
				bRight = false;
				if (!worldMap.checkCollisionRounded(new Vector3(x - 2, y, 0))) { // collision
					x += 2;
					return true;
				}
			} else {
				if (yDir == 0) {
					currentState = State.JUMP;
					return true;
				}

			}
		} else {
			if (!worldMap.checkCollisionRounded(new Vector3(x + 4, y, 0))) {
				if (r.nextInt(3) < 1) {
					if (currentState == State.WALK || currentState == State.CHASERIGHT)
						xDir = -speed; // go the other way now
					bRight = true;
					if (!worldMap.checkCollisionRounded(new Vector3(x + 2, y, 0))) {
						x -= 2;
						return true;
					}
				} else {
					if (yDir == 0) {
						currentState = State.JUMP;
						return true;
					}
				}

			}
		}
		Vector3 pos = new Vector3(x, y - 4, 0);
		Vector3 pos2 = new Vector3(x, y - 8, 0);

		if (this.worldMap.checkCollisionRounded(pos) || (this.worldMap.checkCollision(pos2))) // collision
		{
			pos.y -= 1;
			pos2.y -= 1;
			if (this.worldMap.checkCollisionRounded(pos) || (this.worldMap.checkCollision(pos2))) // collision
			{
				yDir = velocity; // Falling down
				velocity -= 0.1f;
				return true;
			}
		} else {
			yDir = 0;
			velocity = -0.5f;
			return false;
		}

		return false;
	}
}
