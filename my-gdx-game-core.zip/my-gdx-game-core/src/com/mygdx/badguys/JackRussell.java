package com.mygdx.badguys;

import com.badlogic.gdx.graphics.Camera;
import com.mygdx.game.Sterria;
import com.mygdx.game.WorldMap;


public class JackRussell extends Pig { //BadGuy{

	public JackRussell(float x, float y, int animStart, int frameCount, Camera camera, WorldMap worldMap) {
		super(x, y, animStart, frameCount, camera, worldMap);
		health = 10;
		this.setSpeed(0.7f);
	}

	
	@Override
	public void attack() {
	}
}
