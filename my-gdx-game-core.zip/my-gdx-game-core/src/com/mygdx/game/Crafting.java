package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Crafting  {
	private static Sprite inventory;
	private static float xPos,yPos;
	
	public static void initialise(String file, float x, float y)
	{
		xPos = x;
		yPos = y;
		
		inventory = new Sprite(new Texture(file));
		
	}
	
	public static void draw(SpriteBatch batch)
	{
		inventory.setPosition(xPos, yPos);// - hudSprite.getHeight() - 20);
	    inventory.draw(batch);

	}

}
