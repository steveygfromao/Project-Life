package com.mygdx.game;

import java.util.ArrayList;
import java.util.HashMap;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class InventoryManager {

	private HashMap<String, ArrayList<InventoryAbstractSlot>> inventoryList = new HashMap<>();

	public HashMap<String, ArrayList<InventoryAbstractSlot>> getInventoryList() {
		return inventoryList;
	}

	public void setInventoryList(HashMap<String, ArrayList<InventoryAbstractSlot>> inventoryList) {
		this.inventoryList = inventoryList;
	}

	private TextureRegion[][] region;

	// Start items - tab one
	private LandscapeEntity[] tabThree = { new OpazEntity(0, 0), /*new PickAxeEntity(0, 0), new AxeEntity(0, 0),*/
			new MaterialCastleBrick(0, 0), new BasicWoodenEntity(0, 0), new GreyRockEntity(0, 0), new RubyEntity(0, 0),
			new PlatinumRockEntity(0, 0), new WindowLeftEntity(0, 0), new WindowRightEntity(0, 0),
			new WindowTopEntity(0, 0), new WindowBottomEntity(0, 0), new DirtBlockEntity(0, 0),
			new ConcreteOneBlockEntity(0, 0), new ConcreteTwoBlockEntity(0, 0), new ConcreteThreeBlockEntity(0, 0),
			new ConcreteFourBlockEntity(0, 0), new ConcreteFiveBlockEntity(0, 0), new ConcreteSixBlockEntity(0, 0),
			new Block69Entity(0, 0), new Block611Entity(0, 0), new Block612Entity(0, 0), new Block613Entity(0, 0),
			new Block614Entity(0, 0), new Block615Entity(0, 0), new Block616Entity(0, 0), new Block617Entity(0, 0),
			new Block618Entity(0, 0), new Block619Entity(0, 0), new Block620Entity(0, 0), new Block621Entity(0, 0),
			new Block622Entity(0, 0), new Block623Entity(0, 0), new Block624Entity(0, 0), new Block625Entity(0, 0),
			new Block626Entity(0, 0), new Block627Entity(0, 0), new Block628Entity(0, 0), new Block629Entity(0, 0),
			new Block630Entity(0, 0), new Block631Entity(0, 0), new Block632Entity(0, 0), new Block633Entity(0, 0),
			new Block634Entity(0, 0), new Block635Entity(0, 0), new Block636Entity(0, 0), new Block708Entity(0, 0),
			new Block709Entity(0, 0), new Block710Entity(0, 0), new Block711Entity(0, 0), new Block712Entity(0, 0),
			new Block713Entity(0, 0), new Block714Entity(0, 0), new Block715Entity(0, 0), new Block716Entity(0, 0),
			new Block717Entity(0, 0), new Block718Entity(0, 0), new Block719Entity(0, 0), new Block720Entity(0, 0),
			new Block721Entity(0, 0), new Block722Entity(0, 0), new Block723Entity(0, 0), new Block724Entity(0, 0),
			new Block725Entity(0, 0), new Block726Entity(0, 0), new Block727Entity(0, 0), new Block728Entity(0, 0),
			new Block729Entity(0, 0), new Block801Entity(0, 0), new Block802Entity(0, 0), new Block803Entity(0, 0),
			new Block804Entity(0, 0), new Block805Entity(0, 0), new Block806Entity(0, 0), new Block807Entity(0, 0),
			new Block808Entity(0, 0), new Block809Entity(0, 0), new Block810Entity(0, 0), new Block811Entity(0, 0),
			new Block812Entity(0, 0), new Block813Entity(0, 0), new Block814Entity(0, 0), new Block815Entity(0, 0),
			new Block816Entity(0, 0), new Block817Entity(0, 0), new Block818Entity(0, 0), new Block819Entity(0, 0),
			new Block820Entity(0, 0), new Block821Entity(0, 0), new Block822Entity(0, 0), new Block823Entity(0, 0),
			new Block824Entity(0, 0), new Block825Entity(0, 0), new Block826Entity(0, 0), new Block827Entity(0, 0),
			new Block828Entity(0, 0), new Block829Entity(0, 0), new Block830Entity(0, 0), new Block831Entity(0, 0),
			new Block832Entity(0, 0), new Block833Entity(0, 0), new Block834Entity(0, 0), new Block835Entity(0, 0),
			new Block836Entity(0, 0), new Block837Entity(0, 0), new Block838Entity(0, 0), new Block839Entity(0, 0),
			new Block014Entity(0,0),new Block015Entity(0,0),new Block016Entity(0,0),new Block017Entity(0,0),
			new Block018Entity(0,0),new Block019Entity(0,0),new Block020Entity(0,0),new Block021Entity(0,0),
			new Block022Entity(0,0),new Block023Entity(0,0),new Block024Entity(0,0),new Block025Entity(0,0),
			new Block026Entity(0,0),new Block027Entity(0,0),new Block028Entity(0,0),new Block029Entity(0,0),
			new Block030Entity(0,0),new Block031Entity(0,0),new Block032Entity(0,0),new Block033Entity(0,0),
			new Block034Entity(0,0),new Block035Entity(0,0),new Block036Entity(0,0),new Block037Entity(0,0),
			new Block038Entity(0,0),new Block039Entity(0,0),

			new Block114Entity(0,0),new Block115Entity(0,0),new Block116Entity(0,0),new Block117Entity(0,0),
			new Block118Entity(0,0),new Block119Entity(0,0),new Block120Entity(0,0),new Block121Entity(0,0),
			new Block122Entity(0,0),new Block123Entity(0,0),new Block124Entity(0,0),new Block125Entity(0,0),
			new Block126Entity(0,0),new Block127Entity(0,0),new Block128Entity(0,0),new Block129Entity(0,0),
			new Block130Entity(0,0),new Block131Entity(0,0),new Block132Entity(0,0),new Block133Entity(0,0),
			new Block134Entity(0,0),new Block135Entity(0,0),new Block136Entity(0,0),new Block137Entity(0,0),
			new Block138Entity(0,0),new Block139Entity(0,0),

			new Block214Entity(0,0),new Block215Entity(0,0),new Block216Entity(0,0),new Block217Entity(0,0),
			new Block730Entity(0,0),
			

	};

	private LandscapeEntity[] tabFive = { new FoxEntity900(0, 0), new PigEntity901(0, 0), new RhinoEntity902(0, 0),
			new DuckEntity903(0, 0), new BearEntity904(0, 0), new ElephantEntity905(0, 0), new CrocodileEntity906(0, 0),
			new BrainaEntity907(0, 0), new HippoEntity908(0, 0), new HorseEntity909(0, 0), new KoalaEntity910(0, 0),
			new LionEntity911(0, 0), new MonkeyEntity912(0, 0), new MooseEntity913(0, 0), new PandaEntity914(0, 0),
			new ParrotEntity915(0, 0), new PenguinEntity916(0, 0), new PolarBearEntity917(0, 0),
			new SharkEntity918(0, 0), new SnowOwlEntity919(0, 0), new TigerEntity920(0, 0), new WalrusEntity921(0, 0),
			new WolfEntity922(0, 0), new ZombieEntity923(0, 0), new TentacleAEntity924(0, 0),
			new TentacleBEntity925(0, 0), new SquirrelEntity926(0, 0), new SphereBEntity927(0, 0),
			new SphereAEntity928(0, 0), new SnakeEntity929(0, 0), new SlimeEntity930(0, 0), new SlimeEntity931(0, 0),
			new SlimeEntity932(0, 0), new SlimeEntity933(0, 0), new SkullFlameEntity934(0, 0),
			new SkullFlameEntity935(0, 0), new SkullEntity936(0, 0), new SkullEntity937(0, 0), new SkullEntity938(0, 0),
			new SkullEntity939(0, 0), new SkeletonEntity1000(0, 0), new SheepEntity1001(0, 0),
			new SentryCopEntity1002(0, 0), new SentryCopEntity1003(0, 0), new SentryEntity1004(0, 0),
			new RobotEntity1005(0, 0), new RobotEntity1006(0, 0), new PuddleEntity1007(0, 0),
			new PuddleEntity1008(0, 0), new PotionEntity1009(0, 0), new PotionEntity1010(0, 0),
			new PotionEntity1011(0, 0), new PotionEntity1012(0, 0), new PotionEntity1013(0, 0),
			new PotionEntity1014(0, 0), new OrbEntity1015(0, 0), new OrbEntity1016(0, 0), new MushroomEntity1017(0, 0),
			new MushroomEntity1018(0, 0), new MummyEntity1019(0, 0), new MonolithEntity1020(0, 0),
			new MonolithEntity1021(0, 0), new MaskEntity1022(0, 0), new LurkerEntity1023(0, 0),
			new KlakonEntity1024(0, 0), new HeadEntity1025(0, 0), new HeadEntity1026(0, 0), new HeadEntity1027(0, 0),
			new HeadEntity1028(0, 0), new GhostEntity1029(0, 0), new GhostEntity1030(0, 0), new GhostEntity1031(0, 0),
			new FireEntity1032(0,0), new DyeEntity1033(0,0), new DwarfEntity1034(0,0), new DuckEntity1035(0,0),
			new DogEntity1036(0,0), new CrabEntity1037(0,0), new ChickenEntity1038(0,0),new ChickenEntity1039(0,0),new ChickenEntity1100(0,0),
			new CatEntity1101(0,0), new BatEntity1102(0,0), new BallEntity1103(0,0), new HumanOneEntity1104(0,0),
			new HumanOneEntity1105(0,0),new HumanOneEntity1106(0,0),new HumanOneEntity1107(0,0),new HumanOneEntity1108(0,0),
			new HumanOneEntity1109(0,0),new HumanOneEntity1110(0,0),new HumanOneEntity1111(0,0),new HumanOneEntity1112(0,0),
			new HumanOneEntity1113(0,0),new HumanOneEntity1114(0,0),new HumanOneEntity1115(0,0),new HumanOneEntity1116(0,0),
	};

	// Digging
	private LandscapeEntity[] tabOne = { new PickAxeEntity(0, 0) };

	// Weapons
	private LandscapeEntity[] tabTwo = { new AxeEntity(0, 0), new StaffEntity(0,0), new ClubEntity(0,0),new SickleEntity(0,0),
									     new HookedStaffEntity(0,0), new SwordEntity(0,0), new GoldSwordEntity(0,0),
									     new MaceEntity(0,0), new LongBowEntity(0,0), new BlueSwordEntity(0,0),
									     new ShortBowEntity(0,0)};
	
	// Decorations
	private LandscapeEntity[] tabFour = { new JugEntity(0, 0),new JugEntity2(0, 0),new JugMiniEntity(0, 0),new JugMiniEntity2(0, 0), new SkullEntity(0,0),
										  new RagEntity(0, 0), new LightEntity(0,0),new BlueLightEntity(0,0),new GreenLightEntity(0,0),new CyanLightEntity(0,0),
										 };
	

	private LandscapeEntity[] tabSix = { new Block1300Entity(0, 0), new Block1301Entity(0,0),new Block1400Entity(0,0), new Block1401Entity(0,0),
			new Block1302Entity(0, 0), new Block1303Entity(0,0),new Block1402Entity(0,0), new Block1403Entity(0,0),
			new Block1304Entity(0, 0), new Block1305Entity(0,0),new Block1404Entity(0,0), new Block1405Entity(0,0),
			new Block1306Entity(0, 0), new Block1307Entity(0,0),new Block1406Entity(0,0), new Block1407Entity(0,0),
			new Block1308Entity(0, 0), new Block1309Entity(0,0),new Block1408Entity(0,0), new Block1409Entity(0,0),
			new Block1310Entity(0, 0), new Block1311Entity(0,0),new Block1410Entity(0,0), new Block1411Entity(0,0),
			new Block1312Entity(0, 0), new Block1313Entity(0,0),new Block1412Entity(0,0), new Block1413Entity(0,0),
			new Block1314Entity(0, 0), new Block1315Entity(0,0),new Block1414Entity(0,0), new Block1415Entity(0,0),
			new Block1316Entity(0, 0), new Block1317Entity(0,0),new Block1416Entity(0,0), new Block1417Entity(0,0),
			new Block1318Entity(0, 0), new Block1319Entity(0,0),new Block1418Entity(0,0), new Block1419Entity(0,0),
			new Block1320Entity(0, 0), new Block1321Entity(0,0),new Block1420Entity(0,0), new Block1421Entity(0,0),
			new Block1322Entity(0, 0), new Block1323Entity(0,0),new Block1422Entity(0,0), new Block1423Entity(0,0),
			new Block1324Entity(0, 0), new Block1325Entity(0,0),new Block1424Entity(0,0), new Block1425Entity(0,0),
			new Block1326Entity(0, 0), new Block1327Entity(0,0),new Block1426Entity(0,0), new Block1427Entity(0,0),
			new Block1328Entity(0, 0), new Block1329Entity(0,0),new Block1428Entity(0,0), new Block1429Entity(0,0),
			new Block1330Entity(0, 0), new Block1331Entity(0,0),new Block1430Entity(0,0), new Block1431Entity(0,0),
			new Block1332Entity(0, 0), new Block1333Entity(0,0),new Block1432Entity(0,0), new Block1433Entity(0,0),
			new Block1334Entity(0, 0), new Block1335Entity(0,0),new Block1434Entity(0,0), new Block1435Entity(0,0),
			new Block1336Entity(0, 0), new Block1337Entity(0,0),new Block1436Entity(0,0), new Block1437Entity(0,0),
			new Block1338Entity(0, 0), new Block1339Entity(0,0),new Block1438Entity(0,0), new Block1439Entity(0,0),
			};

	@SuppressWarnings("unchecked")
	ArrayList<InventoryAbstractSlot>[] icons = new ArrayList[6];

	public void resetList() {
		// this.icons.clear();
	}

	public InventoryManager(TextureRegion[][] region) {
		this.region = region;
		for (int i = 0; i < 6; i++)
			icons[i] = new ArrayList<>();
	}

	public void addStartingItems(String tab) {
		int index = 0;
		ArrayList<InventoryAbstractSlot> ic = this.inventoryList.get(tab);
		if (tab.equalsIgnoreCase("tab1")) {

			for (LandscapeEntity t : tabOne) {
				InventoryAbstractSlot slot = ic.get(index);
				slot.item = region[0][0].getTexture();
				slot.type = t;
				index++;
			}
		} else {
			if (tab.equalsIgnoreCase("tab2")) {
				for (LandscapeEntity t : tabTwo) {
					InventoryAbstractSlot slot = ic.get(index);
				//	slot.item = region[0][0].getTexture();
					slot.type = t;
					index++;
				}
			} else {
				if (tab.equalsIgnoreCase("tab3")) {
					for (LandscapeEntity t : tabThree) {
						InventoryAbstractSlot slot = ic.get(index);
					//	slot.item = region[0][0].getTexture();
						slot.type = t;
						index++;
					}
				} else {
					if (tab.equalsIgnoreCase("tab4")) {
						for (LandscapeEntity t : tabFour) {
							InventoryAbstractSlot slot = ic.get(index);
					//		slot.item = region[0][0].getTexture();
							slot.type = t;
							index++;
						}
					} else {
						if (tab.equalsIgnoreCase("tab5")) {
							for (LandscapeEntity t : tabFive) {
								InventoryAbstractSlot slot = ic.get(index);
						//		slot.item = region[0][0].getTexture();
								slot.type = t;
								index++;
							}
						}
						else {
							if (tab.equalsIgnoreCase("tab6")) {
								for(int i=0; i<tabSix.length;i+=4) {
								//for (LandscapeEntity t : tabSix) {
									InventoryAbstractSlot slot = ic.get(index);
									//slot.item = region[0][0].getTexture();
									slot.type = tabSix[i];
									slot.type2 = tabSix[i+1];
									slot.type3 = tabSix[i+2];
									slot.type4 = tabSix[i+3];
									index++;
								}
							}
						}
					}
				}
			}

		}
	}

	public void addIcon(InventoryAbstractSlot icon, int tabIndex) {
		icons[tabIndex].add(icon);
	}

	public void drawIcons(SpriteBatch batch, String tab) {
		ArrayList<InventoryAbstractSlot> icons = this.inventoryList.get(tab);
		for(InventoryAbstractSlot i : icons )
		{
			i.draw(batch, i);
		}
		//icons.forEach(i -> i.draw(batch, i));
	}
}
