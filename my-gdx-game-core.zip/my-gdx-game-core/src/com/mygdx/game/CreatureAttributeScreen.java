package com.mygdx.game;



import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.badguys.BadGuy;

public class CreatureAttributeScreen {

	private Texture creatureAttributes = null;
	private BitmapFont font = null;
	
	public CreatureAttributeScreen()
	{

		if(creatureAttributes == null)
		{
			creatureAttributes = new Texture("../my-gdx-game-core/assets/creatureattributes.png");
		}
		font = new BitmapFont();
		
	}

	
	public void render(SpriteBatch batch, float x, float y, BadGuy bg)
	{
		Color c = batch.getColor();
		batch.setColor(1f, 1f, 1f, 0.5f);
		batch.draw(creatureAttributes, x - creatureAttributes.getWidth()-20, y, 700, 300);
		
		font.getData().scaleX = 2;
		font.draw(batch, "TODO", x - creatureAttributes.getWidth() + 80, y + creatureAttributes.getHeight() - 40);
		font.draw(batch, bg.getClass().getSimpleName(), x - creatureAttributes.getWidth() + 80, y + creatureAttributes.getHeight() - 84);
		if(bg.getHealth()<16)
			font.setColor(Color.RED);
		String strHealth = String.format("%.2f", bg.getHealth());
		font.draw(batch, strHealth, x - creatureAttributes.getWidth() + 90, y + creatureAttributes.getHeight() - 136);
	
		font.setColor(1f,1f,1f,0.5f);
		font.draw(batch, Integer.toString(bg.getAggression()), x - creatureAttributes.getWidth() + 120, y + creatureAttributes.getHeight() - 188);
		font.draw(batch, Float.toString(bg.getSpeed()), x - creatureAttributes.getWidth() + 82, y + creatureAttributes.getHeight() - 242);

		font.draw(batch, "No", x - creatureAttributes.getWidth() + 450, y + creatureAttributes.getHeight() - 40);
		font.draw(batch, "No", x - creatureAttributes.getWidth() + 450, y + creatureAttributes.getHeight() - 84);
		font.draw(batch, "No", x - creatureAttributes.getWidth() + 460, y + creatureAttributes.getHeight() - 134);
		
		String strAge = String.format("%.1f", bg.getAge());
		font.draw(batch, strAge, x - creatureAttributes.getWidth() + 440, y + creatureAttributes.getHeight() - 180);     // age

		if(bg.getFoodLevel() < 14)
			font.setColor(Color.RED);
		font.draw(batch, Double.toString(bg.getFoodLevel()), x - creatureAttributes.getWidth() + 440, y + creatureAttributes.getHeight() - 240);     // energy

		font.setColor(1,1,1,0.5f);
		batch.setColor(c);
		
	}
	
	public void dispose() {
		font.dispose();
		creatureAttributes.dispose();
	}
}
