package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class ShopStructure {
	
	private SpriteBatch batch;
	
	BlankEntity[][] map;
	TextureRegion[][] region;
	
	public ShopStructure(SpriteBatch batch, TextureRegion[][] region) {
		this.batch = batch;
		this.region = region;
		map = new BlankEntity[100][100];
		
		for(int y=0; y<100; y++) {
			for(int x=0; x<100; x++) {
				map[x][y] = new BlankEntity(x,y);
			}
		}
		for(int x=0;x<100;x++)
			map[x][0] = new MaterialCastleBrick(x, 0);
		for(int x=0;x<100;x++)
			map[x][99] = new MaterialCastleBrick(x, 99);
		
		for(int x=0;x<100;x++)
			map[x][10] = new MaterialCastleBrick(x, 10);
		for(int x=0;x<100;x++)
			map[x][20] = new MaterialCastleBrick(x, 20);
		for(int x=0;x<100;x++)
			map[x][30] = new MaterialCastleBrick(x, 30);
		for(int x=0;x<100;x++)
			map[x][40] = new RealLavaEntity(x, 40);
		for(int x=0;x<100;x++)
			map[x][99] = new WaterEntity(x, 99);
		
	}
	
	public void drawShop(int camX) {
		for(int y=0; y<100; y++) {
			for(int x=0; x<100; x++) {
				batch.setColor(1, 1, 1, 1);
				map[x][y].draw(batch, region, x, y);
			}
		}
	}
}
