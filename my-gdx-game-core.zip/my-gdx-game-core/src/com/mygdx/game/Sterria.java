package com.mygdx.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.FPSLogger;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap.Format;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.Buildings.BiomeLand;
import com.mygdx.Buildings.BuildingManager;
import com.mygdx.Buildings.Shop;
import com.mygdx.Buildings.ShopLand;
import com.mygdx.badguys.BadGuy;
import com.mygdx.badguys.BadGuyOutsideManager;
import com.mygdx.badguys.Ball;
import com.mygdx.badguys.Bat;
import com.mygdx.badguys.Bear;
import com.mygdx.badguys.Brain;
import com.mygdx.badguys.Cat;
import com.mygdx.badguys.Chicken;
import com.mygdx.badguys.Crab;
import com.mygdx.badguys.Crocodile;
import com.mygdx.badguys.Dog;
import com.mygdx.badguys.Duck;
import com.mygdx.badguys.Dwarf;
import com.mygdx.badguys.Dye;
import com.mygdx.badguys.Elephant;
import com.mygdx.badguys.Fire;
import com.mygdx.badguys.Fox;
import com.mygdx.badguys.Ghost;
import com.mygdx.badguys.Head;
import com.mygdx.badguys.Hippo;
import com.mygdx.badguys.Horse;
import com.mygdx.badguys.HumanEight;
import com.mygdx.badguys.HumanEleven;
import com.mygdx.badguys.HumanFive;
import com.mygdx.badguys.HumanFour;
import com.mygdx.badguys.HumanNine;
import com.mygdx.badguys.HumanOne;
import com.mygdx.badguys.HumanSeven;
import com.mygdx.badguys.HumanSix;
import com.mygdx.badguys.HumanTen;
import com.mygdx.badguys.HumanThirteen;
import com.mygdx.badguys.HumanThree;
import com.mygdx.badguys.HumanTwelve;
import com.mygdx.badguys.HumanTwo;
import com.mygdx.badguys.JackRussell;
import com.mygdx.badguys.Klakona;
import com.mygdx.badguys.Koala;
import com.mygdx.badguys.Lion;
import com.mygdx.badguys.Lurkera;
import com.mygdx.badguys.Mask;
import com.mygdx.badguys.Monkey;
import com.mygdx.badguys.Monolith;
import com.mygdx.badguys.Moose;
import com.mygdx.badguys.Mummy;
import com.mygdx.badguys.Mushroom;
import com.mygdx.badguys.Orb;
import com.mygdx.badguys.OutsideLand;
import com.mygdx.badguys.Panda;
import com.mygdx.badguys.Parrot;
import com.mygdx.badguys.Penguin;
import com.mygdx.badguys.Pig;
import com.mygdx.badguys.PolarBear;
import com.mygdx.badguys.PotionA;
import com.mygdx.badguys.PotionB;
import com.mygdx.badguys.PotionC;
import com.mygdx.badguys.PotionD;
import com.mygdx.badguys.PotionE;
import com.mygdx.badguys.PotionF;
import com.mygdx.badguys.Puddle;
import com.mygdx.badguys.Rabbit;
import com.mygdx.badguys.Rain;
import com.mygdx.badguys.Rhino;
import com.mygdx.badguys.Robot;
import com.mygdx.badguys.Sentry;
import com.mygdx.badguys.SentryCop;
import com.mygdx.badguys.Shark;
import com.mygdx.badguys.Sheep;
import com.mygdx.badguys.Skeleton;
import com.mygdx.badguys.SkullA;
import com.mygdx.badguys.SkullB;
import com.mygdx.badguys.SkullC;
import com.mygdx.badguys.SkullD;
import com.mygdx.badguys.SkullFlame;
import com.mygdx.badguys.Slime;
import com.mygdx.badguys.Snake;
import com.mygdx.badguys.Snow;
import com.mygdx.badguys.SnowyOwl;
import com.mygdx.badguys.Sphere;
import com.mygdx.badguys.Squirrel;
import com.mygdx.badguys.Tentacle;
import com.mygdx.badguys.Tiger;
import com.mygdx.badguys.UfoManager;
import com.mygdx.badguys.Walrus;
import com.mygdx.badguys.WeatherManager;
import com.mygdx.badguys.Wolf;
import com.mygdx.badguys.Zombie;
import com.mygdx.parallax.ParallaxBackground;
import com.mygdx.parallax.ParallaxLayer;
import com.mygdx.plants.LargeTree;
import com.mygdx.plants.OakTreeEntity;
import com.mygdx.plants.PineTree;
import com.mygdx.plants.SmallTreeEntity;
import com.mygdx.plants.TreeManager;
import com.mygdx.weather.WeatherMgr;

import box2dLight.ConeLight;
import box2dLight.PointLight;
import box2dLight.RayHandler;

public class Sterria extends ApplicationAdapter implements InputProcessor {

	private ShopStructure shopStructure = null;
	
	
	private int whichWeather = 0;
	private long startWeather = 0;
	private long endWeather = 0;
	private long weatherPeriod = 0;
	private float plTime = 0;
	private float plHourTime = 10;
	private float scale = 0;

	private long estimatedTime, startTime;

	// private ArrayList<SpotLight> lights;

	private CreatureAttributeScreen creatureAttributeScreen;
	private BadGuy selectedCreature;

	private int nTab = 0;
	private int tabSelection = -1;
	private String tab = "tab1";
	private ShapeRenderer shapeRenderer;

	private Rectangle tab1 = new Rectangle(52, 65, 40, 40);
	private Rectangle tab2 = new Rectangle(103, 65, 40, 40);
	private Rectangle tab3 = new Rectangle(155, 65, 40, 40);
	private Rectangle tab4 = new Rectangle(204, 65, 40, 40);
	private Rectangle tab5 = new Rectangle(254, 65, 40, 40);
	private Rectangle tab6 = new Rectangle(304, 15, 40, 40);

	private Texture inventoryBackdrop = null;

	private boolean bShowInventory = true;

	private InventoryAbstractSlot inventoryItem = null;

	private float leftVelocity, rightVelocity = 0.0f;

	private float jumpVelocity = Player.JUMPHEIGHT - 1;

	private int waterFlow = 0;

	private Viewport vp;

	private UfoManager ufoManager;

	private InventoryManager inventoryManager;

	private TreeManager treeManager;

	private float velocity = 0;// .JUMPHEIGHT;

	private BitmapFont fpsFont = null;

	private boolean torch = false;
	private float torchDir = 0;

	private int FPS = 0;

	private final int LIGHTCHECKFRAMES = 5;

	private World world;
	RayHandler rayHandler;
	private ConeLight ct;

	private Sprite lightSprite;
	private Texture lightTexture;

	private Texture weapons;

	FrameBuffer lightBuffer;
	TextureRegion lightBufferRegion;

	private ParallaxBackground cloudBackground;

	private boolean debug = false;

	private SpriteBatch batch;
	private BitmapFont font;

	@SuppressWarnings("unused")
	private FPSLogger fpsLogger;
	public static OrthographicCamera camera, hudCamera, topHudCamera, fbCamera, shopCamera;

	private boolean bRight = false;
	private boolean bLeft = false;
	private boolean bDown = false;

	TextureRegion[][] regions = null;
	TextureRegion[][] weaponRegions = null;

	private Texture spriteSheet, cloudTexture, cloudOneTexture;

	static int SCREENWIDTH = 0; // 1280 - these are got in the create method;
	static int SCREENHEIGHT = 0; // 1024 - these are got in the create method;
	public static final int TILEWIDTH = 16;
	public static final int TILEHEIGHT = 16;
	public static final int WORLDWIDTH = 2000;// 2000; // 2000 tiles wide =
												// ~62 // screens
	public static final int WORLDHEIGHT = 2000;// 1000; // 500 tiles deep = ~41
												// screens
	// deep or
	// 7 up 8 down
	private WorldMap worldMap;

	// Shaders
	private ShaderProgram nightShader, ambientShader, invertShader;

	float nightCol = 1.0f;

	final String vertexShader = new FileHandle("../my-gdx-game-core/data/vertexShader.glsl").readString();

	final String nightPixelShader = new FileHandle("../my-gdx-game-core/data/nightCycle.frag").readString();

	final String ambientPixelShader = new FileHandle("../my-gdx-game-core/data/AmbientVertexShader.frag").readString();

	// Blur shaders
	final String blurVertexShader = new FileHandle("../my-gdx-game-core/data/BlurVertexShader.glsl").readString();
	final String blurPixelShader = new FileHandle("../my-gdx-game-core/data/BlurFragmentShader.glsl").readString();
	final String bloomPixelShader = new FileHandle("../my-gdx-game-core/data/BloomFragmentShader.glsl").readString();
	final String thresholdPixelShader = new FileHandle("../my-gdx-game-core/data/ThresholdFragmentShader.glsl")
			.readString();
	final String invertPixelShader = new FileHandle("../my-gdx-game-core/data/InvertFragmentShader.glsl").readString();

	// Used for blur shader
	private FrameBuffer blurTargetA, blurTargetB;
	TextureRegion fboRegion;
	static final float MAX_BLUR = 2f;

	SpriteBatch batchz;

	// end of shader vars

	Texture cross = null;

	private Vector3 playerPosition;

	private Player player;

	SoundFx sfx = null;

	private List<OutsideLand> landList;
	private List<BiomeLand> biomeLand;
	private List<ShopLand> shopLand;

	private BadGuyOutsideManager outsideManager;

	private WeatherManager<Snow> weatherManagerSnow;
	private WeatherManager<Rain> weatherManagerRain;

	private WeatherMgr weatherMgr;

	private float absolutePosX = 0f;

	private Weapon weapon;

	private BuildingManager buildingManager;

	@Override
	public void create() {

		weatherMgr = new WeatherMgr();

		buildingManager = new BuildingManager();

		// lights = new ArrayList<SpotLight>();

		creatureAttributeScreen = new CreatureAttributeScreen();

		shapeRenderer = new ShapeRenderer();

		// These are our rectangle bounding box's for the tabs on the inventory
		// screen
		tab1 = new Rectangle(46, 5, 40, 40);
		tab2 = new Rectangle(103 - 6, 5, 40, 40);
		tab3 = new Rectangle(155 - 6, 5, 40, 40);
		tab4 = new Rectangle(204 - 6, 5, 40, 40);
		tab5 = new Rectangle(254 - 6, 5, 40, 40);
		tab6 = new Rectangle(304 - 6, 5, 40, 40);

		batchz = new SpriteBatch();

		weapon = new Weapon();

		sfx = new SoundFx();

		SCREENWIDTH = Gdx.graphics.getWidth();
		SCREENHEIGHT = Gdx.graphics.getHeight();

		fpsFont = new BitmapFont();

		//sfx.playMusic();

		world = new World(new Vector2(0, 0), true); // Box2D world, used for
													// Box2D lights
		RayHandler.useDiffuseLight(true);
		RayHandler.setGammaCorrection(true);
		rayHandler = new RayHandler(this.world);

		rayHandler.setAmbientLight(new Color(0.1f, 0.1f, 0.1f, 0.25f));
		rayHandler.setBlurNum(0);
		rayHandler.setShadows(false);
		rayHandler.setCulling(true);

		this.inventoryBackdrop = new Texture("../my-gdx-game-core/assets/inventorybackdrop.png");

		this.lightTexture = new Texture("../my-gdx-game-core/assets/mylight.png");
		this.lightSprite = new Sprite(this.lightTexture);
		this.lightSprite.scale(3.0f);

		Selection.initialise("../my-gdx-game-core/assets/tabs.png", 50, 840);

		Health.initialise(SCREENWIDTH - Health.healthAmount * 30 - 30, SCREENHEIGHT - 30,
				"../my-gdx-game-core/assets/health.png");

		Crafting.initialise("../my-gdx-game-core/assets/crafting.png", 50, 670);

		worldMap = new WorldMap(WORLDWIDTH, WORLDHEIGHT); // this will create
															// the world map

		ShaderProgram.pedantic = false;


		// Load pixel and vertex shaders
		nightShader = new ShaderProgram(vertexShader, nightPixelShader);

		if (!nightShader.isCompiled()) {
			Gdx.app.error("NightShader", nightShader.getLog());
			System.exit(0);
		} else {
			nightShader.begin();
			nightShader.setUniformf("ambientColor", this.nightCol, this.nightCol, this.nightCol, this.nightCol);
			nightShader.end();
		}

		/*
		 * ambientShader = new ShaderProgram(vertexShader, ambientPixelShader);
		 * 
		 * if (!ambientShader.isCompiled()) { Gdx.app.error("Ambient Shader",
		 * ambientShader.getLog()); System.exit(0); }
		 * 
		 * else { ambientShader.begin();
		 * ambientShader.setUniformf("ambientColor", this.nightCol,
		 * this.nightCol, this.nightCol, 1.0f);// this.nightCol);
		 * ambientShader.end(); }
		 */
		batch = new SpriteBatch();
		fpsLogger = new FPSLogger();

		spriteSheet = new Texture("../my-gdx-game-core/assets/davidtiles.png");

		// spriteSheet.setFilter(TextureFilter.Nearest, TextureFilter.Nearest);

		cloudTexture = new Texture("../my-gdx-game-core/assets/megaclouds.png");
		cloudOneTexture = new Texture("../my-gdx-game-core/assets/cloudone.png");

		regions = TextureRegion.split(spriteSheet, TILEWIDTH, TILEHEIGHT);

		weapons = new Texture("../my-gdx-game-core/assets/weapons.png");

		weaponRegions = TextureRegion.split(weapons, 16, 16);

		weapon.create(weaponRegions);

		camera = new OrthographicCamera();// SCREENWIDTH, SCREENHEIGHT );
		camera.setToOrtho(false, SCREENWIDTH, SCREENHEIGHT);
		camera.viewportHeight = SCREENHEIGHT;
		camera.viewportWidth = SCREENWIDTH;

		shopCamera = new OrthographicCamera();// SCREENWIDTH, SCREENHEIGHT );
		shopCamera.setToOrtho(false, SCREENWIDTH, SCREENHEIGHT);
	//	shopCamera.viewportHeight = SCREENHEIGHT;
	//	shopCamera.viewportWidth = SCREENWIDTH;

		
		vp = new FillViewport(SCREENWIDTH / 1, SCREENHEIGHT / 1, camera); //
		// cause screen be stretched...
		vp.apply();

		hudCamera = new OrthographicCamera(SCREENWIDTH, 100);
		topHudCamera = new OrthographicCamera(SCREENWIDTH, 100);
		topHudCamera.setToOrtho(true, SCREENWIDTH, SCREENHEIGHT);
		fbCamera = new OrthographicCamera(SCREENWIDTH, SCREENHEIGHT);
		fbCamera.setToOrtho(false);

		font = new BitmapFont();
		// font. setScale(1.0f);
		font.setColor(Color.WHITE);

		player = new Player("../my-gdx-game-core/assets/spritesheet.png", SCREENWIDTH / 2, SCREENHEIGHT / 2,
				this.batch); // our
		// hero!

		// w-2000 h-1000
		// Position player middle on X and near top of map on Y
		playerPosition = new Vector3(SCREENWIDTH / 2, SCREENHEIGHT / 2, 0);
		playerPosition.x = (WORLDWIDTH / 2) * TILEWIDTH;

		playerPosition.y = 1700 * 16;

		camera.position.x = playerPosition.x;
		camera.position.y = playerPosition.y;

		shopCamera.position.x = 50*TILEWIDTH;
		shopCamera.position.y = 25*TILEHEIGHT;//(100*16)/2;
		
		/////////////////////////////////////////////////////
		outsideManager = new BadGuyOutsideManager();

		System.out.println("Adding underland creatures...");
		// Get list of caves

		Random r = new Random();

		ArrayList<Cave> caves = worldMap.caves;
		for (int xx = 0; xx < caves.size(); xx++) { // may need to add more than
													// one to xx (need see later
													// in order increase fps )
			Cave cavern = caves.get(xx);

			if (cavern.isWaterCave) // Is this a water cave?
				continue;

			// we need to check how deep we are to add particular types of
			// monsters....TODO TODO TODO TODO
			for (int i = 2; i < cavern.cells.size(); i++) {
				if (cavern.cells.size() > 250) // we need play around with this
				{
					for (int j = 0; j < cavern.cells.size() / 250; j++) {
						// if(r.nextBoolean())
						{
							BadGuy jackRussell = new JackRussell((cavern.cells.get(i).x + (j * 16)) * TILEWIDTH,
									(cavern.cells.get(i).y) * TILEHEIGHT, 6, 2, camera, worldMap);
							jackRussell.load("../my-gdx-game-core/assets/badguys.png", 40, 5, false, "Rabbit");
							outsideManager.addBadGuy((int) jackRussell.getX(), (int) jackRussell.getY(), jackRussell);
							// System.out.println("added jackrussell");
						}
					}
				}
				break;
			}
		}
		System.out.println("Some enemies added to the underworld");

		////////////////////////////////////////////////////////

		// this.biomeLand = new ArrayList<BiomeLand>();
		// worldMap.findLandForBiom(biomeLand);
		// worldMap.addBiome(biomeLand);

		this.shopLand = new ArrayList<ShopLand>();
		worldMap.findLandForShop(shopLand);
		worldMap.addShops(shopLand);

		System.out.println("Added some shops...");

		/////////////// ADD SOME ABOVE GROUND BADDIES /////////////////////////
		// This needs moving into the BadGuyOutsideManager class really //

		landList = new ArrayList<OutsideLand>();

		// Get possible starting spawn points for the player
		worldMap.findLand(landList);

		for (int i = 40; i < 400; i++) {
			OutsideLand oland = landList.get(i);
			if (oland != null) {
				playerPosition.x = oland.x * TILEWIDTH;
				playerPosition.y = (1 + oland.y) * TILEHEIGHT;
				camera.position.x = playerPosition.x;
				camera.position.y = playerPosition.y;
			}
			break;
		}

		ct = new ConeLight(rayHandler, 130, Color.WHITE, 800, playerPosition.x, playerPosition.y, 80, 10);
		ct.setActive(false);
		ct.setXray(false);

		// Cloud background - add backgrounds here
		cloudBackground = new ParallaxBackground(new ParallaxLayer[] {
				// new ParallaxLayer(regions[0][0],new Vector2(),new Vector2(0,
				// 0)),
				new ParallaxLayer(cloudTexture, new Vector2(1.0f, 0.0f), new Vector2(0, 0)),
				// new ParallaxLayer(cloudOneTexture,new Vector2(2.5f,0),new
				// Vector2(0,-180),new Vector2(0, 0)),
		}, 960, 640, new Vector2(4, 0));

		Gdx.input.setInputProcessor(this);

		for (int x = 0; x < 100; x++) {
			Snow snowFlake = new Snow(camera, this.worldMap, r.nextInt(SCREENWIDTH), r.nextInt(100) - 200,
					r.nextInt(10) + 3, r.nextFloat() + 0.5f, 0, r.nextFloat() + 0.55f, r.nextFloat() / 1);
			this.weatherMgr.addWeatherSprite(snowFlake);
		}

		for (int x = 0; x < 100; x++) {
			Rain rain = new Rain(camera, this.worldMap, r.nextInt(SCREENWIDTH), r.nextInt(100) - 200, r.nextInt(10) + 3,
					r.nextFloat() + 0.5f, 0, r.nextFloat() + 0.8f);
			this.weatherMgr.addWeatherSprite(rain);
		}

		/*
		 * Generate trees
		 */
		treeManager = new TreeManager("../my-gdx-game-core/assets/mytrees.png", camera);

		landList.clear();
		worldMap.findLandForTrees(landList); // vip, need find some flat land
												// for each tree
		for (OutsideLand ol : landList) {
			if (r.nextInt(10) >= 5) {
				int whichTree = r.nextInt(4);

				switch (whichTree) {
				case 0:
					treeManager.add(new SmallTreeEntity((ol.x * TILEWIDTH) - TILEWIDTH,
							(ol.y * TILEHEIGHT) + TILEHEIGHT, (byte) 5, r.nextInt(2000) + 600, 0.001f, 0));
					break;
				case 1:
					treeManager.add(new OakTreeEntity((ol.x * TILEWIDTH) - TILEWIDTH, (ol.y * TILEHEIGHT) + TILEHEIGHT,
							(byte) 5, r.nextInt(2000) + 600, 0.0007f, 0));
					break;
				case 2:
					treeManager.add(new LargeTree((ol.x * TILEWIDTH) - TILEWIDTH, (ol.y * TILEHEIGHT) + TILEHEIGHT,
							(byte) 5, r.nextInt(2000) + 600, 0.0006f, 0));
					break;

				case 3:
					treeManager.add(new PineTree((ol.x * TILEWIDTH) - TILEWIDTH, (ol.y * TILEHEIGHT) + TILEHEIGHT,
							(byte) 5, r.nextInt(2000) + 600, 0.0005f, 0));
					break;

				}
			}
		}

		inventoryManager = new InventoryManager(this.regions); // tiles

		// Tab 1
		for (int j = 1; j <= 14; j++) {
			for (int xx = 1; xx <= 12; xx++) {
				InventorySlot i = new InventorySlot(50 * xx, 90 + (50 * j),
						"../my-gdx-game-core/assets/inventoryslot.png");
				inventoryManager.addIcon(i, 0);
			}
		}
		inventoryManager.getInventoryList().put("tab1", inventoryManager.icons[0]);
		// Add some starting items
		inventoryManager.addStartingItems("tab1");

		// Tab 2
		for (int j = 1; j <= 14; j++) {
			for (int xx = 1; xx <= 12; xx++) {
				InventorySlot i = new InventorySlot(50 * xx, 90 + (50 * j),
						"../my-gdx-game-core/assets/inventoryslot.png");
				inventoryManager.addIcon(i, 1);
			}
		}
		inventoryManager.getInventoryList().put("tab2", inventoryManager.icons[1]);
		inventoryManager.addStartingItems("tab2");

		// Tab 3
		for (int j = 1; j <= 14; j++) {
			for (int xx = 1; xx <= 12; xx++) {
				InventorySlot i = new InventorySlot(50 * xx, 90 + (50 * j),
						"../my-gdx-game-core/assets/inventoryslot.png");
				inventoryManager.addIcon(i, 2);
			}
		}
		inventoryManager.getInventoryList().put("tab3", inventoryManager.icons[2]);
		inventoryManager.addStartingItems("tab3");

		// Tab 4
		for (int j = 1; j <= 14; j++) {
			for (int xx = 1; xx <= 12; xx++) {
				InventorySlot i = new InventorySlot(50 * xx, 90 + (50 * j),
						"../my-gdx-game-core/assets/inventoryslot.png");
				inventoryManager.addIcon(i, 3);
			}
		}
		inventoryManager.getInventoryList().put("tab4", inventoryManager.icons[3]);
		inventoryManager.addStartingItems("tab4");

		// Tab 5
		for (int j = 1; j <= 14; j++) {
			for (int xx = 1; xx <= 12; xx++) {
				InventorySlot i = new InventorySlot(50 * xx, 90 + (50 * j),
						"../my-gdx-game-core/assets/inventoryslot.png");
				inventoryManager.addIcon(i, 4);
			}
		}
		inventoryManager.getInventoryList().put("tab5", inventoryManager.icons[4]);
		inventoryManager.addStartingItems("tab5");

		// Tab 6 - 32x32 blocks
		for (int j = 1; j <= 14 / 2; j++) {
			for (int xx = 0; xx < 12 / 2; xx++) {
				InventorySlotLarge i = new InventorySlotLarge(100 * xx + 48, 40 + (98 * j),
						"../my-gdx-game-core/assets/inventoryslotlarge.png");
				inventoryManager.addIcon(i, 5);
			}
		}
		inventoryManager.getInventoryList().put("tab6", inventoryManager.icons[5]);
		inventoryManager.addStartingItems("tab6"); // need to add 32x32 blocks

		ufoManager = new UfoManager(this.worldMap, this.camera, this.outsideManager, this.rayHandler);
		ufoManager.addUfo(16900, 28000, 0, 0);
		ufoManager.addUfo(9700, 27200, 1, 0);
		ufoManager.addUfo(1400, 29200, 0, 1);

		startWeather = System.currentTimeMillis();
		endWeather = startWeather + 10 * 1000; // 60 seconds * 1000 ms/sec

		this.shopStructure = new ShopStructure(this.batch, this.regions);
	}

	private float daynightCycle = -0.001f;// -0.00005f;
	private float nightTime = 20.0f;

	private boolean inShop = false;
	private float tempx=50*16;
	private float tempy=25*16;
	
	// we need to keep updating time in this method - TODO
	private void renderInsideShop() {

		if (Gdx.input.isKeyPressed(Input.Keys.X))  // quickly leave the shop
		{
			this.inShop = false;
			return;
		}
		
	//	shopCamera.position.x = RoundTo.RoundUpToNearest(shopCamera.position.x, 1);
	//	shopCamera.position.y = RoundTo.RoundUpToNearest(shopCamera.position.y, 1);
		
		int camX = (int) shopCamera.position.x - SCREENWIDTH / 2;
		camX /= TILEWIDTH;
		int endX = SCREENWIDTH / TILEHEIGHT + camX;

		int camY = (int) shopCamera.position.y - SCREENHEIGHT / 2;
		camY /= TILEHEIGHT;
		int endY = SCREENHEIGHT / TILEHEIGHT + camY;

		batch.setProjectionMatrix(shopCamera.combined);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		shopCamera.update();
		
		batch.begin();
		
		shopStructure.drawShop(0);
		
		player.render(0, tempx, tempy);

		batch.end();
		
		if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
			player.moveLeft(1);
			if(shopCamera.position.x >572 && tempx<=998)
			{
				shopCamera.position.x -= 4;
			}
			if(tempx > 32)
				tempx-=4;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
			player.moveRight(1);
			if(shopCamera.position.x <1000 && tempx>=600)
			{
				shopCamera.position.x += 4; // scroll map right
			}
			if(tempx < (100*TILEWIDTH)-TILEWIDTH)
				tempx+=4;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
			if(shopCamera.position.y <1200 && tempy>=400)
				shopCamera.position.y +=4;
			if(tempy < (99*TILEHEIGHT)-TILEHEIGHT)
				tempy+=4;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
			if(shopCamera.position.y >400 && tempy<=1200)
				shopCamera.position.y -=4;
			if(tempy>32)
				tempy-=4;
		}	
	}
	
	@Override
	public void render() {

		
		if(inShop) {
			renderInsideShop();
			return;
		}
		
		int walking = 52;

		nightShader.begin();
		nightShader.setUniformf("ambientColor", this.nightCol, this.nightCol, this.nightCol, this.nightCol);
		nightShader.end();

		camera.position.x = RoundTo.RoundUpToNearest(camera.position.x, 1);
		camera.position.y = RoundTo.RoundUpToNearest(camera.position.y, 1);
		camera.update();

		nightCol = this.plHourTime;

		BuildingManager.setHours(plHourTime);

		if (nightCol > 22 && nightCol <= 23)
			nightCol = 0.2f;
		else if (nightCol >= 20 && nightCol <= 22)
			nightCol = 0.3f;
		else if (nightCol > 0 && nightCol <= 4)
			nightCol = 0.2f;
		else if (nightCol > 4 && nightCol <= 6)
			nightCol = 0.3f;
		else if (nightCol > 6 && nightCol <= 7)
			nightCol = 0.5f;
		else if (nightCol > 7 && nightCol <= 8)
			nightCol = 0.8f;
		else if (nightCol > 8 && nightCol <= 16)
			nightCol = 1.0f;
		else if (nightCol > 16 && nightCol <= 18)
			nightCol = 0.8f;
		else if (nightCol > 18 && nightCol < 20)
			nightCol = 0.5f;

		Vector3 poss = new Vector3(camera.position);
		Vector3 poss2 = new Vector3(camera.position);
		// Vector3 possMiddle = new Vector3(camera.position);
		poss.y -= 10;
		if (!bRight) {
			poss.x -= 2;
		} else
			poss.x += 6;

		poss2.y -= 12;
		poss2.x -= 2;

		boolean bc = true;

		bc = worldMap.checkCollision(poss);
		if (!bc)
			velocity = 0;

		if (bc && camera.position.y > 36 * 16) {
			if (bc/* && worldMap.checkCollision(poss2) */ && !player.jumping) {
				camera.position.y -= velocity; // scroll map down
				if (velocity <= 3)
					velocity += 0.25f;
			} else
				velocity = 0f;
		} else
			velocity = 0;

		int fps = Gdx.graphics.getFramesPerSecond();

		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);// | GL20.GL_DEPTH_BUFFER_BIT
													// );

		// batchz.begin();
		// batchz.setShader(this.nightShader);
		// batchz.draw(this.backgroundTexture, 0, 0, 1920,1080);
		// batchz.end();

		cloudBackground.render(0.05f, this.nightShader);// this.nightShader); //
														// render clouds

		if (this.checkBlockAbove(camera.position)) // can we jump? If block
													// above, we cannot
		{
			if (player.jumping) {
				player.setPlayerJumping();

				if (jumpVelocity <= 0) {
					jumpVelocity = Player.JUMPHEIGHT - 1;
					player.jumping = false;
				} else {

					camera.position.y += jumpVelocity;
					jumpVelocity -= 0.1;
				}
			} else {
				if (Gdx.input.isKeyJustPressed(Input.Keys.UP) && !worldMap.checkCollision(poss)
						&& !worldMap.checkCollision(poss2)) {
					if (this.scale >= 0) {
						player.jumping = true;
					}

				}
			}
		}

		else
			player.jumping = false;

		if (Gdx.input.isKeyJustPressed(Input.Keys.I)) {
			bShowInventory = !bShowInventory;
		}

		if (Gdx.input.isKeyPressed(Input.Keys.T)) {
			// Torch
			torch = !torch;
		}

		if (Gdx.input.isKeyPressed(Input.Keys.R)) {
			vp.setWorldSize(SCREENWIDTH, SCREENHEIGHT);
			vp.apply();
			camera.zoom = 1;
			debug = false;
			player.setScale(0);
			scale = 0;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.MINUS)) {
			camera.zoom += 0.5;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.Z)) {
			camera.zoom -= 0.5;
		}

		if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
			if (this.scale >= 0) {
				bRight = false;
				torchDir = 180;
				rightVelocity = 0;
				if (camera.position.x > 64 * 16) {
					absolutePosX = -.1f;
					Vector3 po = new Vector3(camera.position);
					Vector3 po2 = new Vector3(camera.position);
					Vector3 po3 = new Vector3(camera.position);
					po.x -= 6;
					po2.y += 16;
					po2.x -= 6;
					po3.y += 32;
					po3.x -= 6;
					if (worldMap.checkCollision(po) && worldMap.checkCollision(po2) && worldMap.checkCollision(po3)) {
						if (leftVelocity < 2.0) {
							leftVelocity += 0.2;
						}
						camera.position.x -= leftVelocity; // scroll map left

					} else
						leftVelocity = 0;
				}

				walking = 36;
				if (player.jumping)
					player.setPlayerJumping();
				else
					player.moveLeft(1);
				if (this.inventoryItem != null && this.inventoryItem.type instanceof WeaponEntity)
					weapon.render(player.getX() + (player.getDir() == true ? 7 : -7), player.getY() + walking + 16,
							(player.getDir() == true ? -90 : 90));
			}
		} else {
			leftVelocity = 0;
			absolutePosX = 0;
		}

		if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
			if (this.scale >= 0) {
				bRight = true;
				leftVelocity = 0;

				torchDir = 0;
				if (camera.position.x < (WORLDWIDTH - 80) * 16) {
					absolutePosX = .1f;
					Vector3 po = new Vector3(camera.position);
					Vector3 po2 = new Vector3(camera.position);
					Vector3 po3 = new Vector3(camera.position);
					po.x += 8;
					po2.y += 16;
					po2.x += 8;
					po3.y += 32;
					po3.x += 8;
					if (worldMap.checkCollision(po) && worldMap.checkCollision(po2) && worldMap.checkCollision(po3)) {
						if (rightVelocity < 2.0) {
							rightVelocity += 0.2;
						}
						camera.position.x += rightVelocity; // scroll map right
					} else
						rightVelocity = 0;
				}
				walking = 36;
				if (player.jumping)
					player.setPlayerJumping();
				else
					player.moveRight(1);
				if (this.inventoryItem != null && this.inventoryItem.type instanceof WeaponEntity)
					weapon.render(player.getX() + (player.getDir() == true ? 7 : -7), player.getY() + walking + 16,
							(player.getDir() == true ? -90 : 90));

			}
		} else {

			absolutePosX = 0;
		}
		
		if(Gdx.input.isKeyPressed(Input.Keys.L))
		{
			System.out.println("*** LIGHTS IN GAME ***");
			for (SpotLight spotLight : worldMap.lights) {
				System.out.println(spotLight.x + "," + spotLight.y);
					
			}
		}
		
		// Player trying to enter a shop
		if (Gdx.input.isKeyPressed(Input.Keys.E)) {  // enter building
			Shop s = worldMap.collisionWithShop(camera.position.x,camera.position.y);
			if(s!=null){
				String text = s.getClass().getSimpleName();
				// We need to display inside of shop with any occupants and goods that
				// are sold in here
				if(BuildingManager.getHours() >= s.getTimeOpen() && BuildingManager.getHours() < s.getTimeClose()){
					System.out.println(text + " - is open");
					s.showOccupants();
					s.showItems();
					this.inShop = true;
				}
				else {
					
					this.inShop = false;
					System.out.println(text + " - is closed");
				}
			}
			else {
				this.inShop = false;
				System.out.println("No shop here");
			}
			
		}
		
		if (Gdx.input.isKeyPressed(Input.Keys.O)) {
			vp.setWorldSize(SCREENWIDTH / 2, SCREENHEIGHT / 2);
			vp.apply();
			scale = 2;
			player.setScale(scale);
		}
		// Display map
		if (Gdx.input.isKeyPressed(Input.Keys.M)) {
			vp.setWorldSize(SCREENWIDTH * 6, SCREENHEIGHT * 6);
			vp.apply();
			scale = -.5f;
			player.setScale(scale);
		}

		if (Gdx.input.isKeyPressed(Input.Keys.S)) {
			if (this.scale >= 0) {
				if (camera.position.x < (WORLDWIDTH - 64) * 16)
					camera.position.x += 30; // jump map left
			}
		}
		if (Gdx.input.isKeyPressed(Input.Keys.A)) {
			if (this.scale >= 0) {
				if (camera.position.x > 64 * 16)
					camera.position.x -= 30; // jump map right
			}
		}

		// We need to do a jump - TO DO
		if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
			if (this.scale >= 0)
				torchDir += 2;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.PAGE_UP)) {
			if (this.scale >= 0) {
				velocity = 2.0f;
				int v = SCREENHEIGHT / 16;
				if (camera.position.y < (WORLDHEIGHT - v) * 16)
					camera.position.y += 200; // jump map up
			}
		}
		if (Gdx.input.isKeyPressed(Input.Keys.PAGE_DOWN)) {
			if (this.scale >= 0) {
				velocity = 2.0f;
				if (camera.position.y > 39 * 16)
					camera.position.y -= 200; // jump map down
			}
		}
		if (Gdx.input.isKeyPressed(Input.Keys.D)) {
			debug = true; // turn debug on - basically draw the whole map
		}
		if (Gdx.input.isKeyPressed(Input.Keys.O)) {
			debug = false; // turn debug on - basically draw the whole map
		}
		if (Gdx.input.isKeyPressed(Input.Keys.F)) {
			debug = false; // turn debug off
		}


		// Calculate what we should draw
		int camX = (int) camera.position.x - SCREENWIDTH / 2;
		camX /= TILEWIDTH;
		int endX = SCREENWIDTH / TILEHEIGHT + camX;

		int camY = (int) camera.position.y - SCREENHEIGHT / 2;
		camY /= TILEHEIGHT;
		int endY = SCREENHEIGHT / TILEHEIGHT + camY;

		Matrix4 uiMatrix2 = camera.combined.cpy();
		uiMatrix2.setToOrtho2D(0, 0, SCREENWIDTH, SCREENHEIGHT);

		batch.setShader(null);// this.ambientShader);

		Random r = new Random();

		Matrix4 uiMatrix = topHudCamera.combined;// .combined.cpy();
		uiMatrix.setToOrtho2D(0, 0, SCREENWIDTH, SCREENHEIGHT);
		topHudCamera.setToOrtho(true);
		batch.setProjectionMatrix(uiMatrix);

		batch.begin(); // This is the first batch.being

		// Some random weather
		if (System.currentTimeMillis() < endWeather) {

			if (whichWeather == 0) {
				whichWeather = r.nextInt(3) + 1;
			}
			if (whichWeather == 1)
				weatherMgr.renderSnow(batch);
			else if (whichWeather > 1)
				weatherMgr.renderRain(batch);
		} else {
			if (this.weatherPeriod == 0) {
				int v = r.nextInt(60) + 5; // random time we wait before
											// possibly next shower
				this.weatherPeriod = System.currentTimeMillis() + v * 1000; // a
																			// minute
			}
			if (System.currentTimeMillis() > this.weatherPeriod) {
				if (r.nextInt(500) == 20) {
					int v = r.nextInt(60) + 5; // random time it will rain/snow
												// for
					endWeather = System.currentTimeMillis() + v * 1000;
					this.weatherPeriod = 0;
					this.whichWeather = 0;
				}
			}
		}

		batch.setProjectionMatrix(camera.combined); // bind to main camera
													// projection - VIP!!!

		// batch.begin(); // This is the first batch.being
		// Render some trees
		treeManager.checkTrees(camera, batch, SCREENWIDTH, SCREENHEIGHT, this.nightCol);

		buildingManager.renderShops(batch, camera, SCREENWIDTH, SCREENHEIGHT, this.worldMap, this.rayHandler);

		int ww = vp.getScreenWidth();
		int wh = vp.getScreenHeight();
		if (scale < 0) 
//			worldMap.drawMap(true, batch, regions, camX, camY, endX, endY, ww, wh, false);// allow user to view more of the map (they cannot move about when like this though)
			worldMap.drawMap(!false, batch, regions, camX - 80 * 3, camY - 80 * 3, endX + 80 * 10, endY + 80 * 5, ww, wh,
					false,this.nightCol);
		else
			worldMap.drawMap(debug, batch, regions, camX, camY, endX, endY, ww, wh, false,this.nightCol);

		// batch.setProjectionMatrix(camera.combined);

		// render player after blocks
		batch.setProjectionMatrix(uiMatrix2);

		player.setColor(worldMap.getBlockColor(camera.position));
		player.render(0, false, Sterria.camera, bRight);

		batch.setProjectionMatrix(camera.combined);

		worldMap.drawMap(debug, batch, regions, camX, camY, endX, endY, WORLDWIDTH, WORLDHEIGHT, true,this.nightCol);

		// batch.setShader(null);
		// player.render(0, true, this.camera, bRight);

		outsideManager.renderBadGuys(camera, batch);

		if (camX > 16 && endX < WORLDWIDTH && camY > 16 && endY < WORLDHEIGHT && this.waterFlow >= 5) {
			// for(int speed=0;speed<2;speed++)
			worldMap.moveWater(camX, camY - 50, endX, endY + 50);
			this.waterFlow = 0;
		} else
			waterFlow++;

		if (FPS >= 1) {// LIGHTCHECKFRAMES) {
			worldMap.updateLights(camX, camY, endX, endY, torch);
			FPS = 0;
		} else
			FPS++;

		// Render some trees
		// treeManager.checkTrees(camera, batch, SCREENWIDTH, SCREENHEIGHT);

		////////////////////////////////////////////////////////////////
		// Render bad guy sprites and move / update / animate etc them
		////////////////////////////////////////////////////////////////

		// outsideManager.renderBadGuys(camera, batch);

		// Update any ufo's that may be around...
		ufoManager.updateUfos(batch, camera);

		batch.setProjectionMatrix(uiMatrix);

		if (!bShowInventory) {
			Color c = batch.getColor();
			Sprite s = new Sprite(this.inventoryBackdrop);
			s.setPosition(0, 0);
			s.flip(false, true);

			batch.setColor(1f, 1f, 1f, 0.9f);
			s.draw(batch);
			batch.setColor(1f, 1f, 1f, 1f);

			inventoryManager.drawIcons(batch, tab); // we need to get which
													// tab we are on here

			batch.setColor(c);
		}

		// We display selected creatures attributes here if one is selected
		if (this.selectedCreature != null) {
			this.creatureAttributeScreen.render(batch, Gdx.graphics.getWidth(), 62, this.selectedCreature);
		}

		Health.draw(batch);

		batch.setProjectionMatrix(uiMatrix);
		shapeRenderer.begin(ShapeType.Line);
		int top = Gdx.graphics.getHeight();
		if (tabSelection == 1)
			shapeRenderer.rect(53 - 6, top - (67 + 0), 42, 42);
		if (tabSelection == 2)
			shapeRenderer.rect(104 - 6, top - (67 + 0), 42, 42);
		if (tabSelection == 3)
			shapeRenderer.rect(154 - 6, top - (67 + 0), 42, 42);
		if (tabSelection == 4)
			shapeRenderer.rect(203 - 6, top - (67 + 0), 42, 42);
		if (tabSelection == 5)
			shapeRenderer.rect(253 - 6, top - (67 + 0), 42, 42);
		if (tabSelection == 6)
			shapeRenderer.rect(303 - 6, top - (67), 42, 42);
		shapeRenderer.end();

		// HUD - Draw hud (in our case some text!)

		uiMatrix = hudCamera.combined.cpy();
		uiMatrix.setToOrtho2D(0, 0, SCREENWIDTH, SCREENHEIGHT);
		batch.setProjectionMatrix(uiMatrix);
		hudCamera.update();

		showFeet(batch, camera.position, fps);
		drawFps(batch, fps);

		// When player has a torch
		ct.setActive(torch);
		if (torch) {
			worldMap.updateTorch(toScreenSpace(camera.position));
			ct.setPosition(camera.position.x + 8, camera.position.y + 24);
			ct.setDirection(torchDir);
		}

		rayHandler.setCombinedMatrix(camera.combined);
		rayHandler.updateAndRender();

		// Draw weapon
		// We only want to draw weapon if one is selected...
		if (this.inventoryItem != null && this.inventoryItem.type instanceof WeaponEntity && walking != 36) {
			player.setPlayerAttacking();
			weapon.render(player.getX() + (player.getDir() == true ? 7 : -7), player.getY() + walking,
					(player.getDir() == true ? -90 : 90));
			checkCollisionWeaponToEnemy();
		} else
			player.idle();

		batch.end();
	}

	// When we remove a light, we need this to be called to update a basic light
	// to a point light, we only do this though if basic light isn't near a
	// point light
	private void addPointLight(int x, int y, boolean isLightAttribute) {
		// we only get to this method if a spot light was removed

		if (x > 12 && y > 12) {
			for (int yy = y - 12; yy < y + 12; yy++) { // check up to ten blocks
														// to the right
				for (int xx = x - 12; xx < x + 12; xx++) // check up to ten
															// blocks below
				{
					if (worldMap.getBlock(xx, yy) == null)
						continue;
					if (worldMap.getBlock(xx, yy) != null && worldMap.getBlock(xx, yy) instanceof LightEntity
							|| worldMap.getBlock(xx, yy).isLight) { // fix
																	// 8/11/2016
																	// - added
																	// to check
																	// if
																	// isLight
																	// prop is
																	// true -
																	// SDG

						// worldMap.getBlock(xx, yy).isLight=false;
						// check if light is already a spot light by seeing if
						// exists
						for (SpotLight spotLight : worldMap.lights) {
							if (spotLight.x != xx || spotLight.y != yy) {
								if (getLightCastLength(xx, yy) > 0) {
									// We really need to check if we are near
									// another spot light...
									SpotLight light = new SpotLight();
									light.pl = new PointLight(rayHandler, 50, Color.BLUE, 300, xx * 16, yy * 16);// camera.position.y);
									// light.pl.setStaticLight(true);
									// light.pl.setSoft(true);
									light.x = xx;
									light.y = yy;
									worldMap.lights.add(light); // add to our
																// light array
									// - needed so we can
									// remove the Box2DLight
									// when needed
								}
								return;
							}

						}
						if (worldMap.lights.size() == 0) {
							SpotLight light = new SpotLight();
							light.pl = new PointLight(rayHandler, 50, Color.BLUE, 300, xx * 16, yy * 16);// camera.position.y);
							light.pl.setStaticLight(true);
							light.pl.setSoft(true);
							light.x = xx;
							light.y = yy;
							worldMap.lights.add(light); // add to our light
														// array -
							// needed so we can remove the
							// Box2DLight when needed
							return;
						}
					}
				}
			}
		}
	}

	private float getLightCastLength(int x, int y) {

		for (SpotLight l : worldMap.lights) {
			if (x < l.x - 10 || x > l.x + 10 || y < l.y - 10 || y > l.y + 10) {
				// don't do anything
			} else {
				return 0;
			}
		}
		return 1;

	}

	// Check if weapon hit any of the bad guys
	public void checkCollisionWeaponToEnemy() {
		// TODO Auto-generated method stub
		Vector3 weaponPosition = new Vector3(camera.position);
		if (this.bRight)
			weaponPosition.x += 16; // player facing right
		else
			weaponPosition.x -= 16; // player facing left
		BadGuy bg = this.outsideManager.didWeHitABadGuy(weaponPosition);
		if (bg != null) // a collision
		{
			if (weapon.swiping()) // check if we are using our weapon
			{
				bg.decreaseHealth(0.03f);
				Pig p = (Pig) bg;
				// We change the state here for what the badguy will do when hit
				// Best update the chaneStateWhenBeingAttacked method
				// to use a little AI instead of just jumping away...
				p.chaneStateWhenBeingAttacked(BadGuy.State.JUMP);
				weapon.resetWeapon();
			}
		}
	}

	public static boolean isPowerOfTwo(int n) {
		if (n <= 0)
			return false;
		while (n > 1) {
			if ((n & 1) != 0)
				return false;
			n >>>= 1;
		}
		return true;
	}

	void resizeBatch(SpriteBatch batchz, int width, int height) {
		fbCamera.setToOrtho(false, width, height);
		batchz.setProjectionMatrix(fbCamera.combined);

	}

	/*
	 * depreciated
	 */
	@SuppressWarnings("unused")
	private boolean displayBlockDiagAbove(boolean dir, Vector3 position) {
		int val = dir == true ? 0 : -1;
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x) + val;
		int y = Math.round(screenSpace.y) + 1;
		BlankEntity entity = this.worldMap.getBlock(x, y);

		if (entity != null) {
			if (/* entity.toString().equals(".") || */entity instanceof CaveEntity || entity instanceof WaterEntity)

			{
				return !true;
			}
		} else
			// entity is null
			return !true;

		return false;
	}

	@SuppressWarnings("unused")
	private boolean keyPressed;

	@Override
	public boolean keyDown(int keycode) {
		if (keycode == Input.Keys.DOWN) {
			keyPressed = true;
		}
		return false;
	}

	private void addBlock(Vector3 position, /* InventoryType */BlankEntity type, InventoryAbstractSlot slot) {

		if (!(type instanceof ToolEntity) && !(type instanceof WeaponEntity)) {
			Vector3 poss = new Vector3(camera.position.x, camera.position.y, 0);

			Vector3 screenSpace = toScreenSpace(position);
			poss = toScreenSpace(poss);
			int x = (int) screenSpace.x;
			int y = (int) screenSpace.y;
			int px = Math.round(poss.x);
			int py = (int) poss.y;

			if ((x == px && y == py) || (x == px && y == py + 1) || (x == px && y == py + 2)
					|| (x == px && y == py + 3))
				return;

			BlankEntity entity = this.worldMap.getBlock(x, y);

			// uncomment if we are not allowed to draw over top of other tiles..

			if (entity == null || entity instanceof CaveEntity || entity instanceof MaterialBuildingWalkable) {
				// We need to check what type of building block selected

				type.x = x;
				type.y = y;

				if (entity != null) {
					if (entity.isLight) {
						this.removeBlock(position, false, false, false);
						// worldMap.removeLight(x, y);
					}
				}
				// if (!entity.isDecoration) {
				BlankEntity t = type;
				if (slot instanceof InventorySlotLarge) // if large block we
														// need to draw four of
														// them
				{
					if ((this.worldMap.getBlock(x, y) instanceof CaveEntity
							|| worldMap.getBlock(x, y) instanceof MaterialBuildingWalkable
							|| worldMap.getBlock(x, y) == null)
							&& (this.worldMap.getBlock(x + 1, y) instanceof CaveEntity
									|| worldMap.getBlock(x + 1, y) instanceof MaterialBuildingWalkable
									|| worldMap.getBlock(x + 1, y) == null)
							&& (this.worldMap.getBlock(x, y - 1) instanceof CaveEntity
									|| worldMap.getBlock(x, y - 1) instanceof MaterialBuildingWalkable
									|| worldMap.getBlock(x, y - 1) == null)
							&& (this.worldMap.getBlock(x + 1, y - 1) instanceof CaveEntity
									|| worldMap.getBlock(x + 1, y - 1) instanceof MaterialBuildingWalkable
									|| worldMap.getBlock(x + 1, y - 1) == null)) {

						slot.type.underNeath = this.worldMap.getBlock(x, y);
						if (this.worldMap.getBlock(x + 1, y) != null) {
							slot.type.lightValue = this.worldMap.getBlock(x + 1, y).lightValue;
							slot.type.originalLightValue = this.worldMap.getBlock(x + 1, y).originalLightValue;
						} else {
							slot.type.originalLightValue = 15;
							slot.type.lightValue = 15;
						}
						worldMap.addEntity(slot.type); // 20/09

						slot.type2.underNeath = this.worldMap.getBlock(x + 1, y);
						slot.type2.x = x + 1;
						slot.type2.y = y;
						if (this.worldMap.getBlock(x + 2, y) != null) {
							slot.type2.lightValue = this.worldMap.getBlock(x + 2, y).lightValue;
							slot.type2.originalLightValue = this.worldMap.getBlock(x + 2, y).originalLightValue;
						} else {
							slot.type2.originalLightValue = 15;
							slot.type2.lightValue = 15;
						}
						worldMap.addEntity(slot.type2); // 20/09

						slot.type3.underNeath = this.worldMap.getBlock(x, y - 1);
						slot.type3.x = x;
						slot.type3.y = y - 1;
						if (this.worldMap.getBlock(x + 1, y - 1) != null) {
							slot.type3.lightValue = this.worldMap.getBlock(x + 1, y - 1).lightValue;
							slot.type3.originalLightValue = this.worldMap.getBlock(x + 1, y - 1).originalLightValue;
						} else {
							slot.type3.originalLightValue = 15;
							slot.type.lightValue = 15;
						}
						worldMap.addEntity(slot.type3); // 20/09

						slot.type4.underNeath = this.worldMap.getBlock(x + 1, y - 1);
						slot.type4.x = x + 1;
						slot.type4.y = y - 1;
						if (this.worldMap.getBlock(x + 2, y - 1) != null) {
							slot.type4.lightValue = this.worldMap.getBlock(x + 2, y - 1).lightValue;
							slot.type4.originalLightValue = this.worldMap.getBlock(x + 2, y - 1).originalLightValue;
						} else {
							slot.type4.originalLightValue = 15;
							slot.type4.lightValue = 15;
						}

						worldMap.addEntity(slot.type4); // 20/09
					}
				} else {
					type.underNeath = entity;
					if (this.worldMap.getBlock(x + 1, y) != null) {
						t.originalLightValue = this.worldMap.getBlock(x + 1, y).originalLightValue;
						t.lightValue = this.worldMap.getBlock(x + 1, y).lightValue;
					} else {
						t.originalLightValue = 15;
						t.lightValue = 15;
					}
					worldMap.addEntity(t); // 20/09
				}

			}
		}
	}

	// ///////////////////////////////////////////////////////////
	// Remove a block - blocks take a varied amount of time to
	// dig out. Example - rock is 7 hits before it will be removed
	// and dirt is 2 hits.
	// TODO: Set animation of digging and allow collectable when
	// dug out (or <BlankEntity>.hits == 0 and block is removed)
	// ///////////////////////////////////////////////////////////
	private void removeBlock(Vector3 position, boolean bDown, boolean bLeft, boolean bRight) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = (int) screenSpace.x;
		int y = (int) screenSpace.y;

		BlankEntity entity = this.worldMap.getBlock(x, y);

		if (entity == null)
			return;

		if (entity instanceof LightEntity || entity.isLight) // light/torch? -
																// FIX isLight
																// added
																// 8/11/2016 SDG
		{
			worldMap.removeLight(x, y);
			entity.isLight = false;

			for (SpotLight p : worldMap.lights) {
				if (p.x == x && p.y == y) {
					p.pl.remove();
					worldMap.lights.remove(p);

					addPointLight(x, y, entity.isLight); // see if there is a
															// need to update a
					// basic light to a spot light

					break;
				}
			}
			return;
		}

		if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity
				|| entity instanceof CaveBottomEntity) {
			if (entity.hits <= 0) // hit block enough times? If so, we can go
			// ahead and remove it
			{
				this.worldMap.removeEntity(x, y);
			} else
				entity.hits--; // still need to hit the block more

		} else {
			if (entity != null && !(entity instanceof CaveEntity) && !(entity instanceof WaterEntity)) {
				if (entity.hits <= 0) // hit block enough times? If so, we can
										// go
										// ahead and remove it
				{
					this.worldMap.removeEntity(x, y);
				} else
					entity.hits--; // still need to hit the block more

			}
		}
	}

	/*
	 * Checks to see if we have blocks we can pass through above us, useful when
	 * player going to perform a jump
	 */
	private boolean checkBlockAbove(Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);
		if ((worldMap.getBlock(x, y + 1) == null)
				|| (worldMap.getBlock(x, y + 1) instanceof CaveEntity
						|| worldMap.getBlock(x, y + 1) instanceof WaterEntity
						|| worldMap.getBlock(x, y + 1) instanceof TreeEntity
						|| worldMap.getBlock(x, y + 1) instanceof LavaEntity)
				|| worldMap.getBlock(x, y + 1) instanceof GreyRockEntity) {
			return true;
		}
		return false;
	}

	public BlankEntity getBlock(int x, int y) {
		if (x <= WorldMap.w && x >= 0 && y <= WorldMap.h && y >= 0)
			return this.worldMap.getBlock(x, y);// worldMap[x][y];
		else
			return null;
	}

	// Some helper methods
	private Vector3 toScreenSpace(Vector3 position) {
		Vector3 v = new Vector3(0, 0, 0);
		v.x = position.x / TILEWIDTH;
		v.y = position.y / TILEHEIGHT;
		return v;
	}

	private void showFeet(SpriteBatch batch, Vector3 position, int fps) {
		Vector3 screenSpace = toScreenSpace(position);
		String pos = String.format("Depth: %1.0f feet", (this.WORLDHEIGHT - screenSpace.y) * 4);
		font.setColor(Color.CYAN);
		font.draw(batch, pos, 10, SCREENHEIGHT);

		pos = String.format("Player map pos:[X:%1.0f,Y:%1.0f]", screenSpace.x, screenSpace.y);
		font.setColor(Color.YELLOW);
		font.draw(batch, pos, 10, 70);
		String playerPos = String.format("Camera pos:[X:%.2f, Y:%.2f]", position.x, position.y);
		font.draw(batch, playerPos, 10, 50);
		font.draw(batch, "FPS: " + fps, SCREENWIDTH - 70, 50);

		pos = String.format("PL Time:%02.0f:%02.0f", plHourTime, plTime);
		font.setColor(Color.YELLOW);
		font.draw(batch, pos, SCREENWIDTH - 100, SCREENHEIGHT);

		// one hour is 60 seconds in project life
		if (plTime < 59)
			plTime += Gdx.graphics.getDeltaTime() * 2; // Mess with timings
		else {
			if (plHourTime < 23) {
				plHourTime += 1;
			} else {
				plHourTime = 0;
			}
			plTime = 0;
		}

	}

	private void drawFps(SpriteBatch batch, int fps) {

		Color c = fpsFont.getColor();
		fpsFont.setColor(0, 1, 0, 1);
		if (fps >= 45) {
			// 45 or more FPS show up in green
			fpsFont.setColor(0, 1, 0, 1);
		} else if (fps >= 30) {
			// 30 or more FPS show up in yellow
			fpsFont.setColor(1, 1, 0, 1);
		} else {
			// less than 30 FPS show up in red
			fpsFont.setColor(1, 0, 0, 1);
		}
		fpsFont.draw(batch, "FPS: " + fps, 10, 50);
		fpsFont.setColor(c); // white

	}

	@Override
	public void dispose() {
		batch.dispose();
		// player.getSpriteBatch().dispose();
		nightShader.dispose();
		font.dispose();
		spriteSheet.dispose();
		cloudTexture.dispose();
		cloudOneTexture.dispose();
		rayHandler.dispose();
		world.dispose();
		fpsFont.dispose();
		sfx.dispose();
		weapons.dispose();
		// ambientShader.dispose();
		
		// invertShader.dispose();
		this.creatureAttributeScreen.dispose();
	}

	@Override
	public void resize(int width, int height) {
		// vp.update(width, height, true);

		// batch.setProjectionMatrix(camera.combined);
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {

		startTime = System.currentTimeMillis();
		// ... do something ...
		// See if we have clicked on one of the selection tabs
		Vector3 touchPos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);

		if (!bShowInventory) {

			if (tab1.contains(touchPos.x, touchPos.y)) {
				nTab = 0;
				tab = "tab1";
				return true;
			}
			if (tab2.contains(touchPos.x, touchPos.y)) {
				nTab = 1;
				tab = "tab2";
				return true;

			}
			if (tab3.contains(touchPos.x, touchPos.y)) {
				nTab = 2;
				tab = "tab3";
				return true;

			}
			if (tab4.contains(touchPos.x, touchPos.y)) {
				nTab = 3;
				tab = "tab4";
				return true;

			}
			if (tab5.contains(touchPos.x, touchPos.y)) {
				nTab = 4;
				tab = "tab5";
				return true;
			}
			if (tab6.contains(touchPos.x, touchPos.y)) {
				nTab = 5;
				tab = "tab6";
				return true;
			}
		}

		Vector3 mousePos = new Vector3();
		mousePos.set(Gdx.input.getX(), Gdx.input.getY(), 0);

		mousePos.y = /* SCREENHEIGHT - */ Gdx.input.getY() - 32;

		if (button == Input.Buttons.RIGHT) {
			Vector3 mousePos2 = new Vector3();
			mousePos2.set(Gdx.input.getX(), Gdx.input.getY(), 0);
			camera.unproject(mousePos2);
			selectedCreature = this.outsideManager.badGuyInformation(camera.position, mousePos2.x, mousePos2.y);
			if (selectedCreature != null) {
				// do what?... well, creatures attributes will be shown
			}
			return false;
		}

		if (button == Input.Buttons.LEFT) {
			Rectangle bounds = null;

			if (!this.bShowInventory) // inventory being shown
			{
				for (InventoryAbstractSlot inv : inventoryManager.icons[nTab]) {
					inv.setPicked(false);
				}

				for (InventoryAbstractSlot inv : inventoryManager.icons[nTab]) {
					bounds = inv.bounds();
					if (bounds != null) {
						if (mousePos.x >= bounds.x && mousePos.x <= bounds.x + bounds.width
								&& mousePos.y >= bounds.y - bounds.height && mousePos.y <= bounds.y) {
							inventoryItem = inv;
							inv.setPicked(true);
							return true;
						}
					}
				}

			}
			mousePos.set(Gdx.input.getX(), Gdx.input.getY(), 0);

			camera.unproject(mousePos);

			InventoryAbstractSlot ii = null;

			if (inventoryItem != null && inventoryItem.type != null && !(inventoryItem.type instanceof SpawnEntity)
					&& !(inventoryItem.type instanceof ToolEntity) && !(inventoryItem.type instanceof WeaponEntity)) {
				if (nTab != 5) {
					ii = new InventorySlot(inventoryItem.x, inventoryItem.y,
							"../my-gdx-game-core/assets/inventoryslot.png");
					ii.type = (LandscapeEntity) EntityFactory.getEntity(inventoryItem.type);
					ii.type.x = screenX;
					ii.type.y = screenY;
				} else { // large block
					ii = new InventorySlotLarge(inventoryItem.x, inventoryItem.y,
							"../my-gdx-game-core/assets/inventoryslot.png");
					ii.type = (LandscapeEntity) EntityFactory.getEntity(inventoryItem.type);
					ii.type.x = screenX;
					ii.type.y = screenY;
					ii.type2 = (LandscapeEntity) EntityFactory.getEntity(inventoryItem.type2);
					ii.type3 = (LandscapeEntity) EntityFactory.getEntity(inventoryItem.type3);
					ii.type4 = (LandscapeEntity) EntityFactory.getEntity(inventoryItem.type4);

				}
			} else
				ii = inventoryItem;

			Vector3 screenSpace = toScreenSpace(mousePos);
			int xx = Math.round(screenSpace.x);// + 1;
			int yy = Math.round(screenSpace.y);// + 1;
			BlankEntity ent = this.worldMap.getBlock(xx, yy);

			// Spawn something living - only can drop if nothing in way or is
			// cave entity
			if (inventoryItem != null && inventoryItem.type instanceof SpawnEntity) {
				if (ent != null && !(ent instanceof CaveEntity) && !(ent instanceof MaterialBuildingWalkable)
						&& !(ent instanceof LightEntity))
					return false;

				switch (inventoryItem.type.id) {
				case 400:
					BadGuy Fox = new Fox(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					Fox.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Fox");
					outsideManager.addBadGuy((int) Fox.getX(), (int) Fox.getY(), Fox);
					break;
				case 401:
					BadGuy rabbit = new Rabbit(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					rabbit.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Rabbit");
					outsideManager.addBadGuy((int) rabbit.getX(), (int) rabbit.getY(), rabbit);
					break;
				case 402:
					BadGuy rhino = new Rhino(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					rhino.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Rhino");
					outsideManager.addBadGuy((int) rhino.getX(), (int) rhino.getY(), rhino);
					break;
				case 403:
					BadGuy duck = new Duck(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					duck.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Duck");
					outsideManager.addBadGuy((int) duck.getX(), (int) duck.getY(), duck);
					break;
				case 404:
					BadGuy bear = new Bear(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					bear.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Brown Bear");
					outsideManager.addBadGuy((int) bear.getX(), (int) bear.getY(), bear);
					break;
				case 405:
					BadGuy ele = new Elephant(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					ele.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Elephant");
					outsideManager.addBadGuy((int) ele.getX(), (int) ele.getY(), ele);
					break;
				case 406:
					BadGuy croc = new Crocodile(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Crocodile");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 407:
					croc = new Brain(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "braina");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 408:
					croc = new Hippo(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Hippo");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 409:
					croc = new Horse(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Horse");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 410:
					croc = new Koala(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Koala");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 411:
					croc = new Lion(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Lion");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 412:
					croc = new Monkey(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Monkey");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 413:
					croc = new Moose(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Moose");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 414:
					croc = new Panda(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Panda");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 415:
					croc = new Parrot(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Parrot");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 416:
					croc = new Penguin(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Penguin");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 417:
					croc = new PolarBear(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Polar Bear");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 418:
					croc = new Shark(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Shark");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 419:
					croc = new SnowyOwl(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Snowowl");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 420:
					croc = new Tiger(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Tiger");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 421:
					croc = new Walrus(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Walrus");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 422:
					croc = new Wolf(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Wolf");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 423:
					croc = new Zombie(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "zombiea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 424:
					croc = new Tentacle(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "tentaclea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 425:
					croc = new Tentacle(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "tentacleb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 426:
					croc = new Squirrel(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "squirrela");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 427:
					croc = new Sphere(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "sphereb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 428:
					croc = new Sphere(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "spherea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 429:
					croc = new Snake(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "snakea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 430:
					croc = new Slime(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "slimed");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 431:
					croc = new Slime(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "slimec");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 432:
					croc = new Slime(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "slimeb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 433:
					croc = new Slime(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "slimea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 434:
					croc = new SkullFlame(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skullflameb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 435:
					croc = new SkullFlame(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skullflamea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 436:
					croc = new SkullA(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skulla");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 437:
					croc = new SkullB(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skullb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 438:
					croc = new SkullC(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skullc");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 439:
					croc = new SkullD(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skulld");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 440:
					croc = new Skeleton(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "skeletond");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 441:
					croc = new Sheep(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "Sheep" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 442:
					croc = new SentryCop(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "sentrycopb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 443:
					croc = new SentryCop(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "sentrycopa");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 444:
					croc = new Sentry(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "sentrya");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 445:
					croc = new Robot(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "robota");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 446:
					croc = new Robot(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "robotb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 447:
					croc = new Puddle(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "puddlea");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 448:
					croc = new Puddle(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "puddleb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 449:
					croc = new PotionF(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "portionf");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 450:
					croc = new PotionA(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "portiona");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 451:
					croc = new PotionB(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "portionb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 452:
					croc = new PotionC(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "portionc");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 453:
					croc = new PotionD(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "portiond");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 454:
					croc = new PotionE(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "portione");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 455:
					croc = new Orb(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "orba");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 456:
					croc = new Orb(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "orbb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 457:
					croc = new Mushroom(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "mushrooma");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 458:
					croc = new Mushroom(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "mushroomb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 459:
					croc = new Mummy(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "mummya");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 460:
					croc = new Monolith(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "monolitha");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 461:
					croc = new Monolith(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "monolithb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 462:
					croc = new Mask(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "maskd");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 463:
					croc = new Lurkera(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "lurkera");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 464:
					croc = new Klakona(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "klakona");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 465:
					croc = new Head(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "heada");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 466:
					croc = new Head(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "headb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 467:
					croc = new Head(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "headc");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 468:
					croc = new Head(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "headd");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 469:
					croc = new Ghost(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ghasta");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 470:
					croc = new Ghost(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ghastb");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 471:
					croc = new Ghost(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ghastc" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 472:
					croc = new Fire(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "firea" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 473:
					croc = new Dye(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "dyea" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 474:
					croc = new Dwarf(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "dwarfa" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 475:
					croc = new Duck(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ducka" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 476:
					croc = new Dog(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "doga" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 477:
					croc = new Crab(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "craba" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 478:
					croc = new Chicken(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "chickena" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 479:
					croc = new Chicken(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "chickenb" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 480:
					croc = new Chicken(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "chickenc" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 481:
					croc = new Cat(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "cata" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 482:
					croc = new Bat(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "bat" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 483:
					croc = new Ball(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ball" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 484:
					croc = new HumanOne(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "bhg" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 485:
					croc = new HumanTwo(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "bhw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 486:
					croc = new HumanThree(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "dbhg" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 487:
					croc = new HumanFour(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "dghw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 488:
					croc = new HumanFive(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "dkhg" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 489:
					croc = new HumanSix(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ghg" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 490:
					croc = new HumanSeven(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ghw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 491:
					croc = new HumanEight(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "lghw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 492:
					croc = new HumanNine(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "mhw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 493:
					croc = new HumanTen(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "ohw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 494:
					croc = new HumanEleven(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "orhw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 495:
					croc = new HumanTwelve(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "phw" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				case 496:
					croc = new HumanThirteen(mousePos.x, mousePos.y, 0, 0, camera, worldMap);
					croc.load("../my-gdx-game-core/assets/badguys.png", 0, 0, false, "puhg" + "");
					outsideManager.addBadGuy((int) croc.getX(), (int) croc.getY(), croc);
					break;
				}

			} else if (inventoryItem != null && (inventoryItem.type != null)
					&& !(inventoryItem.type instanceof ToolEntity)) {

				int x = (int) screenSpace.x;
				int y = (int) screenSpace.y;

				if (inventoryItem.type instanceof LightEntity) {

					Color[] cols = { Color.RED, Color.BLUE, Color.PURPLE, Color.MAGENTA };

					screenSpace = toScreenSpace(camera.position);

					float length = getLightCastLength(x, y);

					if (length > 0) {
						// Add a torch/light
						if (this.worldMap.addLight(x, y)) {
							SpotLight light = new SpotLight();
							int index = 0;
							if (inventoryItem.type instanceof BlueLightEntity)
								index = 1;
							if (inventoryItem.type instanceof GreenLightEntity)
								index = 2;
							if (inventoryItem.type instanceof CyanLightEntity)
								index = 3;

							light.pl = new PointLight(rayHandler, 50, cols[index], 300, x * 16, y * 16);// camera.position.x,
							// camera.position.y);
							light.pl.setStaticLight(true);
							light.pl.setSoft(true);
							light.x = x;
							light.y = y;
							worldMap.lights.add(light); // add to our light
														// array -
							// needed so we
							// can remove the Box2DLight
							// when needed
						}
					} else // don't create a Box2DLight, just our standard one
					{
						this.worldMap.addLight(x, y);
					}

				} else if (inventoryItem.type instanceof DecorationEntity) {
					this.worldMap.addDecoration(x, y, inventoryItem.type);

				} else // normal block
				{
					addBlock(mousePos, ii.type, ii);
					weapon.resetWeapon();
				}
			}

			// if pickaxe we can dig
			else if (inventoryItem != null && inventoryItem.type instanceof ToolEntity) {
				sfx.playDirt();
				removeBlock(mousePos, bDown, bLeft, bRight);
			}

		}
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		estimatedTime = System.currentTimeMillis() - startTime;
		if (estimatedTime > 600) // long press
		{
			Vector3 touchPos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
			camera.unproject(touchPos);

			// We could check if shop is in view...
			// long press
			// Need to check if we are over a shop and player is near shop
			ArrayList<Shop> shops = BuildingManager.getInstance().getShops();
			if (shops != null) {
				Rectangle playerRect = new Rectangle(touchPos.x, touchPos.y, 20, 20);

				for (Shop s : shops)

				/* shops.stream().forEach((s) -> */ {
					Rectangle shopRect = new Rectangle(s.getPosition().x, s.getPosition().y, s.getWidth() * 16,
							s.getHeight() * 16);
					if (Intersector.overlaps(shopRect, playerRect)) {
						System.out.println("Shop selected" + s.getClass().getSimpleName());
						System.out.println("Shop opening and closing times:" + s);
						if (this.plHourTime >= s.getTimeOpen() && this.plHourTime < s.getTimeClose())
							System.out.println("Shop is currently open");
						else
							System.out.println("Shop is closed");

						s.getItemsList()
								.forEach(item -> System.out.println(
										item.getItemName() + " - " + item.getItemDescription() + " Level required:"
												+ item.getLevelRequired() + " Price:" + item.getPrice()));

						s.showOccupants();
						return true;
					}
				}
				;// );

			}

		}
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {

		if (this.bShowInventory)
			return true;

		Vector3 mousePos = new Vector3();

		mousePos.set(Gdx.input.getX(), Gdx.input.getY(), 0);

		// camera.unproject(mousePos);

		mousePos.y = Gdx.input.getY() - 32;// SCREENHEIGHT - Gdx.input.getY()
											// -32 ;
		Rectangle bounds = null;
		for (InventoryAbstractSlot inv : inventoryManager.icons[nTab]) { // we
																			// need
																			// to
			// get
			// which
			// page
			// tab we
			// are on
			// - just
			// using
			// 0 here
			bounds = inv.bounds();
			if (bounds != null) {
				inv.setSelected((mousePos.x >= bounds.x && mousePos.x <= bounds.x + bounds.width)
						&& (mousePos.y >= bounds.y - bounds.height && mousePos.y <= bounds.y));
			}
		}

		Vector3 touchPos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
		if (tab1.contains(touchPos.x, touchPos.y)) {
			tabSelection = 1;
		} else if (tab2.contains(touchPos.x, touchPos.y)) {
			tabSelection = 2;
		} else if (tab3.contains(touchPos.x, touchPos.y)) {
			tabSelection = 3;
		} else if (tab4.contains(touchPos.x, touchPos.y)) {
			tabSelection = 4;
		} else if (tab5.contains(touchPos.x, touchPos.y)) {
			tabSelection = 5;
		} else if (tab6.contains(touchPos.x, touchPos.y)) {
			tabSelection = 6;
		} else
			tabSelection = -1;

		return true;
	}

	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}
}
