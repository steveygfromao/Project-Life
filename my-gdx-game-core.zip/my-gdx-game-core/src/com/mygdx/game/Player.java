package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Player {

	public static final float JUMPHEIGHT = 4.0f;

	private float scale = 0.0f;
	private float colour;
	private float endY, jumpY;
	public boolean jumping = false;
	private float velocity = 2.0f;
	private Texture playerTextures;
	private SpriteBatch spriteBatch;
	private TextureRegion currentFrame;
	private TextureRegion[] walkFrames;

	private static final int FRAMEROWS = 2;// 90/48;//768 / 32;// 24;//768 / 32;
											// height
	private static final int FRAMECOLS = 16;// 128/16;//800 / 16; //50;//800 /
											// 16; width
	private static float TIMER = 1.0f;
	private static float AMOUNTFRAMES = FRAMEROWS * FRAMECOLS;// (((FRAMEROWS/2)-1)
																// * FRAMECOLS)
																// -
																// 0.2f;//2.8f;

	private boolean bRight = true;

	// Need to load animations and put into hashmap here
	// anim1 would be of type Animation
	public static void initialize() {
	}

	public void jump() {

		if (!jumping) {
			jumping = true;
			jumpY = y;
		}
		if (jumping) {

			if (velocity <= 0) // reached jump height?
			{

				jumping = false; // yes, set jumping to false, player should now
									// fall down
				velocity = JUMPHEIGHT;
			} else {
				jumpY -= velocity;// 0.1f; // keep jumping
				velocity -= 0.1f;
			}
		}
	}

	public TextureRegion getCurrentFrame() {
		return currentFrame;
	}

	public void setCurrentFrame(TextureRegion currentFrame) {
		this.currentFrame = currentFrame;
	}

	public TextureRegion[] getWalkFrames() {
		return walkFrames;
	}

	public void setWalkFrames(TextureRegion[] walkFrames) {
		this.walkFrames = walkFrames;
	}

	public Animation getWalkAnimation() {
		return walkAnimation;
	}

	public void setWalkAnimation(Animation walkAnimation) {
		this.walkAnimation = walkAnimation;
	}

	// private TextureAtlas atlas;
	private Animation walkAnimation;

	private int x, y;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean getDir() {
		return bRight;
	}

	public Player(String textureFile, int x, int y, SpriteBatch spriteBatch) {

		colour = 1;

		playerTextures = new Texture(textureFile);

		TextureRegion[][] tmp = TextureRegion.split(playerTextures, playerTextures.getWidth() / FRAMECOLS,
				playerTextures.getHeight() / 2);

		walkFrames = new TextureRegion[FRAMECOLS * (FRAMEROWS)];

		int index = 0;
		for (int i = 0; i < FRAMEROWS; i++) {
			for (int j = 0; j < FRAMECOLS; j++) {
				walkFrames[index++] = tmp[i][j];
			}
		}
		walkAnimation = new Animation(TIMER, walkFrames);
		this.spriteBatch = spriteBatch;// new SpriteBatch();

		this.x = x;
		this.y = y;

		currentFrame = walkAnimation.getKeyFrame(0, true);

	}

	public void setScale(float scale)
	{
		this.scale = scale;
	}
	public void render(float delta, boolean inWater, Camera cam, boolean bRight) {

		Color c = spriteBatch.getColor();
		// animTime += Gdx.graphics.getDeltaTime(); // use for new animation
		// code
		spriteBatch.setColor(colour, colour, colour, 1);

		Sprite s = new Sprite(currentFrame);
		s.setPosition(x, y+(scale)*16);
	
		s.scale(scale);
		s.draw(spriteBatch);

//		spriteBatch.draw(currentFrame, x, y);

//		spriteBatch.setColor(c);

	}
	public void render(float delta, float x, float y) {

		Color c = spriteBatch.getColor();
		// animTime += Gdx.graphics.getDeltaTime(); // use for new animation
		// code
		spriteBatch.setColor(colour, colour, colour, 1);

		Sprite s = new Sprite(currentFrame);
		s.setPosition(x, y+(scale)*16);
	
		s.scale(scale);
		s.draw(spriteBatch);

//		spriteBatch.draw(currentFrame, x, y);

//		spriteBatch.setColor(c);

	}

	public void idle() {

		currentFrame = this.walkFrames[16 + (bRight ? 0 : 3)];// walkAnimation.getKeyFrame(TIMER,
																// true);
	}

	public void setPlayerAttacking() {
		currentFrame = this.walkFrames[17 + (bRight ? 0 : 3)];

	}

	public void setPlayerJumping() {
		currentFrame = this.walkFrames[18 + (bRight ? 0 : 3)];
	}

	public void moveRight(int amount) {
		bRight = true;

		currentFrame = walkAnimation.getKeyFrame(TIMER, true);
		if (TIMER > 8.0f)
			TIMER = 0.0f;
		else
			TIMER += Gdx.graphics.getDeltaTime() * 8;

	}

	public void moveLeft(int amount) {
		bRight = false;
		currentFrame = walkAnimation.getKeyFrame(TIMER + 8, true);
		if (TIMER > 8.0f)
			TIMER = 0.0f;
		else
			TIMER += Gdx.graphics.getDeltaTime() * 8;

	}

	public Texture getPlayerTextures() {
		return playerTextures;
	}

	public void setColor(float c) {
		this.colour = c;
	}

	public void setPlayerTextures(Texture playerTextures) {
		this.playerTextures = playerTextures;
	}

	public SpriteBatch getSpriteBatch() {
		return spriteBatch;
	}

	public void setSpriteBatch(SpriteBatch spriteBatch) {
		this.spriteBatch = spriteBatch;
	}

}
