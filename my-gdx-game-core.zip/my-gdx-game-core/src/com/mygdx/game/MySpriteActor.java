package com.mygdx.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public abstract class MySpriteActor extends Actor {
  private Texture texture;
  private boolean flipX, flipY;

  public MySpriteActor(float x, float y, Texture texture) {
    this.texture = texture;
    this.setPosition(x, y);
    this.setSize(texture.getWidth(), texture.getHeight()); // Initial size is 0f, 0f - nothing would get drawn.
    this.addListener(new ClickListener() {
      @Override
      public void clicked(InputEvent event, float x, float y) {
  		System.out.println("Clicked");
		
        MySpriteActor.this.clicked(event, event.getButton(), x, y);
      }
    });
  }

  protected abstract void clicked(InputEvent event, int button, float x, float y);

  @Override
  public void draw(Batch batch, float parentAlpha) {
    Color color = getColor();
    // Set this so texture is tinted with the color you can change with setColor() method.
    // Plus, if the action is Actions.fadeOut or Actions.fadeIn, make the actor change alpha/visibility.
    batch.setColor(color.r, color.g, color.b, color.a * parentAlpha);
    // Render the texture correctly even when it changes position, rotation, size, scale, etc.
    // Also useful if you're going to use Actions.
    if (texture != null) {
      batch.draw(
          texture,
          getX(), getY(), getOriginX(), getOriginY(),
          getWidth(), getHeight(), getScaleX(), getScaleY(),
          getRotation(),
          // It's like TextureRegion, what area of the Texture to draw.
          // Well, this is going to draw whole texture.
          0, 0, texture.getWidth(), texture.getHeight(),
          flipX, flipY
      );
    }
  }
}