package com.mygdx.game;

import box2dLight.PointLight;

public class SpotLight {
	public PointLight pl;
	public int x, y;

}
