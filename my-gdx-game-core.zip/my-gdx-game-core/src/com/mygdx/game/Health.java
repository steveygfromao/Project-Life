package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Health {

	static Sprite health;

	private static float xPos, yPos;

	static byte healthAmount = 5;

	static void initialise(int x, int y, String file) {
		xPos = x;
		yPos = y;

		health = new Sprite(new Texture(file));

	}

	
	public static void draw(SpriteBatch batch) {
	
		for(int i=0; i<healthAmount;i++)
		{
			health.setPosition(xPos + (i*32), yPos);// - hudSprite.getHeight() - 20);
			health.draw(batch);
		}
	}

}
