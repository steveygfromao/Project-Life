package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class InventorySlotLarge extends InventoryAbstractSlot{

	public InventorySlotLarge(float x, float y, String iconPath) {
		super(x,y,iconPath);
	}

	@Override
	void draw(SpriteBatch batch, InventoryAbstractSlot i) {
		// TODO Auto-generated method stub
		
		if (this.isSelected() || this.getPicked())
			batch.setColor(1, 1, 1, 1);
		else
			batch.setColor(1, 1, 1, 0.7f);

//		icon.flip(false, true);
		batch.draw(icon, x, y);
		if (i != null && i.type !=null)
		{
			batch.draw(item, x + 32, y + 32
					, 16, 16, i.type.sx*16, i.type.sy*16, 16, 16, false, !false);

			batch.draw(item, x + 48, y +32
					, 16, 16, i.type2.sx*16, i.type2.sy*16, 16, 16, false, !false);

			
			batch.draw(item, x + 32, y + 48
					, 16, 16, i.type3.sx*16, i.type3.sy*16, 16, 16, false, !false);

			batch.draw(item, x + 48, y + 48 
					, 16, 16, i.type4.sx*16, i.type4.sy*16, 16, 16, false, !false);
			
			font.draw(batch, Integer.toString(type.amount), x + 4, y + 18);
		}
	}

	@Override
	Rectangle bounds() {
		return new Rectangle(x + icon.getWidth() * 0.2f, y + icon.getHeight() * 0.2f, icon.getWidth() * 0.8f,
				icon.getHeight() * 0.8f);
	}

}
