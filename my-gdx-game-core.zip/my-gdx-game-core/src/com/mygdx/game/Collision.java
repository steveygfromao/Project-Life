package com.mygdx.game;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Intersector;

public class Collision {

	// Check collision of two rectangles
	public static boolean intersectorCollision(float x1, float y1, int w1, int h1, float x2, float y2, int w2, int h2) {
		Rectangle rect1 = new Rectangle(x1, y1, w1, h1);
		Rectangle rect2 = new Rectangle(x2, y2, w2, h2);
		return Intersector.overlaps(rect1, rect2);
	}

	// Axis aligned bounding box collision
	public static boolean aabbCollision(double x1, double y1, double w1, double h1, double x2,
	         double y2, double w2, double h2) {
	      
	      double cntrX1 = x1 + w1 / 2;
	      double cntrY1 = y1 + h1 / 2;

	      double cntrX2 = x2 + w2 / 2;
	      double cntrY2 = y2 + h2 / 2;

	      double distanceX = Math.abs(cntrX1 - cntrX2);
	      double distanceY = Math.abs(cntrY1 - cntrY2);

	      double sumWidth = (w1 / 2 + w2 / 2);
	      double sumHeight = (h1 / 2 + h2 / 2);

	      return distanceX < sumWidth && distanceY < sumHeight;
	     
	   }
}
