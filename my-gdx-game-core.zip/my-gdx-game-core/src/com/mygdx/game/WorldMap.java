package com.mygdx.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.Buildings.ArmourShop;
import com.mygdx.Buildings.BiomeLand;
import com.mygdx.Buildings.BuildingFactory;
import com.mygdx.Buildings.BuildingManager;
import com.mygdx.Buildings.PetShop;
import com.mygdx.Buildings.Shop;
import com.mygdx.Buildings.ShopLand;
import com.mygdx.badguys.BadGuy;
import com.mygdx.badguys.OutsideLand;
import com.mygdx.chunk.Chunk;

public class WorldMap {

	public ArrayList<SpotLight> lights;

	static final int BIOMWIDTH = 4;

	static final int MAXLIGHTLEVEL = 15;
	static final int W = 35;
	static final int H = 25;

	static int CROPCHANCE = 180;

	ArrayList<Cave> caves = new ArrayList<>();
	ArrayList<Cave> outsidecaves = new ArrayList<>();

	ArrayList<Chunk> chunkList = new ArrayList<>();

	private static final int ROCKAMOUNT = 5; // maximum types of rocks games has
	private static final int CHANCEOFADDINGCHUNK = 2; // Between 0-5

	private int GRASS_MAX = 1800; // to 1400
	public final int GRASS_START = 1600; // start 1000 down
	private final int DIRT_START = 1200; // 500 down to 1000 (Caves will be
											// generated in this part)
	private final int ROCK_START = 800; //
	private final int COAL_START = 450;
	private final int LAVA_START = 0;

	private final int CAVEREGULARITY = 10; // lower values for smaller but more
											// caves, larger for less but larger
											// caves

	private final int MAXLIGHT = 15; // top brightness of light

	private final int TREECHANCE = 5;

	public static int w, h;

	private SimplexNoise sn;

	private BlankEntity[][] worldMap; // 2D array to store the whole map

	private Random r = new Random();

	public BlankEntity[][] getWorldMap() {
		return worldMap;
	}

	public boolean addDecoration(int x, int y, BlankEntity entity) {

		// only allow decorations to be added to walkable material or empty
		// space
		if (worldMap[x][y] instanceof MaterialBuildingWalkable || worldMap[x][y] == null) {

			if (worldMap[x][y] instanceof DecorationEntity)
				return false;
			if (worldMap[x][y] != null) {
				worldMap[x][y].isDecoration = true;
				worldMap[x][y].decorationEntity = (DecorationEntity) entity;
			} else // must be outside
			{
				worldMap[x][y] = entity;// new LightEntity(x, y); // outside
										// light
			}
		}
		return true;
	}

	/*
	 * addLight Place a light source - when this is placed, we then need to
	 * update the light levels on blocks in it's vicinity
	 */
	public boolean addLight(int x, int y) {
		if (worldMap[x][y] instanceof LightEntity)
			return false;

		if (!(worldMap[x][y] instanceof MaterialBuildingWalkable) && !(worldMap[x][y] instanceof CaveEntity)
				&& worldMap[x][y] != null)
			return false;

		if (worldMap[x][y] != null)
			worldMap[x][y].isLight = true;
		else // must be outside
		{
			worldMap[x][y] = new LightEntity(x, y); // outside light
		}
		updateBlocksAroundLight(x, y);

		return true;
	}

	public void removeLight(int x, int y) {
		removeEntity(x, y);
	}

	public void addFloatingIsland() {
		/*
		 * for (int y = h - 1; y > GRASS_MAX; y--) // 2000 > 1400 { for (int x =
		 * 0; x < w - 1; x++) { worldMap[x][y] = new CoalEntity(x, y); } }
		 */
	}

	/*
	 * updateBlocksAroundLight This is where we need to change the light level
	 * of the blocks around the light placed at worldMap[x,y] Each block/entity
	 * has a lightLevel property Calculation: lightlevel = MAXLIGHT - (tile.x -
	 * x) x - x position of torch/light y - y position of torch/light
	 */
	private void updateBlocksAroundLight(int x, int y) {

		setLightSource(x, y, worldMap, MAXLIGHTLEVEL);

	}

	private void setLightSource(int x, int y, BlankEntity[][] map, int lightLevel) {
		if(map[x][y]!=null)
			map[x][y].lightValue = (byte) lightLevel;
	}

	/*
	 * Go through all lights in view and update blocks etc around them - this
	 * method is called every frame - well almost!
	 */
	public void updateLights(int sx, int sy, int ex, int ey, boolean torch) {
		for (int y = sy; y <= ey; y++) {
			for (int x = sx; x < ex + 1; x++) {
				if (x > 0 && y > 0 && x < this.w - 1 && y < this.h - 1 && worldMap[x][y] != null) {
					worldMap[x][y].lightValue = worldMap[x][y].originalLightValue; // we
																					// reset
																					// all
																					// tiles
																					// back
																					// to
																					// original
																					// colour
				}
			}
		}
		// now lets see if we have any lights near the blocks
		for (int y = sy; y <= ey - 1; y++) {
			for (int x = sx; x < ex - 1; x++) {

				if (x > 0 && y > 0 && x < this.w - 1 && y < this.h - 1 && worldMap[x][y] != null
						&& (worldMap[x][y] instanceof LightEntity || worldMap[x][y].isLight)) { // found
																								// a
					// light
					// updateFromTorchTileLight(worldMap, x, y);
					this.updateTileLight(worldMap, x, y);
				}
			}
		}

	}

	public void updateTorch(Vector3 position) {
		updateTileLight(worldMap, (int) position.x, (int) position.y);
	}

	private void updateFromTorchTileLight(BlankEntity[][] map, int lx, int ly) {
		int lightx = lx;
		int lighty = ly;

		worldMap[lx][ly].lightValue = 15;
		worldMap[lx - 1][ly].lightValue = 15;
		worldMap[lx + 1][ly].lightValue = 15;
		worldMap[lx][ly - 1].lightValue = 15;
		worldMap[lx][ly + 1].lightValue = 15;

		// if(worldMap[lx][ly] )
		float yy = 1.0f;

		for (int x = 0; x < 10; x++) {
			BlankEntity entity = this.getBlock(x + lx, ly);
			float lightValue = 15;
			if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity
					|| entity instanceof CaveEntity || entity == null) {
				System.out.println("Cave entity, be 90% of light");
				lightValue = (float) (worldMap[x + lx][ly].lightValue * 0.95) / yy;
				worldMap[x + lx + 1][ly].lightValue = lightValue;// (byte)
																	// (worldMap[x+lx][ly].lightValue
																	// *
																	// 0.95);
																	// //
																	// 90%
			} else {
				System.out.println("Solid block so 80% of light");
				lightValue = (float) (worldMap[x + lx][ly].lightValue * 0.80) / yy;
				worldMap[x + lx + 1][ly].lightValue = lightValue;
			}
		}
		yy += 0.2f;

	}

	private void updateTileLight(BlankEntity[][] map, int lightX, int lightY) {
		byte lightLevel = 0;
		try {
			for (int x = 0; x < 1 + W / 2; x++) { // map width
				for (int y = 0; y < (H / 2); y++) { // map height
					lightLevel = (byte) ((byte) MAXLIGHTLEVEL - x - y);
					if (lightLevel > 15)
						lightLevel = MAXLIGHTLEVEL;
					if (lightLevel < 0)
						lightLevel = 0;

					// Array index out of bounds fixed - 8/3/2016
					if ((x + (lightX) < WorldMap.w) && ((lightY) - y > 0) && ((lightX) - x > 0)
							&& ((lightY) + 1 + y < WorldMap.h)) {
						if (map[x + lightX][lightY - y] != null) {
							if (map[x + lightX][lightY - y].lightValue < lightLevel) {
								if (map[x + lightX][lightY - y] instanceof CaveEntity)
									map[x + lightX][lightY - y].lightValue = lightLevel * 0.95f;
								else
									map[x + lightX][lightY - y].lightValue = lightLevel * 0.8f;
							}
						}

						if (map[x + lightX][lightY + 1 + y] != null) {
							if (map[x + lightX][lightY + 1 + y].lightValue < lightLevel) {

								if (map[x + lightX][lightY + 1 + y] instanceof CaveEntity)
									map[x + lightX][lightY + 1 + y].lightValue = lightLevel * 0.95f;
								else
									map[x + lightX][lightY + 1 + y].lightValue = lightLevel * 0.8f;

							}
						}
						if (map[lightX - x][lightY - y] != null) {

							if (map[lightX - x][lightY - y].lightValue < lightLevel) {
								if (map[lightX - x][lightY - y] instanceof CaveEntity)
									map[lightX - x][lightY - y].lightValue = lightLevel * 0.95f;
								else
									map[lightX - x][lightY - y].lightValue = lightLevel * 0.8f;
							}
						}
						if (map[lightX - x][lightY + 1 + y] != null) {

							if (map[lightX - x][lightY + 1 + y].lightValue < lightLevel) {
								if (map[lightX - x][lightY + 1 + y] instanceof CaveEntity)
									map[lightX - x][lightY + 1 + y].lightValue = lightLevel * 0.95f;
								else
									map[lightX - x][lightY + 1 + y].lightValue = lightLevel * 0.8f;
							}
						}
					}

				}
			}
		} catch (Exception ex) {
			System.out.println("Light out of range");
		}

	}

	/*
	 * private void updateTileLight(BlankEntity[][] map, int lightX, int lightY)
	 * { byte lightLevel = 0; try { for (int x = 0; x < 1 + W / 2; x++) { for
	 * (int y = 0; y < (H / 2); y++) { lightLevel = (byte) ((byte) MAXLIGHTLEVEL
	 * - x - y); if (lightLevel > 15) lightLevel = MAXLIGHTLEVEL; if (lightLevel
	 * < 0) lightLevel = 0;
	 * 
	 * // Array index out of bounds fixed - 8/3/2016 if ((x + (lightX) <
	 * WorldMap.w) && ((lightY) - y > 0) && ((lightX) - x > 0) && ((lightY) + 1
	 * + y < WorldMap.h)) { if (map[x + lightX][lightY - y] != null) { if (map[x
	 * + lightX][lightY - y].lightValue < lightLevel) { map[x + lightX][lightY -
	 * y].lightValue = lightLevel; } }
	 * 
	 * if (map[x + lightX][lightY + 1 + y] != null) { if (map[x + lightX][lightY
	 * + 1 + y].lightValue < lightLevel) { map[x + lightX][lightY + 1 +
	 * y].lightValue = lightLevel; } } if (map[lightX - x][lightY - y] != null)
	 * {
	 * 
	 * if (map[lightX - x][lightY - y].lightValue < lightLevel) { map[lightX -
	 * x][lightY - y].lightValue = lightLevel; } } if (map[lightX - x][lightY +
	 * 1 + y] != null) {
	 * 
	 * if (map[lightX - x][lightY + 1 + y].lightValue < lightLevel) { map[lightX
	 * - x][lightY + 1 + y].lightValue = lightLevel; } } }
	 * 
	 * } } } catch (Exception ex) { System.out.println("Light out of range"); }
	 * 
	 * }
	 */

	/*
	 * getYPosition
	 */
	private int getYPosition(int x) {
		int yOffset = 8;
		float val = Math.abs(sn.noise(x, 1));
		if (val < 0.05)
			yOffset = 1;
		if (val > 0.05 && val < 0.1)
			yOffset = 3;
		if (val > 0.1 && val < 0.2)
			yOffset = 5;
		if (val > 0.2 && val < 0.3)
			yOffset = 8;
		if (val > 0.3 && val < 0.4)
			yOffset = 10;
		if (val > 0.4 && val < 0.6)
			yOffset = 15;
		if (val > 0.6 && val < 0.7)
			yOffset = 40;
		if (val > 0.8 && val < 0.9)
			yOffset = 48;

		return yOffset;
	}

	/*
	 * WorldMap Constructor
	 */
	public WorldMap(int w, int h) {

		// GRASS_MAX = h; // Set to height of map

		WorldMap.w = w;
		WorldMap.h = h;

		worldMap = new BlankEntity[w][h];

		sn = new SimplexNoise();

		lights = new ArrayList<SpotLight>();

		generateMap();
	}

	private Vector3 toScreenSpace(Vector3 position) {
		Vector3 v = new Vector3(0, 0, 0);
		v.x = position.x / 16;
		v.y = position.y / 16;
		return v;
	}

	// Check to see if player is in the water
	public boolean checkCollisionWithWater(Vector3 position) {
		position.y += 16; // middle of player
		Vector3 screenSpace = toScreenSpace(position);
		// for(int i=0; i<3;i++)
		{
			int x = Math.round(screenSpace.x);
			int y = Math.round(screenSpace.y);
			BlankEntity entity = getBlock(x, y);
			if (entity instanceof WaterEntity)
				return true;
			// screenSpace.y-=16;
		}
		return false;
	}

	public boolean checkRectCollision(Rectangle r1, Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = (int) screenSpace.x;
		int y = (int) screenSpace.y;
		BlankEntity entity = getBlock(x, y);

		if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity)
			return true;

		return false;
	}

	public boolean checkCollisionToInt(Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		// int x = Math.round(screenSpace.x);
		// int y = Math.round(screenSpace.y) ;
		int x = (int) screenSpace.x;
		int y = (int) screenSpace.y;
		BlankEntity entity = getBlock(x, y);
		if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity)
			return true;
		return entity == null /* || entity.toString().equals(".") */
				|| entity instanceof CaveEntity || entity instanceof WaterEntity || entity instanceof LavaEntity
				|| entity instanceof TreeEntity || entity instanceof MaterialBuildingWalkable
				|| entity instanceof CropEntity || entity instanceof DecorationEntity || entity instanceof LightEntity;
	}

	public boolean checkCollision(Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);
		BlankEntity entity = getBlock(x, y);
		entityHit = entity;
		if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity)
			return true;
		return entity == null /* || entity.toString().equals(".") */
				|| entity instanceof CaveEntity || entity instanceof WaterEntity || entity instanceof LavaEntity
				|| entity instanceof TreeEntity || entity instanceof MaterialBuildingWalkable
				|| entity instanceof CropEntity || entity instanceof DecorationEntity || entity instanceof LightEntity
				|| entity.isLight || entity.isDecoration;

	}

	private BlankEntity entityHit;

	public BlankEntity getEntityHit() {
		return entityHit;
	}

	public boolean isCrop() {
		if (getEntityHit() instanceof CropEntity) {
			return true;
		}
		return false;
	}

	public boolean checkCollisionRounded(Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);
		BlankEntity entity = getBlock(x, y);
		entityHit = entity;
		if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity)
			return true;

		if (entity instanceof CropEntity) // hit crop, get its attributes such
											// as how much energy it give us
		{
			// System.out.println("CROP Entity hit");
			// this.removeEntity(x, y);
			return true;
		}
		return entity == null /* || entity.toString().equals(".") */
				|| entity instanceof CaveEntity || entity instanceof WaterEntity || entity instanceof LavaEntity
				|| entity instanceof TreeEntity || entity instanceof MaterialBuildingWalkable
				|| entity instanceof CropEntity || entity instanceof DecorationEntity || entity instanceof LightEntity;
	}

	public Shop collisionWithShop(BadGuy bg) {
		ArrayList<Shop> shops = BuildingManager.getInstance().getShops();
		if (shops != null) {
			Rectangle badGuy = new Rectangle(bg.getX(), bg.getY(), 1, 1);
			for (Shop s : shops) {
				Rectangle shopRect = new Rectangle(s.getPosition().x + 16, s.getPosition().y, s.getWidth() - 16,
						s.getHeight());
				if (Intersector.overlaps(shopRect, badGuy)) {

					return s;
				}

			}
			
		}
		return null;
	}
	public Shop collisionWithShop(float x, float y) {
		ArrayList<Shop> shops = BuildingManager.getInstance().getShops();
		if (shops != null) {
			Rectangle player = new Rectangle(x, y, 16, 48);
			for (Shop s : shops) {
				Rectangle shopRect = new Rectangle(s.getPosition().x + 16, s.getPosition().y, s.getWidth() - 16,
						s.getHeight());
				if (Intersector.overlaps(shopRect, player)) {

					return s;
				}

			}
			
		}
		return null;
	}
	// Creatures use this collision
	public boolean checkCollisionRounded(Vector3 position, BadGuy bg) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);
		BlankEntity entity = getBlock(x, y);
		if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity || entity instanceof CaveRightEntity)
			return true;

		if (entity instanceof CropEntity) // hit crop, get its attributes such
											// as how much energy it give us
		{
			// Food level of creature
			if (bg.getFoodLevel() < 15) // if creatures food level is below 15
										// it can collect some
			{
				this.removeEntity(x, y);
				bg.increaseFoodLevel(2);
			}
			return true;
		}
		return entity == null /* || entity.toString().equals(".") */
				|| entity instanceof CaveEntity || entity instanceof WaterEntity || entity instanceof LavaEntity
				|| entity instanceof TreeEntity || entity instanceof MaterialBuildingWalkable
				|| entity instanceof CropEntity || entity instanceof DecorationEntity || entity instanceof LightEntity;

	}

	public boolean checkCollisionWithGrass(Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);
		BlankEntity entity = getBlock(x, y);
		return entity == null || entity instanceof MoonEntity || entity instanceof CaveEntity
				|| entity instanceof TreeEntity;

	}

	public int getAndSetSnowStageEntity(int x, int y) {
		BlankEntity entity = getBlock(x, y);
		if (entity instanceof GrassEntity) {
			if (entity instanceof SnowStageOneEntity) {
				if (entity.lifeCount <= 28) {
					addEntity(new SnowStageTwoEntity(x, y));
					// entity.lifeCount = 10;
				} else
					entity.lifeCount--;
				return 1;
			}
			if (entity instanceof SnowStageTwoEntity) {
				if (entity.lifeCount <= 24) {
					addEntity(new SnowStageThreeEntity(x, y));
					// entity.lifeCount = 10;
				} else
					entity.lifeCount--;
				return 2;
			}
			if (entity instanceof SnowStageThreeEntity) {

				if (entity.lifeCount <= 20) {
					addEntity(new SnowStageOneEntity(x, y)); // y+1 to go up
					// entity.lifeCount = 10;
				} else
					entity.lifeCount--;
				return 3;
			}
			if (entity.lifeCount <= 0) {
				addEntity(new SnowStageThreeEntity(x, y));
				entity.lifeCount = 20;
			} else
				entity.lifeCount--;
		}
		return -1;

	}

	/*
	 * getBlock get tile from map
	 */
	public BlankEntity getBlock(int x, int y) {
		if (x < WorldMap.w && x >= 0 && y < WorldMap.h && y >= 0)
			return worldMap[x][y];
		else
			return null;
	}

	/*
	 * generateMap Generate the world map
	 */
	private void generateMap() {
		for (int y = 0; y < h - 1; y++) {
			for (int x = 0; x < w - 1; x++) {
				worldMap[x][y] = null;// new BlankEntity(x,y);
			}
		}

		int yOffset = getYPosition(1);

		addEntity(new GrassEntity(0, GRASS_START - 2 + yOffset, GrassType.FLAT));
		for (int x = 1; x < w; x++) {
			int pos = r.nextInt(5);
			if (pos == 1 && yOffset < GRASS_MAX - GRASS_START) {
				yOffset += 2;
				addEntity(new GrassEntity(x, GRASS_START + yOffset, GrassType.FLAT));
			} else if (pos >= 4 && yOffset >= 0) {
				yOffset -= 2;
				addEntity(new GrassEntity(x, GRASS_START + yOffset, GrassType.FLAT));
			} else {
				addEntity(new GrassEntity(x, GRASS_START + yOffset, GrassType.FLAT));// ,
			}

		}

		CellularAutomata caves = new CellularAutomata(GRASS_START - DIRT_START, w, 30, 5, 4);

		System.out.println("Creating caves...");
		caves.initialiseMap();
		for (int i = 0; i < CAVEREGULARITY; i++) {
			caves.doSimulationStep(5);
		}

		System.out.println("Creating dirt blocks...");
		// Add dirt/earth - need to pass map array to cave generation here
		byte depth = 0;
		for (int x = 0; x < w; x++) {
			int y = DIRT_START + getYPosition(r.nextInt(4));
			do {
				LandscapeEntity ls = new LandscapeEntity(x, y);

				LandscapeEntity2 ls2 = new LandscapeEntity2(x, y);

				if (x > 0) {
					BlankEntity entity = this.getEntity(x - 1, y);
					if (entity == null) {
						addEntity(ls);
					} else {
						addEntity(r.nextBoolean() == true ? ls : ls2);
					}
				} else
					addEntity(r.nextBoolean() == true ? ls : ls2);

				y++;

			} while (!(worldMap[x][y] instanceof BlankEntity));

		}

		//
		for (int yy = DIRT_START; yy < GRASS_MAX; yy++) {
			depth = 0;
			for (int x = w - 2; x > 1; x--) {
				BlankEntity entity = this.getEntity(x - 1, yy);

				if (entity == null && getEntity(x + 1, yy) == null && getEntity(x, yy) instanceof LandscapeEntity) {
					// Single block
					addEntity(new LandscapeSingle(x, yy));

				} else {
					if (entity instanceof LandscapeEntity) // one to left a
															// brick
					{
						if (getEntity(x, yy) == null) {
							addEntity(new LandscapeRightEntity(x - 1, yy));
							worldMap[x - 1][yy].lightValue = 14;// worldMap[x+1][yy-1].lightValue;
							worldMap[x - 1][yy].originalLightValue = 14;
						}
					}
				}
				depth++;
			}
		}

		for (int yy = DIRT_START; yy < GRASS_MAX; yy++) {
			for (int x = 1; x < w - 2; x++) {
				BlankEntity entity = this.getEntity(x, yy);
				if (entity == null) {
					entity = this.getEntity(x + 1, yy);
					if (entity instanceof LandscapeEntity) {
						worldMap[x + 1][yy] = new LandscapeLeftEntity(x + 1, yy);
						worldMap[x + 1][yy].lightValue = 14;// worldMap[x+1][yy-1].lightValue;
						worldMap[x + 1][yy].originalLightValue = 14;// worldMap[x+1][yy-1].originalLightValue;

					}
				}
			}
		}

		// Add rock
		System.out.println("Creating rock blocks...");
		for (int x = 0; x < w; x++) {
			int y = ROCK_START + r.nextInt(1);
			do {
				addEntity(new RockEntity(x, y));
				y++;
			} while (!(worldMap[x][y] instanceof LandscapeEntity));
		}

		// Add coal
		System.out.println("Creating Coal blocks...");
		for (int x = 0; x < w; x++) {
			int y = COAL_START + r.nextInt(3);
			do {
				addEntity(new CoalEntity(x, y));
				y++;
			} while (!(worldMap[x][y] instanceof RockEntity));
		}

		System.out.println("Creating Lava blocks...");
		// Add lava
		for (int x = 0; x < w; x++) {
			int y = LAVA_START;
			do {
				addEntity(new RealLavaEntity(x, y));
				y++;
			} while (!(worldMap[x][y] instanceof CoalEntity));
		}

		System.out.println("Adding caves pass one...");
		// Add caves to earth/dirt layer
		BlankEntity[][] m = caves.getMap();
		for (int x = 0; x < GRASS_START - (DIRT_START + 2); x++) {
			for (int y = 0; y < w; y++) {
				if (m[x][y] != null) {
					m[x][y].x = y;
					m[x][y].y = x + DIRT_START;
				}
				worldMap[y][x + DIRT_START] = m[x][y];
			}
		}

		// 2nd pass checks - modify grass graphics
		System.out.println("Creating grass...");
		for (int pass = 0; pass <= 1; pass++) {
			for (int y = GRASS_START; y < GRASS_MAX; y++) {
				for (int x = 1; x < w - 1; x++) {
					if (worldMap[x][y] instanceof GrassEntity
							&& (worldMap[x - 1][y] == null && worldMap[x + 1][y] == null)) {
						worldMap[x][y] = null;
						worldMap[x][y - 1] = new GrassEntity(x, y, GrassType.FLAT);
					}
				}
			}
		}
		for (int y = GRASS_START; y < GRASS_MAX; y++) {
			for (int x = 1; x < w - 1; x++) {
				if (worldMap[x][y] instanceof GrassEntity && (worldMap[x - 1][y] == null)) {
					worldMap[x][y] = new GrassLeftEntity(x, y);
				}
			}
		}
		for (int y = GRASS_START; y < GRASS_MAX; y++) {
			for (int x = 1; x < w - 1; x++) {
				if (worldMap[x][y] instanceof GrassEntity && (worldMap[x + 1][y] == null)) {
					worldMap[x][y] = new GrassRightEntity(x, y);
				}
			}
		}

		// //////////////////////////////////////////////////////

		for (int yy = GRASS_MAX; yy > ROCK_START; yy--) {
			for (int x = 1; x < w - 2; x++) {
				BlankEntity entity = this.getEntity(x, yy);
				if (entity != null)// && entity instanceof LandscapeEntity ||
									// entity instanceof CoalEntity)
				{
					BlankEntity entityAbove = this.getEntity(x, yy + 1);
					if (entityAbove != null) {
						float lv = entityAbove.lightValue;
						if (lv > 1) {
							lv--;
						} else
							lv = 1;

						worldMap[x][yy].lightValue = lv;
						worldMap[x][yy].originalLightValue = lv;

					}
				}
			}
		}

		// //////////////////////////////////////////////////////

		System.out.println("Adding cave walls...");

		// Do cave gfx - add cave edges to left and right
		for (int x = 0; x < GRASS_START - (DIRT_START + 2); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + DIRT_START] instanceof LandscapeEntity) {
					if (worldMap[y - 1][x + DIRT_START] == null) {
						addEntity(new CaveRightEntity(y - 1, x + DIRT_START));
					} else {
						if (worldMap[y + 1][x + DIRT_START] == null) {
							addEntity(new CaveLeftEntity(y + 1, x + DIRT_START));
						}
					}
				}
			}
		}
		System.out.println("Adding landscape entities...");

		for (int x = 0; x < GRASS_START - (DIRT_START + 2); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + DIRT_START + 1] instanceof LandscapeEntity) // dirt
																				// above
				{
					if (worldMap[y][x + DIRT_START] == null) // empty space -
																// cave
						addEntity(new CaveTopEntity(y, x + DIRT_START));
				} else {
					if (worldMap[y][x + DIRT_START - 1] instanceof LandscapeEntity) // dirt
																					// above
					{
						if (worldMap[y][x + DIRT_START] == null) // empty space
																	// - cave
							addEntity(new CaveBottomEntity(y, x + DIRT_START));
					}
				}
			}
		}

		System.out.println("Adding caves pass two...");

		// Cave third pass - fill in nulls -
		for (int x = 0; x < GRASS_START - (DIRT_START + 2); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + DIRT_START] == null) // empty space - cave
				{
					addEntity(new CaveEntity(y, x + DIRT_START));
				}
			}
		}

		// Caves in Rock layer
		caves = new CellularAutomata(DIRT_START - ROCK_START, w, 30, 5, 4);

		System.out.println("Creating caves in rocks...");
		caves.initialiseMap();
		for (int i = 0; i < CAVEREGULARITY + 3; i++) {
			caves.doSimulationStep(0);
		}
		m = caves.getMap();
		for (int x = 0; x < DIRT_START - (ROCK_START); x++) {
			for (int y = 0; y < w; y++) {
				if (m[x][y] != null) {
					m[x][y].x = y;
					m[x][y].y = x + ROCK_START;
				}
				worldMap[y][x + ROCK_START] = m[x][y];
			}
		}
		// TO DO - NEED GRAPHICS FOR ROCK LEFT/RIGHT and entities creating for
		// them

		System.out.println("Creating rock left and right entities for rock caves...");
		for (int x = 0; x < DIRT_START - (ROCK_START); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + ROCK_START] instanceof LandscapeEntity) {
					if (worldMap[y -1][x + ROCK_START] == null) {
						addEntity(new RockLeftEntity(y , x + ROCK_START)); // left
																				// rockEntity
																				// needs
					} 
				}
			}
		}
		for (int x = 0; x < DIRT_START - (ROCK_START); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + ROCK_START] instanceof RockEntity) {
					if (worldMap[y + 1][x + ROCK_START] == null) {
						addEntity(new RockRightEntity(y , x + ROCK_START)); // left
																				// rockEntity
																				// needs
					} 
				}
			}
		}
		
	
		System.out.println("Filling in null blocks in caves in rock layer...");
		for (int x = 0; x < DIRT_START - (ROCK_START); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + ROCK_START] == null) // empty space - cave
				{
					addEntity(new CaveEntity(y, x + ROCK_START));
				}
			}
		}

		// Caves in COAL layer
		caves = new CellularAutomata(ROCK_START - COAL_START, w, 30, 5, 4);

		System.out.println("Creating caves in coal layer...");
		caves.initialiseMap();
		for (int i = 0; i < CAVEREGULARITY + 7; i++) {
			caves.doSimulationStep(1);
		}
		m = caves.getMap();
		for (int x = 0; x < ROCK_START - (COAL_START); x++) {
			for (int y = 0; y < w; y++) {
				if (m[x][y] != null) {
					m[x][y].x = y;
					m[x][y].y = x + COAL_START;
				}
				worldMap[y][x + COAL_START] = m[x][y];
			}
		}
		// TO DO - NEED GRAPHICS FOR COAL LEFT/RIGHT and entities creating for
		// them
		/*
		 * System.out.println(
		 * "Creating coal left and right entities for coal caves..."); for (int
		 * x = 0; x < ROCK_START - (COAL_START ); x++) { for (int y = 1; y < w -
		 * 1; y++) { if (worldMap[y][x + COAL_START] instanceof LandscapeEntity)
		 * { if (worldMap[y - 1][x + COAL_START] == null) { addEntity(new
		 * CaveLeftEntity(y - 1, x + COAL_START)); // right rockEntity needs
		 * creating } else { if (worldMap[y + 1][x + COAL_START] == null) {
		 * addEntity(new CaveRightEntity(y + 1, x + COAL_START)); // left
		 * rockEntity needs creating } } } } }
		 */
		System.out.println("Filling in null blocks in caves in coal layer...");
		for (int x = 0; x < ROCK_START - (COAL_START); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + COAL_START] == null) // empty space - cave
				{
					addEntity(new CaveEntity(y, x + COAL_START));
				}
			}
		}

		/*
		 * for (int x = 2; x < worldMap.length-2; x++) { for (int y =
		 * GRASS_START; y < worldMap[x].length-2; y++) {
		 * fFill.iterativeFillLand(x, y); ArrayList<CaveCell> cavec =
		 * fFill.landCells; if (cavec.size() > 0) { Cave c = new Cave(); for
		 * (CaveCell cell : cavec) { c.cells.add(cell); }
		 * this.outsidecaves.add(c); } } } System.out.println(
		 * "[Outside caves to fill with water generated:[" +
		 * this.outsidecaves.size() + "]");
		 *
		 * // System.out.println("Adding water to land"); // addWaterToLand();
		 */

		// Caves in Lava layer
		caves = new CellularAutomata(COAL_START - LAVA_START, w, 30, 5, 4);

		System.out.println("Creating caves in Lava layer...");
		caves.initialiseMap();
		for (int i = 0; i < CAVEREGULARITY + 4; i++) {
			caves.doSimulationStep(2);
		}
		m = caves.getMap();
		for (int x = 0; x < COAL_START - (LAVA_START); x++) {
			for (int y = 0; y < w; y++) {
				if (m[x][y] != null) {
					m[x][y].x = y;
					m[x][y].y = x + LAVA_START;
				}
				worldMap[y][x + LAVA_START] = m[x][y];
			}
		}
		// TO DO - NEED GRAPHICS FOR COAL LEFT/RIGHT and entities creating for
		// them
		/*
		 * System.out.println(
		 * "Creating coal left and right entities for coal caves..."); for (int
		 * x = 0; x < COAL_START - (LAVA_START ); x++) { for (int y = 1; y < w -
		 * 1; y++) { if (worldMap[y][x + LAVA_START] instanceof LandscapeEntity)
		 * { if (worldMap[y - 1][x + LAVA_START] == null) { addEntity(new
		 * CaveLeftEntity(y - 1, x + LAVA_START)); // right rockEntity needs
		 * creating } else { if (worldMap[y + 1][x + LAVA_START] == null) {
		 * addEntity(new CaveRightEntity(y + 1, x + LAVA_START)); // left
		 * rockEntity needs creating } } } } }
		 */
		System.out.println("Filling in null blocks in caves in lava layer...");
		for (int x = 0; x < COAL_START - (LAVA_START); x++) {
			for (int y = 1; y < w - 1; y++) {
				if (worldMap[y][x + LAVA_START] == null) // empty space - cave
				{
					addEntity(new CaveEntity(y, x + LAVA_START)); // need to add
																	// red lava
																	// type tile
				}
			}
		}

		System.out.println("Adding water...");

		// Create cave entities so we can add water and wot not to them
		FloodFill fFill = new FloodFill(worldMap);

		for (int x = 0; x < w; /* worldMap.length; */ x++) {
			for (int y = 0; y < h /* worldMap[x].length */; y++) {
				fFill.iterativeFill(x, y);
				ArrayList<CaveCell> cavec = fFill.caveCells;
				if (cavec.size() > 0) {
					Cave c = new Cave();
					for (CaveCell cell : cavec) {
						c.cells.add(cell);
					}
					this.caves.add(c);
				}
			}
		}
		System.out.println("[Caves generated:[" + this.caves.size() + "]");

		addWaterToCave(0);

	/*
	 * // We need somehow store where the water biomes are....
	 * System.out.println("Adding water biomes to land");
	 *
	 * for (int x = 0; x < (GRASS_MAX-1) - (GRASS_START); x++) { for (int y = 1;
	 * y < w - 1; y++) { if (worldMap[y][x + GRASS_START] != null) { int tempx =
	 * x+GRASS_START; if(worldMap[y][tempx] instanceof GrassEntity ||
	 * worldMap[y][tempx] instanceof WaterEntity) { int temp = tempx+1; int ex =
	 * getEnd(temp,y); if(ex!=-1) { if(ex-y < 18) { for(int yy=y;yy<ex;yy++) {
	 * worldMap[yy][temp] = new WaterEntity(yy, temp); } } y=ex-1; } } } }
	 *
	 * }
	 */

	System.out.println("Creating chunks...");

	createChunks();System.out.println("Amount of chunks we can add to:"+chunkList.size()+"\n\n");System.out.println("Inserting random rocks...");
	// insertRandomRocks();

	// addTrees(); // This needs updating

//	System.out.println("Adding random planets...");
	// addPlanets();

	Random r = new Random();
	int randValue = r.nextInt(60) + 100;
	int xrandValue = r.nextInt(6) + 150;for(
	int y = h - 60;y>GRASS_START+100;y-=randValue) // 2000 >
													// 1400
/*	{
		for (int x = 50; x < w - 51; x += xrandValue) {

			addPlanet(x, y);
		}
	}
*/
	System.out.println("Adding chests...");this.addChests();

	System.out.println("Adding crops...");this.addCrops();
	}

	public void addBiome(List<BiomeLand> biomeLand) {
		for (BiomeLand b : biomeLand) {

			this.addDomeBiom(b);
		}
	}

	private void addDomeBiom(BiomeLand b) {
		worldMap[b.x - b.size][b.y + 1] = new BiomDomeEntity(b.x - b.size, b.y + 1);
		for (float i = 0; i < b.size; i++) {
			for (double u = 0; u < 180; u += 1) {
				double angle = u * Math.PI / 180;
				int x2 = (int) (b.x + i * Math.cos(angle));
				int y2 = (int) (b.y + i * Math.sin(angle));
				worldMap[x2][y2 + 1] = new BiomDomeEntity(x2, y2 + 1);// ,GrassType.FLAT);
																		// // we
																		// need
																		// draw
																		// grass
																		// if
																		// top
																		// or
																		// corners
																		// -
																		// TODO
				worldMap[x2][y2 + 1].lightValue = 15;
				worldMap[x2][y2 + 1].originalLightValue = 15;

			}
		}

	}

	public void findLandForBiom(List<BiomeLand> biomeLand) {
		int length = 0;

		for (int y = GRASS_MAX; y > GRASS_START - 1000; y--) {
			for (int x = 20; x < w - 20; x++) {
				length = 0;
				int i = 0;
				if (worldMap[x][y] instanceof GrassEntity && worldMap[x][y + 1] == null) { // found
																							// a
																							// start
					// point
					int start = x + i;

					while (worldMap[x + i][y] instanceof GrassEntity && x + i < w - 20) {
						length++; // length of this piece of grass flat land
						i++;
					}
					if (length >= 12) // smallest biome is of 12 width
					{
						BiomeLand foundLand = new BiomeLand(start + length / 2, y, length / 2);
						biomeLand.add(foundLand);
					}
				}

			}
		}
	}

	// This add / allows creation of shops on land we have found
	public void addShops(List<ShopLand> shopLand) {
		for (ShopLand b : shopLand) {
			this.addShop(b);
			System.out.println("Shop added at:" + b.x + "," + b.y + " of size:" + b.size);
		}
	}

	private void addShop(ShopLand b) {
		Shop ps = null;
		// We still need to add items in the createShop method and creature that
		// populates the shop
		if (b.size <= 5) // pet shop
			ps = BuildingFactory.createShop(BuildingFactory.Buildings.pet, new Vector2(b.x, b.y + 16), 60, 6, worldMap);
		else if (b.size >= 120 / 16 && b.size < 10) // weapons
			ps = BuildingFactory.createShop(BuildingFactory.Buildings.weapons, new Vector2(b.x, b.y + 16), 110, 8,
					worldMap);
		else if (b.size >= 10)// armour
			ps = BuildingFactory.createShop(BuildingFactory.Buildings.armour, new Vector2(b.x, b.y + 16), 150, 10,
					worldMap);
		// ps.createShop();

	}

	public void findLandForShop(List<ShopLand> shopLand) {
		int length = 0;

		for (int y = GRASS_MAX; y > GRASS_START - 1000; y--) {
			for (int x = 20; x < w - 20; x++) {
				length = 0;
				int i = 0;
				if (worldMap[x][y] instanceof GrassEntity) { // found a start
																// point
					int start = x + i;

					while (worldMap[x + i][y] instanceof GrassEntity && x + i < w - 20) {
						length++; // length of this piece of grass flat land
						i++;
					}
					if (length >= 5) // smallest shop is of 5 width
					{
						ShopLand sLand = new ShopLand(start * 16, y * 16, length);
						shopLand.add(sLand);
					}
				}
				// depending on the world size, we set skip gap for next shop
				x += length + r.nextInt(w / 100) + 5; // make sure we skip
				// some of the land
			}
		}
	}

	int getEnd(int sx, int cols) {

		for (int x = cols; x < w - 2; x++) {

			if (worldMap[x][sx] instanceof GrassEntity || worldMap[x][sx] instanceof LandscapeLeftEntity
					|| worldMap[x][sx] instanceof LandscapeRightEntity || worldMap[x][sx] instanceof LandscapeSingle
					|| worldMap[x][sx] instanceof FlowerEntity)
				return x;
		}
		return -1;
	}

	// This needs fixing so we don't have water in very single hole on the land
	// - TODO
	private void addWaterToLand() {

		for (int xx = 0; xx < this.outsidecaves.size(); xx++) {
			Cave cavern = this.outsidecaves.get(xx);

			if (!cavern.isWaterCave) // Is this a water cave?
				continue;

			int highest = 0;
			int lowest = 100000;

			for (int i = 0; i < cavern.cells.size(); i++) {
				if (cavern.cells.get(i).y > highest)
					highest = cavern.cells.get(i).y;
				if (cavern.cells.get(i).y < lowest)
					lowest = cavern.cells.get(i).y;
			}

			int pickedValue = lowest;
			if (highest - lowest > 0)
				pickedValue = lowest + ((highest - lowest) / 2);

			for (int i = 0; i < cavern.cells.size(); i++) {
				if (cavern.cells.get(i).y <= pickedValue)

					worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = new WaterEntity(cavern.cells.get(i).x,
							cavern.cells.get(i).y);
			}
			for (int i = 0; i < cavern.cells.size(); i++) {
				if (cavern.cells.get(i).y == pickedValue) {
					worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = new WaterTopEntity(cavern.cells.get(i).x,
							cavern.cells.get(i).y);
				}
				if (cavern.cells.get(i).y == lowest) {
					worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = new WaterBottomEntity(
							cavern.cells.get(i).x, cavern.cells.get(i).y);
				}
			}

		}
	}

	/*
	 * addWaterToCave Add water blocks to cave - still needs work as adds to
	 * half way in the cave - best to do random height and also do random value
	 * if the cave is going to have water or not (DONE if has water 6/3/2016)
	 */
	//
	private void addWaterToCave(int whichCave) {

		for (int xx = 0; xx < caves.size(); xx++) {
			Cave cavern = this.caves.get(xx);

			if (!cavern.isWaterCave) // Is this a water cave?
				continue;

			int highest = 0;
			int lowest = 100000;

			for (int i = 0; i < cavern.cells.size(); i++) {
				if (cavern.cells.get(i).y > highest)
					highest = cavern.cells.get(i).y;
				if (cavern.cells.get(i).y < lowest)
					lowest = cavern.cells.get(i).y;
			}

			int pickedValue = lowest;
			if (highest - lowest > 0)
				pickedValue = lowest + ((highest - lowest) / 2);

			for (int i = 0; i < cavern.cells.size(); i++) {
				if (cavern.cells.get(i).y <= pickedValue)

					worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = new WaterEntity(cavern.cells.get(i).x,
							cavern.cells.get(i).y);
			}
			for (int i = 0; i < cavern.cells.size(); i++) {
				if (cavern.cells.get(i).y == pickedValue) {
					worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = new WaterTopEntity(cavern.cells.get(i).x,
							cavern.cells.get(i).y);
				}
				if (cavern.cells.get(i).y == lowest) {
					worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = new WaterBottomEntity(
							cavern.cells.get(i).x, cavern.cells.get(i).y);
				}
			}

		}
	}

	/*
	 * Tree biomes addTress Add trees of random height to the top level (grass)
	 */
	private void addTrees() {
		Random r = new Random();
		TreeEntity treeOne = null;
		for (int y = GRASS_START; y < GRASS_MAX - 2; y++) {
			for (int x = 2; x < w - 1; x += 7) {// r.nextInt(7)+8) {
				if (worldMap[x][y] instanceof GrassEntity) {
					if (r.nextInt(8) > TREECHANCE) {// TREECHANCE) { //
													// TREECHANCE) {
						int size = r.nextInt(40);

						for (int i = 1; i < size + 2; i++) {
							treeOne = r.nextBoolean() == true ? new TreeEntity(x, y + i) : new TreeEntityTwo(x, y + i);
							// the bigger the tree, the more hits needed to cut
							// it down
							treeOne.hits = (byte) (size / 6 + 2);
							worldMap[x][y + i] = treeOne; // place
															// sprite
						}
						// add some random branches
						/*
						 * for (int i = 3; i < size + 2; i++) { boolean rr =
						 * r.nextBoolean(); treeOne = rr == true ? new
						 * TreeEntityBranchLeft(x - 1, y + i) : new
						 * TreeEntityBranchRight(x + 1, y + i); // the bigger
						 * the tree, the more hits needed to cut // it down if
						 * (r.nextBoolean()) { treeOne.hits = (byte) (size / 6 +
						 * 2); if (rr) { worldMap[x - 1][y + i] = treeOne; if
						 * (r.nextBoolean()) if (x > 2) worldMap[x - 2][y + i] =
						 * new LeafEntityBranchLeft(x - 2, y + i); } else {
						 * worldMap[x + 1][y + i] = treeOne; if
						 * (r.nextBoolean()) worldMap[x + 2][y + i] = new
						 * LeafEntityBranchRight(x + 2, y + i); } } }
						 * 
						 * worldMap[x][y + size + 2] = new TreeEntity(x, y +
						 * size + 2); worldMap[x][y + size + 3] = new
						 * LeafEntityBranchTop(x, y + size + 3);
						 * 
						 * if (worldMap[x + 1][y + size + 2] == null) worldMap[x
						 * + 1][y + size + 2] = new LeafEntityBranchLeft(x + 1,
						 * y + size + 2);
						 * 
						 * if (x > 1 && worldMap[x - 1][y + size + 2] == null)
						 * worldMap[x - 1][y + size + 2] = new
						 * LeafEntityBranchRight(x - 1, y + size + 2);
						 */
					} else {
						// Flowers
						worldMap[x][y + 1] = new FlowerEntity(x, y);
					}
				}
			}
		}
	}

	// Add some crops/food to the land - we need this as a user setting, if
	// world difficult, food/crops should be scarce etc...
	private void addCrops() {
		CropEntity[] crops = { new Block2800Entity(0, 0), new Block2801Entity(0, 0), new Block2802Entity(0, 0),
				new Block2803Entity(0, 0), };
		// Random r = new Random();
		for (int y = GRASS_START; y < GRASS_MAX - 2; y++) {
			// r = new Random();
			for (int x = 2; x < w - 1; x += 1) {// r.nextInt(7)+8) {
				// r = new Random();
				if (worldMap[x][y] instanceof GrassEntity) {
					if (r.nextInt(200) > CROPCHANCE) {
						worldMap[x][y + 1] = crops[r.nextInt(4)];
						worldMap[x][y + 1].x = x;
						worldMap[x][y + 1].y = y;
					}
				}
			}
		}
	}

	/*
	 * getEntity Get tile from map
	 */
	private BlankEntity getEntity(int x, int y) {
		if (x > 0 && y > 0 && x < this.w - 1 && y < this.h - 1)
			return worldMap[x][y];
		return null;
	}

	/*
	 * addEntity Add a tile to the map
	 */
	public void addEntity(BlankEntity entity) {
		BlankEntity ent = getBlock(entity.x, entity.y);

		if (ent instanceof CaveEntity) {

			entity.underNeath = worldMap[entity.x][entity.y];// new
																// CaveEntity(entity.x,
																// entity.y); //
																// store
																// previous
																// block
			entity.originalLightValue = entity.underNeath.originalLightValue;
			entity.lightValue = -100;// ent.originalLightValue;

		} else // CODE BELOW DOESN'T SEEM TO WORK?!?!?!?
		{
			// Grass entity? and snow we trying to add?
			if (ent instanceof GrassEntity && (entity instanceof SnowStageOneEntity
					|| entity instanceof SnowStageTwoEntity || entity instanceof SnowStageThreeEntity)) {
				entity.underNeath = getBlock(entity.x, entity.y);// new
																	// CaveEntity(entity.x,entity.y);
																	// // store
																	// previous
																	// block
				entity.originalLightValue = entity.underNeath.originalLightValue;

			}
			if (ent instanceof CaveEntity) {
				entity.underNeath = getBlock(entity.x, entity.y);
				entity.originalLightValue = entity.underNeath.originalLightValue;
			}

		}
		worldMap[entity.x][entity.y] = entity;
	}

	/*
	 * removeEntity Remove a tile from the map
	 */
	public void removeEntity(int x, int y) {
		BlankEntity entity = getBlock(x, y);
		if (entity.isLight) // just remove the light
		{
			entity.isLight = false;
			return;
		}
		if (entity.isDecoration) {
			entity.isDecoration = false;
			return;
		}
		if (entity instanceof MaterialBuildingBlock || entity instanceof DecorationEntity
				|| entity instanceof LargeMaterialBuildingBlock) {
			worldMap[x][y] = entity.underNeath;
		} else {

			if (entity instanceof GrassLeftEntity) {
				worldMap[x][y] = new CaveLeftEntity2(x, y);
			} else if (entity instanceof GrassRightEntity) {
				worldMap[x][y] = new CaveRightEntity2(x, y);
			} else if (entity instanceof GrassEntity) {
				worldMap[x][y] = new CaveTopEntity2(x, y);
			} else if (entity instanceof SnowStageOneEntity) {
				worldMap[x][y] = new CaveTopEntity2(x, y);
				worldMap[x][y].lightValue = entity.lightValue;
				worldMap[x][y].originalLightValue = entity.originalLightValue;
				return;
			} else if (entity instanceof SnowStageThreeEntity) {
				worldMap[x][y] = new CaveTopEntity2(x, y);
				worldMap[x][y].lightValue = entity.lightValue;
				worldMap[x][y].originalLightValue = entity.originalLightValue;
				return;
			} else if (entity instanceof SnowStageTwoEntity) {
				worldMap[x][y] = new CaveTopEntity2(x, y);
				worldMap[x][y].lightValue = entity.lightValue;
				worldMap[x][y].originalLightValue = entity.originalLightValue;
				return;
			} else if (entity instanceof CropEntity) {
				if (worldMap[x][y].underNeath != null) {
					worldMap[x][y].lightValue = entity.lightValue;
					worldMap[x][y].originalLightValue = entity.originalLightValue;
				} else
					worldMap[x][y] = worldMap[x][y].underNeath;
				return;
			}

			// else
			/*
			 * if (entity instanceof GrassEntity || entity instanceof TreeEntity
			 * // || entity instanceof // LandscapeEntity // //
			 * LandscapeRightEntity || // entity instanceof //
			 * LandscapeLeftEntity || entity instanceof SnowStageOneEntity ||
			 * entity instanceof SnowStageTwoEntity || entity instanceof
			 * SnowStageThreeEntity || entity instanceof MaterialBuildingBlock
			 * || entity instanceof LightEntity) { // need fix when we remove
			 * the light... // || entity instanceof OpazEntity )
			 * worldMap[x][y]=new CaveEntity(x, y); //worldMap[x][y] =
			 * entity.underNeath;// new CaveEntity(x, y); //
			 * worldMap[x][y].lightValue =entity.lightValue;// new CaveEntity(x,
			 * // y); // worldMap[x][y].originalLightValue =
			 * entity.originalLightValue; } else // really need see what was
			 * hit, need put dirt block underneath - // if was landscape left,
			 * left dirtblock, if right, right // dirtblock {
			 */
			if (entity instanceof LandscapeLeftEntity) {
				worldMap[x][y] = new CaveLeftEntity3(x, y);
			} else if (entity instanceof LandscapeRightEntity) {
				worldMap[x][y] = new CaveRightEntity3(x, y);
			} else if (entity instanceof LandscapeEntity) {
				worldMap[x][y] = new CaveEntity(x, y);
			} else if (entity instanceof CaveRightEntity) {
				worldMap[x][y] = new CaveEntity(x, y); // need new
														// CaveRightEntity3
			} else if (entity instanceof CaveLeftEntity) {
				worldMap[x][y] = new CaveEntity(x, y); // need new
														// CaveLeftEntity3
			} else if (entity instanceof CaveTopEntity) {
				worldMap[x][y] = new CaveEntity(x, y);
			} else if (entity instanceof CaveBottomEntity) {
				worldMap[x][y] = new CaveEntity(x, y);
			} else if (entity instanceof LightEntity) {
				// worldMap[x][y].isLight = false;
				// CaveEntity c = new CaveEntity(x, y);
				// if(worldMap[x-1][y] !=null)
				// {
				// c.lightValue = worldMap[x-1][y].lightValue;
				// c.originalLightValue = worldMap[x-1][y].originalLightValue;
				// worldMap[x][y] =c;
				// return;
				// }
				// else
				{
					worldMap[x][y] = null;// new BlankEntity(x,y);
					return;
				}
			}
			if (worldMap[x][y] != null) {
				worldMap[x][y].lightValue = entity.lightValue;
				worldMap[x][y].originalLightValue = entity.originalLightValue;
			}
		}

		// we need get correct light values in here

		// worldMap[x][y] = new CaveEntity(x, y);
	}

	// /////////////////////////////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////////////////
	public void moveWater(int sx, int sy, int ex, int ey) {

		for (int y = sy; y <= ey; y++) {
			for (int x = sx; x < ex + 1; x++) {
				try {
					if (worldMap[x][y] instanceof WaterEntity) {

						if ((worldMap[x][y - 1] instanceof LavaEntity) || (worldMap[x][y - 1] instanceof CaveEntity)) {
							worldMap[x][y] = new CaveEntity(x, y);
							worldMap[x][y - 1] = new WaterEntity(x, y - 1);
						} else if ((worldMap[x - 1][y] instanceof LavaEntity)
								|| (worldMap[x - 1][y] instanceof CaveEntity)) { // air
																					// to
																					// the
																					// left
							worldMap[x][y] = new CaveEntity(x, y);
							worldMap[x - 1][y] = new WaterEntity(x - 1, y);
						} else if ((worldMap[x + 1][y] instanceof LavaEntity)
								|| (worldMap[x + 1][y] instanceof CaveEntity)) { // air
																					// to
																					// the
																					// right
							worldMap[x][y] = new CaveEntity(x, y);
							worldMap[x + 1][y] = new WaterEntity(x + 1, y);
						}
					}
				} catch (java.lang.ArrayIndexOutOfBoundsException e) {
					// System.out.println("Water out of world bounds");
				}
			}
		}
	}

	/*
	 * drawMap When drawing the map, we need to draw just screen width, screen
	 * height at the position the player is in
	 */

	public void drawMapWithBloom(boolean bDebug, SpriteBatch batch, TextureRegion[][] region, int sx, int sy, int ex,
			int ey, int w, int h) {

		// draw what we can see
		for (int row = sy; row < ey + 1; row++)
			for (int col = sx; col < ex + 1; col++) {
				BlankEntity entity = getEntity(col, row);
				if (entity != null) {
					{
						batch.setColor((float) entity.lightValue / MAXLIGHT, (float) entity.lightValue / MAXLIGHT,
								(float) entity.lightValue / MAXLIGHT, 1);

						if (entity.lightValue > 0)
							worldMap[col][row].draw(batch, region, col - sx, row - sy);
					}
				}
			}
		batch.setColor(1, 1, 1, 1);

	}

	public float getBlockColor(Vector3 position) {
		Vector3 screenSpace = toScreenSpace(position);
		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);
		BlankEntity entity = getEntity(x, y);
		if (entity != null) {
			return (float) entity.lightValue / MAXLIGHT;
		}
		return 1;
	}

	// Draw the tile map (only what we can see though, obviously!)
	public void drawMap(boolean bDebug, SpriteBatch batch, TextureRegion[][] region, int sx, int sy, int ex, int ey,
			int w, int h, boolean water, float c) {

		Color originalColor = batch.getColor();

		//c = 1;
		
		if (bDebug) { // Draw everything...for debug, be about 2fps!
			for (int row = 0; row < this.h - 1; row++)
				for (int col = 0; col < this.w - 1; col++) {
					BlankEntity entity = getEntity(col, row);
					if (entity != null) {
						// if (entity.lightValue > 0)
						batch.setColor(1, 1, 1, 1);
						worldMap[col][row].draw(batch, region, col, row);
					}
				}

		} else {
			boolean bLightNear = false;
			for (int row = sy; row < ey + 1; row++)
				for (int col = sx; col < ex + 1; col++) {
					BlankEntity entity = getEntity(col, row);
			/*		for (SpotLight l : lights) { // check if any spot light near block
						if (col < l.x - 10 || col > l.x + 10 || row < l.y - 10 || row > l.y + 10) {
							bLightNear = false;
						}
						else
						{
							bLightNear = true;
						//	System.out.println("Light near block");
							break;  // break out of the loop
						}
					}*/
					if (water && entity != null && entity instanceof WaterEntity) { // Draw
																					// water
																					// entities

//						if(!bLightNear)
						if( !(entity instanceof CaveEntity ) && !(entity instanceof LandscapeEntity) &&
								!(entity instanceof GrassEntity) && !(entity instanceof WaterEntity))

							batch.setColor((float) (entity.lightValue / MAXLIGHT)*c, (float) (entity.lightValue / MAXLIGHT)*c,
									(float) (entity.lightValue / MAXLIGHT)*c, 1);
						else
							batch.setColor((float) (entity.lightValue / MAXLIGHT)*1, (float) (entity.lightValue / MAXLIGHT)*1,
									(float) (entity.lightValue / MAXLIGHT)*1, 1);
		

						if (entity.lightValue > 0)
							worldMap[col][row].draw(batch, region, col, row);
						


					} else // possibly water entity
					{
						if (!water && entity != null && !(entity instanceof WaterEntity)) { // Draw
																							// everything
																							// except
																							// water
																							// entities

							if( !(entity instanceof CaveEntity ) && !(entity instanceof LandscapeEntity) &&
									!(entity instanceof GrassEntity) && !(entity instanceof WaterEntity))
//							if(!bLightNear)
								batch.setColor((float) (entity.lightValue / MAXLIGHT)*c, (float) (entity.lightValue / MAXLIGHT)*c,
										(float) (entity.lightValue / MAXLIGHT)*c, 1);
							else
								batch.setColor((float) (entity.lightValue / MAXLIGHT)*1, (float) (entity.lightValue / MAXLIGHT)*1,
										(float) (entity.lightValue / MAXLIGHT)*1, 1);
							
					//		batch.setColor((float) (entity.lightValue / MAXLIGHT)*c, (float) (entity.lightValue / MAXLIGHT)*c,
						//			(float) (entity.lightValue / MAXLIGHT)*c, 1);
			

							if (entity.lightValue > 0)
								worldMap[col][row].draw(batch, region, col, row);
							


						} else if (!water && entity != null && entity instanceof WaterEntity) // we
																								// need
																								// to
																								// add
																								// cave
																								// entity
																								// due
																								// to
																								// water
																								// being
																								// transparent,
																								// else
																								// clouds
																								// show
																								// through!
							batch.draw(region[1][1], col << 4, row << 4);

						if (entity != null && entity.isLight) {
							// we need to draw a light also on top of this block
							batch.setColor(1, 1, 1, 1);
							LightEntity light = new LightEntity(col, row);
							light.draw(batch, region, col, row);
						}
						if (entity != null && entity.isDecoration) // draw
																	// decoration
						{
							entity.decorationEntity.draw(batch, region, col, row);
						}
					}
				}
		}
		batch.setColor(originalColor);
	}

	private void insertRandomRocks() {

		Random r = new Random();
		for (Chunk c : chunkList) {
			int rock = r.nextInt(ROCKAMOUNT);
			for (int y = 0; y < Chunk.CHUNKSIZE; y++) {
				for (int x = 0; x < Chunk.CHUNKSIZE; x++) {
					drawRockLayer(c.x, c.y, rock);

				}
			}
		}
	}

	private void drawRockLayer(int xx, int yy, int rock) {
		Random r = new Random();
		int endY = r.nextInt(Chunk.CHUNKSIZE);
		for (int y = 0; y < endY; y++) {
			int xStart = r.nextInt(Chunk.CHUNKSIZE - 2);
			int xEnd = r.nextInt(Chunk.CHUNKSIZE);
			if (xEnd < xStart)
				xEnd += 1;
			for (int x = xStart; x < xEnd; x++) {
				if (yy < h - 500) { // where to start doing the rocks from
					switch (rock) // need to add more rocks here
					{

					case 0:
						worldMap[xx + x][yy + y] = r.nextBoolean() == true ? new RealLavaEntity(xx + x, yy + y)
								: worldMap[xx + x][yy + y];
						break;
					case 1:
						worldMap[xx + x][yy + y] = r.nextBoolean() == true ? new RockEntity(xx + x, yy + y)
								: worldMap[xx + x][yy + y];
						break;
					case 2:
						worldMap[xx + x][yy + y] = r.nextBoolean() == true ? new RockEntity(xx + x, yy + y)
								: worldMap[xx + x][yy + y];
						break;
					case 3:
						worldMap[xx + x][yy + y] = r.nextBoolean() == true ? new CoalEntity(xx + x, yy + y)
								: worldMap[xx + x][yy + y];
						break;
					case 4:
						worldMap[xx + x][yy + y] = r.nextBoolean() == true ? new CoalEntity(xx + x, yy + y)
								: worldMap[xx + x][yy + y];
						break;
					default:
						worldMap[xx + x][yy + y] = r.nextBoolean() == true ? new LandscapeEntity(xx + x, yy + y)
								: new LandscapeEntity2(xx + x, yy + y);
						break;
					}
				}
			}
		}
	}

	private void createChunks() {
		Random r = new Random();
		for (int sy = 0; sy < WorldMap.h; sy += Chunk.CHUNKSIZE) {
			for (int sx = 0; sx < WorldMap.w; sx += Chunk.CHUNKSIZE) {
				if (isChunk(sx, sy)) {
					if (r.nextInt(5) > CHANCEOFADDINGCHUNK) // randomly choose
															// if we create this
															// chunk (saves on
															// memory doing it
															// here)
						chunkList.add(new Chunk(sx, sy));
				}
			}
		}
	}

	private boolean isChunk(int x, int y) {
		try {
			for (int yy = 0; yy < Chunk.CHUNKSIZE; yy++) {
				for (int xx = 1; xx < Chunk.CHUNKSIZE; xx++) {
					// We don't want to add any special rocks in water or a cave
					// entity
					if (worldMap[x + xx][y + yy] == null || worldMap[x + xx][y + yy] instanceof WaterEntity
							|| worldMap[x + xx][y + yy] instanceof CaveEntity)
						return false;

					if (worldMap[x + xx][y + yy].id != worldMap[xx + x - 1][yy + y].id) {
						return false;
					}
				}
			}
		} catch (Exception e) {
			return false;
		}
		return true;// (Chunk.CHUNKSIZE-1) * Chunk.CHUNKSIZE;
	}

	private void addPlanet(int x, int y) {
		Random r = new Random();
		if (r.nextInt(4) >= 2) {
			for (float i = 0; i < r.nextInt(30) + 8; i++) {
				for (double u = 0.0f; u < 360; u += 1) {
					double angle = u * Math.PI / 180;
					int x2 = (int) (x + i * Math.cos(angle));
					int y2 = (int) (y + i * Math.sin(angle));
					worldMap[x2][y2] = r.nextBoolean() == true ? new MoonEntity(x2, y2) : new MoonEntityCrater(x2, y2);
				}
			}
		}
	}

	// This will create a weird landscape with some caves...
	@SuppressWarnings("unused")
	private void generateLandIsland(int x, int y) {
		Random r = new Random();
		for (float i = 0; i < r.nextInt(28) + 8; i++) {
			for (double u = 0.0f; u < r.nextInt(360) + 100; u += 0.5) {
				double angle = u * Math.PI / 180;
				int x2 = (int) (x + i * Math.cos(angle));
				int y2 = (int) (y + i * Math.sin(angle));
				worldMap[x2][y2] = r.nextBoolean() == true ? new CaveEntity(x2, y2) : new LavaEntity(x2, y2);
			}
		}
	}

	public void findLand(List<OutsideLand> landList) {
		for (int y = h - 1; y > GRASS_START; y--) // 2000 > 1400
		{
			for (int x = 0; x < w - 1; x++) {
				if (worldMap[x][y] instanceof GrassEntity) {
					OutsideLand foundLand = new OutsideLand(x, y);
					landList.add(foundLand);
				}
			}
		}
	}

	/*
	 * Find land for trees to be planted
	 */
	public void findLandForTrees(List<OutsideLand> landList) {
		for (int y = h - 1; y > GRASS_START; y--) // 2000 > 1400
		{
			for (int x = 0; x < w - 4; x += 4) {
				if (worldMap[x][y] instanceof GrassEntity && worldMap[x + 1][y] instanceof GrassEntity
						&& worldMap[x + 2][y] instanceof GrassEntity && !(worldMap[x][y + 1] instanceof BiomDomeEntity))// &&
				// worldMap[x+3][y]
				// instanceof
				// GrassEntity)
				{
					OutsideLand foundLand = new OutsideLand(x + 1, y);
					landList.add(foundLand);
				}
			}
		}
	}

	/*
	 * Find land for trees to be planted
	 */
	public void findLandForCrops(List<OutsideLand> landList) {
		for (int y = h - 1; y > GRASS_START; y--) // 2000 > 1400
		{
			for (int x = 0; x < w - 1; x += 4) {
				if (worldMap[x][y] instanceof GrassEntity && worldMap[x + 1][y] instanceof GrassEntity
						&& worldMap[x + 2][y] instanceof GrassEntity)// &&
																		// worldMap[x+3][y]
																		// instanceof
																		// GrassEntity)
				{
					OutsideLand foundLand = new OutsideLand(x + 1, y);
					landList.add(foundLand);
				}
			}
		}
	}

	/*
	 * TO DO
	 */
	private void flattenLand() {

	}

	public boolean checkLongCollision(Vector3 position, int width, int height) {

		boolean collision = true;
		Vector3 screenSpace = toScreenSpace(position);

		int x = Math.round(screenSpace.x);
		int y = Math.round(screenSpace.y);

		for (int xx = 0; xx < width / 16; xx++) {
			BlankEntity entity = getBlock(x + xx, y);
			if (entity instanceof CaveTopEntity || entity instanceof CaveLeftEntity
					|| entity instanceof CaveRightEntity)
				collision = false;
			if (entity == null || entity instanceof CaveEntity || entity instanceof WaterEntity
					|| entity instanceof LavaEntity || entity instanceof TreeEntity)
				collision = false;
		}
		return collision;
	}

	public void addChests() {
		for (int xx = 0; xx < caves.size(); xx++) {
			Cave cavern = this.caves.get(xx);

			if (!cavern.isWaterCave) // Is this a water cave?
			{
				int highest = 0;
				int lowest = 100000;

				for (int i = 0; i < cavern.cells.size(); i++) {
					if (cavern.cells.get(i).y > highest)
						highest = cavern.cells.get(i).y;
					if (cavern.cells.get(i).y < lowest)
						lowest = cavern.cells.get(i).y;
				}

				int pickedValue = lowest;
				if (highest - lowest > 0)
					pickedValue = lowest + ((highest - lowest) / 2);

				for (int i = 0; i < cavern.cells.size(); i++) {
					if (cavern.cells.get(i).y <= pickedValue)

						if (r.nextInt(10) > 8) // this will need work - we add a
												// chest if over 8
						{
							Block633Entity chest = new Block633Entity(cavern.cells.get(i).x, cavern.cells.get(i).y);
							chest.underNeath = new CaveEntity(cavern.cells.get(i).x, cavern.cells.get(i).y);
							chest.originalLightValue = this.getBlock(cavern.cells.get(i).x,
									cavern.cells.get(i).y).originalLightValue;
							chest.lightValue = this.getBlock(cavern.cells.get(i).x, cavern.cells.get(i).y).lightValue;

							worldMap[cavern.cells.get(i).x][cavern.cells.get(i).y] = chest;

						}
					break;

				}
			}
		}

	}
}
