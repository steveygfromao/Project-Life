package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class InventorySlot extends InventoryAbstractSlot {
	
	@Override
	public Rectangle bounds() {
		return new Rectangle(x + icon.getWidth() * 0.2f, y + icon.getHeight() * 0.2f, icon.getWidth() * 0.8f,
				icon.getHeight() * 0.8f);
	}


	public InventorySlot(float x, float y, String iconPath) {
		super(x,y,iconPath);
	}

	@Override
	public void draw(SpriteBatch batch, InventoryAbstractSlot i) {
		if (this.isSelected() || this.getPicked())
			batch.setColor(1, 1, 1, 1);
		else
			batch.setColor(1, 1, 1, 0.7f);

		Sprite s = new Sprite(icon);
		s.setPosition(x, y);
		s.flip(false, true);
		s.draw(batch);
		//batch.draw(icon, x, y);
		if (i != null && i.type !=null)
		{
			
			batch.draw(item, x + 16, y + 16
					, 16, 16, i.type.sx*16, i.type.sy*16, 16, 16, false, true);
			
			font.draw(batch, Integer.toString(type.amount), x + 2, y );
		}
	}
}
