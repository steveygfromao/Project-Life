package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Selection {

	private static Sprite selectionSheet;
	private static float xPos,yPos;
	
	public static void initialise(String file, float x, float y)
	{
		xPos = x;
		yPos = y;
		
		selectionSheet = new Sprite(new Texture(file));
		
	}
	
	public static void draw(SpriteBatch batch)
	{
		selectionSheet.setPosition(xPos, yPos);// - hudSprite.getHeight() - 20);
		selectionSheet.draw(batch);

	}
}
