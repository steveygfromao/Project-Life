package com.mygdx.game;

import java.util.ArrayList;

public class Line {
	BlankEntity[][] map = null;

	private ArrayList<Point> points;

	public ArrayList<Point> getLineOfSight() {
		return points;
	}

	private int cx, cy;

	private int w, h;

	public int getCollisionX() {
		return cx;
	}

	public int getCollisionY() {
		return cy;
	}

	// Display map
	public void Debug() {
		for (int y = 0; y < h; y++, System.out.println())
			for (int x = 0; x < w; x++)
				System.out.print(map[x][y]);
	}

	public Line(int w, int h, WorldMap worldMap) {
		this.w = w;
		this.h = h;
		map = worldMap.getWorldMap();
	}

	public void Initalise() {
		for (int y = 0; y < h; y++)
			for (int x = 0; x < w; x++)
				map[x][y] = null;
	}

	public boolean RayCast(int x0, int y0, int x1, int y1) {
		//points = new ArrayList<Point>();
		boolean visible = true;

		int dx = Math.abs(x1 - x0);
		int dy = Math.abs(y1 - y0);

		int sx = x0 < x1 ? 1 : -1;
		int sy = y0 < y1 ? 1 : -1;
		int err = dx - dy;

		while (true) {
		//	points.add(new Point(x0, y0));
			// map[x0][y0] = '*';
			try
			{
				if ((map[x0][y0] instanceof LandscapeEntity) || (map[x0][y0] instanceof GrassEntity)
						|| (map[x0][y0] instanceof MaterialBuildingBlock)
	
				) {
					// System.out.printf("\n\n** Ray hit some land - array[%d,%d] |
					// screen[%d,%d] **\n\n",x0,y0,x0*16,y0*16);
					visible = false;
					break;
				}
				if (x0 == x1 && y0 == y1) // reached destination?
					break;
	
				int e2 = err * 2;
				if (e2 > -dx) {
					err -= dy;
					x0 += sx;
				}
				if (e2 < dx) {
					err += dx;
					y0 += sy;
				}
			}
			catch(Exception e) { }
		}
		cx = x0;
		cy = y0;
		return visible;
	}
}
