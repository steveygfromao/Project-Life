package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public abstract class InventoryAbstractSlot {

	public InventoryAbstractSlot(float x, float y, String iconPath) {	
		this.x = x;
		this.y = y-64;
		icon = new Sprite(new Texture(iconPath));
		font.setColor(0.5f,0.5f,0.5f,1);
	
	}
			
		
	protected float x, y;

	protected Sprite icon;
	protected static Texture item;
	
	protected LandscapeEntity type,type2,type3,type4;
	
	protected BitmapFont font = new BitmapFont(true);
	
	private boolean isSelected = false;

	private boolean empty = true;

	private boolean picked = false;
	
	public void setPicked(boolean picked) {
		this.picked = picked;
	}
	
	public boolean getPicked() { 
		return picked;
	}
	
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public boolean isSelected() {
		return this.isSelected;
	}
	
	public void setSlotEmpty(boolean empty) {
		this.empty = empty;
	}

	public boolean isSlotEmpty() {
		return empty;
	}

	public void removeItem() {
		setSlotEmpty(true);
		item = null;
	} 

	abstract void draw(SpriteBatch batch, InventoryAbstractSlot i);

	abstract Rectangle bounds();

}
