package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Weapon {

	private float TIMER = 1.0f;

	private boolean animating = false;

	private SpriteBatch spriteBatch = null;

	SpriteBatch batch;
	TextureRegion[] animationFrames;
	Animation animation;
	float elapsedTime;

	public void create(TextureRegion[][] tmpFrames) {
		batch = new SpriteBatch();
		animationFrames = new TextureRegion[8];
		int index = 0;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 1; j++) {
				animationFrames[index++] = tmpFrames[j][i];
			}
		}

		animation = new Animation(TIMER, animationFrames);

	}

	public void render(float x, float y, float rotation) {
		elapsedTime += Gdx.graphics.getDeltaTime();
		//Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		if (TIMER < 8) {
			TIMER +=  0.5f;
			batch.draw(animation.getKeyFrame(TIMER, false), x, y-24, 8, 0, 16, 16, 1.0f, 1.0f, rotation, false);
			animating = true;
		}
		else
		{
			batch.draw(this.animationFrames[0], x, y-24, 8, 0, 16, 16, 1.0f, 1.0f, rotation, false);
			animating = false;
			TIMER=8;
		}

		batch.end();
	}

	public boolean swiping() {
		return this.animating;
	}

	public void resetWeapon() {
		if(TIMER >=8)
		{
			TIMER = 0.0f;
			animating = false;
		}
	}

	public SpriteBatch getSpriteBatch() {
		return this.spriteBatch;
	}

	public Weapon() {
		spriteBatch = new SpriteBatch();

	}

	public void draw(SpriteBatch batch, TextureRegion[][] weapon, int row, int col, float x, float y, float rotation,
			boolean dir) {
		batch.begin();

		batch.draw(weapon[row][col], x, y, 8, 0, 16, 16, 1, 1, rotation, dir);
		batch.end();
	}

}
