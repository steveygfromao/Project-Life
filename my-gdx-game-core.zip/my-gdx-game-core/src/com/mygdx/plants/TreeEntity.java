package com.mygdx.plants;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public abstract class TreeEntity {

	float x, y;
	byte hits;
	int growTime;

	boolean grown = true;
	
	float scale = 0;
	float growStep = 0;
	
	public TreeEntity(){}
	
	public TreeEntity(float x, float y, byte hits, int growTime, float growStep, float scale) {
		this.x = x;
		this.y = y;
		this.hits = hits;
		this.growTime = growTime;
		this.growStep = growStep;
		this.scale = scale;
		grown = this.growTime <= 0;
	}

	protected abstract void draw(SpriteBatch batch, TextureRegion[][] tree, float col);

	protected void fallOver() {
		System.out.println("To implement");
	}
}