package com.mygdx.plants;

import java.util.ArrayList;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class TreeManager {

	static public enum TreeTypes {
		SMALL, MEDIUM, LARGE
	}

	private ArrayList<TreeEntity> treeList = new ArrayList<>();
	private Texture trees;
	private TextureRegion[][] treeSpriteRegions = null;


	public TreeManager(String path, Camera camera) {
		trees = new Texture(path);
		treeSpriteRegions = TextureRegion.split(trees, 80, 160);
	}

	public void add(TreeEntity tree) {
		treeList.add(tree);
	}

	public void remove(TreeEntity tree) {
		treeList.remove(tree);
	}

	public void checkTrees(Camera camera, SpriteBatch batch, int width, int height, float col) {
		treeList.forEach(tree -> {
			if (tree.hits <= 0) {
				tree.fallOver(); // need tree to fall over
				// remove(tree); // may cause a crash...
			} else // tree still around so lets draw it
			{
				if (tree.scale < 1)
					tree.scale += tree.growStep;// 0.001;
				if (tree.growTime > 0) {
					tree.growTime -= 1;
				}
				if (tree.x >= (camera.position.x - (width) ) && tree.x <= camera.position.x + width
						&& tree.y >= (camera.position.y - (height) - 0) && tree.y <= camera.position.y + height)

					tree.draw(batch, treeSpriteRegions,col);
			}
		});
	}

}
