package com.mygdx.plants;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class OakTreeEntity extends TreeEntity {

	public OakTreeEntity(float x, float y, byte hits, int growTime, float growStep, float scale) {
		super(x, y, hits, growTime, growStep, scale);
	}

	@Override
	protected void draw(SpriteBatch batch, TextureRegion[][] tree, float col) {
		Color c = batch.getColor();
		batch.setColor(1,1,1,1);		
		Sprite s = new Sprite(tree[0][1]);
		
		s.setColor(col,col,col,1);

		s.setSize(s.getWidth() * scale, s.getHeight() * scale);
		s.setRotation(0);
		s.setPosition(x,y);
		s.draw(batch);

		batch.setColor(c);
	}
}