package com.mygdx.plants;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class LargeTree extends TreeEntity {

	public LargeTree(float x, float y, byte hits, int growTime, float growStep, float scale) {
		super(x, y, hits, growTime, growStep, scale);
	}

	@Override
	protected void draw(SpriteBatch batch, TextureRegion[][] tree, float col) {
		Color c = batch.getColor();
		batch.setColor(1,1,1,1);		
		Sprite s = new Sprite(tree[0][3]);
		
		s.setColor(col,col,col,1);
		s.setSize(s.getWidth() * scale, s.getHeight() * scale);
		s.setRotation(0);
		s.setPosition(x,y );
		s.draw(batch);
	
		batch.setColor(c);
	//	batch.draw(tree[0][0], x, y, tree[0][0].getRegionWidth(), tree[0][0].getRegionHeight());				
	}
}
